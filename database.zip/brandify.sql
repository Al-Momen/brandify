-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 30, 2025 at 09:24 AM
-- Server version: 8.0.30
-- PHP Version: 8.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brandify`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint UNSIGNED NOT NULL,
  `role_id` bigint DEFAULT NULL,
  `name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `username` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `remember_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `role_id`, `name`, `email`, `username`, `email_verified_at`, `image`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 0, 'Super Admin', 'admin@example.com', 'admin', NULL, '6864d156b3f2e1751437654.jpg', '$2y$12$KCGCuWN/lg5cjhwNg5HI6Oliv1SCFmnU4Jqad9513ldWq/WGyErLO', 'l4z61PpWEkt93kHmqh5W0aHF13DECT8FmJ2m6PTDCrKl5fd8CVddQvAOkGsY', NULL, '2025-09-13 00:30:05'),
(3, 3, 'Manager', 'manager@gmail.com', 'manager', NULL, '686a18d8e2e881751783640.jpg', '$2y$12$x8DlEz5FlUm7NpfXROifY.MoQYrUNntJs8/24lasApzSh1PZ2rIFO', NULL, '2025-07-06 00:34:02', '2025-07-06 00:34:02');

-- --------------------------------------------------------

--
-- Table structure for table `admin_notifications`
--

CREATE TABLE `admin_notifications` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL DEFAULT '0',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `read_status` tinyint(1) NOT NULL DEFAULT '0',
  `click_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_notifications`
--

INSERT INTO `admin_notifications` (`id`, `user_id`, `title`, `read_status`, `click_url`, `created_at`, `updated_at`) VALUES
(1, 1, 'Credit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/1', '2025-10-27 01:27:31', '2025-10-27 01:27:31'),
(2, 1, 'Credit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/2', '2025-10-27 01:30:37', '2025-10-27 01:30:37'),
(3, 1, 'Deposit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/3', '2025-10-27 01:32:28', '2025-10-27 01:32:28'),
(4, 1, 'Deposit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/4', '2025-10-27 01:33:44', '2025-10-27 01:33:44'),
(5, 1, 'Plan Paymentrequest from testuser', 0, '/admin/manage/deposits/details/5', '2025-10-27 03:10:48', '2025-10-27 03:10:48'),
(6, 1, 'Plan Paymentrequest from testuser', 0, '/admin/manage/deposits/details/6', '2025-10-27 03:15:29', '2025-10-27 03:15:29'),
(7, 1, 'Plan Paymentrequest from testuser', 0, '/admin/manage/deposits/details/11', '2025-10-27 04:16:37', '2025-10-27 04:16:37'),
(8, 1, 'Plan Paymentrequest from testuser', 0, '/admin/manage/deposits/details/12', '2025-10-27 04:18:33', '2025-10-27 04:18:33'),
(9, 1, 'Plan Subscription Paymentrequest from testuser', 0, '/admin/manage/deposits/details/14', '2025-10-27 04:54:34', '2025-10-27 04:54:34'),
(10, 1, 'Plan Subscription Paymentrequest from testuser', 0, '/admin/manage/deposits/details/15', '2025-10-27 04:56:43', '2025-10-27 04:56:43'),
(11, 1, 'Plan Subscription Paymentrequest from testuser', 0, '/admin/manage/deposits/details/16', '2025-10-27 04:57:10', '2025-10-27 04:57:10'),
(12, 1, 'Credit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/1', '2025-10-27 05:00:20', '2025-10-27 05:00:20'),
(13, 1, 'Credit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/2', '2025-10-27 05:01:14', '2025-10-27 05:01:14'),
(14, 1, 'Deposit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/3', '2025-10-27 05:02:28', '2025-10-27 05:02:28'),
(15, 1, 'Deposit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/4', '2025-10-27 05:03:06', '2025-10-27 05:03:06'),
(16, 1, 'Plan Subscription Paymentrequest from testuser', 0, '/admin/manage/deposits/details/5', '2025-10-27 05:04:51', '2025-10-27 05:04:51'),
(17, 1, 'Plan Subscription Paymentrequest from testuser', 0, '/admin/manage/deposits/details/6', '2025-10-27 05:06:11', '2025-10-27 05:06:11'),
(18, 1, 'Plan Subscription Paymentrequest from testuser', 0, '/admin/manage/deposits/details/7', '2025-10-27 06:49:30', '2025-10-27 06:49:30'),
(19, 1, 'Plan Subscription Paymentrequest from testuser', 0, '/admin/manage/deposits/details/8', '2025-10-27 07:09:27', '2025-10-27 07:09:27'),
(20, 1, 'New withdraw request from testuser', 0, '/admin/manage/withdrawals/details/1', '2025-10-27 07:22:10', '2025-10-27 07:22:10'),
(21, 1, 'Plan Subscription Paymentrequest from testuser', 0, '/admin/manage/deposits/details/15', '2025-11-04 02:21:58', '2025-11-04 02:21:58'),
(22, 0, 'A new support ticket has opened ', 0, '/admin/support/ticket/view/8', '2025-11-04 03:12:28', '2025-11-04 03:12:28'),
(23, 0, 'A new support ticket has opened ', 0, '/admin/support/ticket/view/9', '2025-11-05 06:51:06', '2025-11-05 06:51:06'),
(24, 3, 'New member registered', 0, '/admin/manage/users/detail/3', '2025-11-05 09:09:52', '2025-11-05 09:09:52'),
(25, 1, 'Credit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/25', '2025-11-06 04:48:33', '2025-11-06 04:48:33'),
(26, 1, 'Credit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/1', '2025-11-09 03:00:45', '2025-11-09 03:00:45'),
(27, 1, 'Credit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/2', '2025-11-09 03:10:18', '2025-11-09 03:10:18'),
(28, 1, 'Credit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/3', '2025-11-09 03:14:56', '2025-11-09 03:14:56'),
(29, 1, 'Deposit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/4', '2025-11-09 03:19:33', '2025-11-09 03:19:33'),
(30, 1, 'Deposit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/5', '2025-11-09 03:20:28', '2025-11-09 03:20:28'),
(31, 1, 'Deposit Paymentrequest from testuser', 0, '/admin/manage/deposits/details/6', '2025-11-09 03:21:53', '2025-11-09 03:21:53'),
(32, 0, 'A new support ticket has opened ', 0, '/admin/support/ticket/view/10', '2025-11-16 05:00:32', '2025-11-16 05:00:32');

-- --------------------------------------------------------

--
-- Table structure for table `admin_password_resets`
--

CREATE TABLE `admin_password_resets` (
  `id` bigint UNSIGNED NOT NULL,
  `email` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `token` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_password_resets`
--

INSERT INTO `admin_password_resets` (`id`, `email`, `token`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin@example.com', '880076', 0, '2025-07-07 03:21:13', NULL),
(2, 'admin@example.com', '580582', 1, '2025-07-07 03:22:10', NULL),
(3, 'admin@example.com', '191758', 0, '2025-09-13 00:06:04', NULL),
(4, 'admin@example.com', '252380', 1, '2025-09-13 00:25:41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Health & Fitness', 1, '2025-08-30 02:27:44', '2025-08-30 02:30:59'),
(2, 'Travel & Tourism', 1, '2025-08-30 02:27:58', '2025-08-30 02:30:49'),
(3, 'Business', 1, '2025-08-30 02:28:10', '2025-08-30 02:29:33'),
(4, 'Gaming', 1, '2025-08-30 02:28:26', '2025-08-30 02:29:15'),
(5, 'Clothing & Fashion', 1, '2025-08-30 02:31:10', '2025-08-30 02:31:10'),
(6, 'Tech Tips & Tutorials', 1, '2025-08-30 02:31:22', '2025-08-30 02:31:22'),
(7, 'Science & Innovation', 1, '2025-08-30 02:31:31', '2025-08-30 02:31:31'),
(8, 'Food & Cooking', 1, '2025-08-30 02:31:43', '2025-08-30 02:31:43'),
(9, 'Fitness & Gym', 1, '2025-08-30 02:31:50', '2025-08-30 02:31:50'),
(10, 'Photography', 1, '2025-08-30 02:32:29', '2025-08-30 02:32:29'),
(11, 'Personal Blog / Vlog', 1, '2025-08-30 02:32:39', '2025-08-30 02:32:39'),
(12, 'Politics & Current Affairs', 1, '2025-08-30 02:33:00', '2025-08-30 02:33:00'),
(13, 'Tech News', 1, '2025-08-30 02:33:09', '2025-08-30 02:33:09'),
(14, 'Sports', 1, '2025-08-30 02:33:19', '2025-09-04 06:17:02'),
(15, 'Local News', 1, '2025-08-30 02:33:30', '2025-11-04 07:17:09');

-- --------------------------------------------------------

--
-- Table structure for table `deposits`
--

CREATE TABLE `deposits` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL DEFAULT '0',
  `is_credit_purchase` tinyint NOT NULL DEFAULT '0' COMMENT '0 = No , 1 = Yes',
  `number_of_credit` int NOT NULL DEFAULT '0' COMMENT 'when credit purchase user store how many credits are purchase',
  `method_code` int UNSIGNED NOT NULL DEFAULT '0',
  `amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `method_currency` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `rate` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `final_amo` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `detail` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `btc_amo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `btc_wallet` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `trx` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `try` int NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=>success, 2=>pending, 3=>cancel',
  `from_api` tinyint(1) NOT NULL DEFAULT '0',
  `admin_feedback` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `deposits`
--

INSERT INTO `deposits` (`id`, `user_id`, `is_credit_purchase`, `number_of_credit`, `method_code`, `amount`, `method_currency`, `charge`, `rate`, `final_amo`, `detail`, `btc_amo`, `btc_wallet`, `trx`, `try`, `status`, `from_api`, `admin_feedback`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 12, 1003, 40.00000000, '$', 1.60000000, 1.00000000, 241.60000000, '[{\"name\":\"TRX\",\"type\":\"text\",\"value\":\"#AHJSNBS45\"},{\"name\":\"Full Name\",\"type\":\"text\",\"value\":\"Tom Cruse\"},{\"name\":\"Email\",\"type\":\"text\",\"value\":\"testuser@gmail.com\"}]', '0', '', 'HNFFGHMYMTYK', 0, 1, 0, NULL, '2025-01-08 03:00:40', '2025-11-09 03:13:03'),
(2, 1, 1, 10, 1003, 30.00000000, '$', 1.50000000, 1.00000000, 201.50000000, '[{\"name\":\"TRX\",\"type\":\"text\",\"value\":\"#AHJSNBS45\"},{\"name\":\"Full Name\",\"type\":\"text\",\"value\":\"Robert Ban\"},{\"name\":\"Email\",\"type\":\"text\",\"value\":\"testuser@gmail.com\"}]', '0', '', '2X93W7TH6PGO', 0, 1, 0, NULL, '2025-02-12 03:10:12', '2025-11-09 03:13:54'),
(3, 1, 1, 10, 1003, 50.00000000, '$', 1.50000000, 1.00000000, 201.50000000, '[{\"name\":\"TRX\",\"type\":\"text\",\"value\":\"HAFST123#AS\"},{\"name\":\"Full Name\",\"type\":\"text\",\"value\":\"Copila Sama\"},{\"name\":\"Email\",\"type\":\"text\",\"value\":\"testuser@gmail.com\"}]', '0', '', 'TJ6DFAV1AYB6', 0, 1, 0, 'zxcvzvdfsvzf', '2025-03-25 03:14:44', '2025-11-09 03:15:17'),
(4, 1, 0, 0, 1003, 80.00000000, '$', 1.52500000, 1.00000000, 211.52500000, '[{\"name\":\"TRX\",\"type\":\"text\",\"value\":\"AHJSN45#VV\"},{\"name\":\"Full Name\",\"type\":\"text\",\"value\":\"Smith kob\"},{\"name\":\"Email\",\"type\":\"text\",\"value\":\"testuser@gmail.com\"}]', '0', '', 'SOSOFWDVQR34', 0, 1, 0, NULL, '2025-04-15 03:19:26', '2025-11-09 03:19:48'),
(5, 1, 0, 0, 1003, 30.00000000, '$', 1.07500000, 1.00000000, 31.07500000, '[{\"name\":\"TRX\",\"type\":\"text\",\"value\":\"AHJSN45#VV\"},{\"name\":\"Full Name\",\"type\":\"text\",\"value\":\"Bob kuisa\"},{\"name\":\"Email\",\"type\":\"text\",\"value\":\"testuser@gmail.com\"}]', '0', '', 'QOBCZWMQNM1E', 0, 1, 0, NULL, '2025-05-13 03:20:18', '2025-11-09 03:20:56'),
(6, 1, 0, 0, 1003, 90.00000000, '$', 1.12500000, 1.00000000, 90.12500000, '[{\"name\":\"TRX\",\"type\":\"text\",\"value\":\"AHJSN45#VV\"},{\"name\":\"Full Name\",\"type\":\"text\",\"value\":\"Copila Sama\"},{\"name\":\"Email\",\"type\":\"text\",\"value\":\"testuser@gmail.com\"}]', '0', '', '46M8VKRKJ2AW', 0, 1, 0, NULL, '2025-06-03 03:21:45', '2025-11-09 03:22:03'),
(7, 2, 1, 10, 1003, 40.00000000, '$', 1.12500000, 1.00000000, 51.12500000, '[{\"name\":\"TRX\",\"type\":\"text\",\"value\":\"AHJSN45#VV\"},{\"name\":\"Full Name\",\"type\":\"text\",\"value\":\"Copila Sama\"},{\"name\":\"Email\",\"type\":\"text\",\"value\":\"testuser@gmail.com\"}]', '0', '', '46M8VKRKJ2AW', 0, 1, 0, NULL, '2025-07-31 03:21:45', '2025-11-09 03:22:03'),
(8, 2, 1, 10, 1003, 30.00000000, '$', 1.12500000, 1.00000000, 51.12500000, '[{\"name\":\"TRX\",\"type\":\"text\",\"value\":\"AHJSN45#VV\"},{\"name\":\"Full Name\",\"type\":\"text\",\"value\":\"Copila Sama\"},{\"name\":\"Email\",\"type\":\"text\",\"value\":\"testuser@gmail.com\"}]', '0', '', '46M8VKRKJ2AW', 0, 1, 0, NULL, '2025-08-15 03:21:45', '2025-11-09 03:22:03'),
(9, 1, 0, 0, 1003, 40.00000000, '$', 1.12500000, 1.00000000, 51.12500000, '[{\"name\":\"TRX\",\"type\":\"text\",\"value\":\"AHJSN45#VV\"},{\"name\":\"Full Name\",\"type\":\"text\",\"value\":\"Copila Sama\"},{\"name\":\"Email\",\"type\":\"text\",\"value\":\"testuser@gmail.com\"}]', '0', '', '46M8VKRKJ2AW', 0, 1, 0, NULL, '2025-09-13 03:21:45', '2025-11-09 03:22:03'),
(10, 2, 1, 10, 1003, 60.00000000, '$', 1.12500000, 1.00000000, 51.12500000, '[{\"name\":\"TRX\",\"type\":\"text\",\"value\":\"AHJSN45#VV\"},{\"name\":\"Full Name\",\"type\":\"text\",\"value\":\"Copila Sama\"},{\"name\":\"Email\",\"type\":\"text\",\"value\":\"testuser@gmail.com\"}]', '0', '', '46M8VKRKJ2AW', 0, 1, 0, NULL, '2025-10-16 03:21:45', '2025-11-09 03:22:03'),
(11, 2, 1, 10, 1003, 45.00000000, '$', 1.12500000, 1.00000000, 51.12500000, '[{\"name\":\"TRX\",\"type\":\"text\",\"value\":\"AHJSN45#VV\"},{\"name\":\"Full Name\",\"type\":\"text\",\"value\":\"Copila Sama\"},{\"name\":\"Email\",\"type\":\"text\",\"value\":\"testuser@gmail.com\"}]', '0', '', '46M8VKRKJ2AW', 0, 1, 0, NULL, '2025-11-10 03:21:45', '2025-11-09 03:22:03');

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

CREATE TABLE `forms` (
  `id` bigint UNSIGNED NOT NULL,
  `act` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `form_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `forms`
--

INSERT INTO `forms` (`id`, `act`, `form_data`, `created_at`, `updated_at`) VALUES
(2, 'manual_deposit', '{\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"nid_number_22\":{\"name\":\"NID Number 22\",\"label\":\"nid_number_22\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"textarea\"},\"sadfg\":{\"name\":\"sadfg\",\"label\":\"sadfg\",\"is_required\":\"optional\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"asdf\":{\"name\":\"asdf\",\"label\":\"asdf\",\"is_required\":\"required\",\"extensions\":null,\"options\":[\"Test\",\"Test2\",\"Test3\"],\"type\":\"select\"},\"nid_number_226985\":{\"name\":\"NID Number 226985\",\"label\":\"nid_number_226985\",\"is_required\":\"required\",\"extensions\":null,\"options\":[\"Test\",\"Test 2\",\"Test 3\"],\"type\":\"checkbox\"},\"nid_number_3333\":{\"name\":\"NID Number 3333\",\"label\":\"nid_number_3333\",\"is_required\":\"required\",\"extensions\":null,\"options\":[\"Test\",\"asdf\"],\"type\":\"radio\"},\"nid_number_3333587\":{\"name\":\"NID Number 3333587\",\"label\":\"nid_number_3333587\",\"is_required\":\"optional\",\"extensions\":\"jpg,bmp,png,pdf\",\"options\":[],\"type\":\"file\"}}', '2022-03-16 01:09:49', '2022-03-17 00:02:54'),
(3, 'manual_deposit', '{\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"nid_number_226985\":{\"name\":\"NID Number 226985\",\"label\":\"nid_number_226985\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"textarea\"}}', '2022-03-16 04:32:29', '2022-03-16 04:35:32'),
(5, 'withdraw_method', '{\"nid_number_33\":{\"name\":\"NID Number 33\",\"label\":\"nid_number_33\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"textarea\"}}', '2022-03-17 00:45:35', '2022-03-17 00:53:17'),
(6, 'withdraw_method', '{\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"textarea\"}}', '2022-03-17 00:47:04', '2022-03-17 00:47:04'),
(7, 'kyc', '{\"full_name\":{\"name\":\"Full Name\",\"label\":\"full_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"gender\":{\"name\":\"Gender\",\"label\":\"gender\",\"is_required\":\"required\",\"extensions\":null,\"options\":[\"Male\",\"Female\",\"Others\"],\"type\":\"select\"},\"you_hobby\":{\"name\":\"You Hobby\",\"label\":\"you_hobby\",\"is_required\":\"required\",\"extensions\":null,\"options\":[\"Programming\",\"Gardening\",\"Traveling\",\"Others\"],\"type\":\"checkbox\"},\"nid_photo\":{\"name\":\"NID Photo\",\"label\":\"nid_photo\",\"is_required\":\"required\",\"extensions\":\"jpg,png\",\"options\":[],\"type\":\"file\"}}', '2022-03-17 02:56:14', '2025-08-13 02:16:48'),
(8, 'manual_deposit', '{\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2022-03-21 07:53:25', '2022-03-21 07:53:25'),
(9, 'manual_deposit', '{\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2022-03-21 07:54:15', '2022-03-21 07:54:15'),
(10, 'manual_deposit', '{\"nid_number\":{\"name\":\"NID Number\",\"label\":\"nid_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"textarea\"}}', '2022-03-21 07:55:15', '2022-03-21 07:55:22'),
(11, 'withdraw_method', '{\"nid_number_2658\":{\"name\":\"NID Number 2658\",\"label\":\"nid_number_2658\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[\"asdf\"],\"type\":\"checkbox\"}}', '2022-03-22 00:14:09', '2022-03-22 00:14:18'),
(12, 'withdraw_method', '[]', '2022-03-30 09:03:12', '2022-03-30 09:03:12'),
(13, 'withdraw_method', '{\"recipient_full_name\":{\"name\":\"Recipient Full Name\",\"label\":\"recipient_full_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"bank_name\":{\"name\":\"Bank Name\",\"label\":\"bank_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"account_number\":{\"name\":\"Account Number\",\"label\":\"account_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"email_for_confirmation\":{\"name\":\"Email for Confirmation\",\"label\":\"email_for_confirmation\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2022-03-30 09:09:11', '2025-09-21 07:25:23'),
(14, 'withdraw_method', '{\"mobile_banking_provider\":{\"name\":\"Mobile Banking Provider\",\"label\":\"mobile_banking_provider\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"account_name\":{\"name\":\"Account Name\",\"label\":\"account_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"mobile_banking_number\":{\"name\":\"Mobile Banking Number\",\"label\":\"mobile_banking_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2022-03-30 09:10:12', '2025-09-21 07:25:04'),
(15, 'manual_deposit', '{\"send_from_number\":{\"name\":\"Send From Number\",\"label\":\"send_from_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"transaction_number\":{\"name\":\"Transaction Number\",\"label\":\"transaction_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"screenshot\":{\"name\":\"Screenshot\",\"label\":\"screenshot\",\"is_required\":\"required\",\"extensions\":\"jpg,jpeg,png\",\"options\":[],\"type\":\"file\"}}', '2022-03-30 09:15:27', '2022-03-30 09:15:27'),
(16, 'manual_deposit', '{\"transaction_number\":{\"name\":\"Transaction Number\",\"label\":\"transaction_number\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"screenshot\":{\"name\":\"Screenshot\",\"label\":\"screenshot\",\"is_required\":\"required\",\"extensions\":\"jpg,pdf,docx\",\"options\":[],\"type\":\"file\"}}', '2022-03-30 09:16:43', '2022-04-11 03:19:54'),
(17, 'manual_deposit', '[]', '2022-03-30 09:21:19', '2022-03-30 09:21:19'),
(18, 'manual_deposit', '{\"asdfasddf\":{\"name\":\"asdfasddf\",\"label\":\"asdfasddf\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2022-09-28 04:50:55', '2022-09-28 04:50:55'),
(19, 'manual_deposit', '{\"sadf\":{\"name\":\"sadf\",\"label\":\"sadf\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"textarea\"}}', '2022-09-28 05:13:04', '2022-09-28 05:13:59'),
(20, 'manual_deposit', '{\"transaction_id\":{\"name\":\"Transaction ID\",\"label\":\"transaction_id\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2023-05-27 02:50:43', '2023-05-27 02:50:43'),
(21, 'manual_deposit', '{\"depositor_full_name\":{\"name\":\"Depositor Full Name\",\"label\":\"depositor_full_name\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"bank_name\":{\"name\":\"Bank Name\",\"label\":\"bank_name\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"account_number\":{\"name\":\"Account Number\",\"label\":\"account_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"transfer_reference_code\":{\"name\":\"Transfer Reference Code\",\"label\":\"transfer_reference_code\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"deposit_amount\":{\"name\":\"Deposit Amount\",\"label\":\"deposit_amount\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2025-06-28 07:50:58', '2025-09-21 07:23:28'),
(22, 'manual_deposit', '{\"sender_name\":{\"name\":\"Sender Name\",\"label\":\"sender_name\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"mobile_money_number\":{\"name\":\"Mobile Money Number\",\"label\":\"mobile_money_number\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"transaction_reference_id\":{\"name\":\"Transaction Reference ID\",\"label\":\"transaction_reference_id\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"amount_sent\":{\"name\":\"Amount Sent\",\"label\":\"amount_sent\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"email_for_notification\":{\"name\":\"Email for Notification\",\"label\":\"email_for_notification\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2025-06-29 03:30:31', '2025-09-21 07:21:49'),
(23, 'manual_deposit', '{\"payer_full_name\":{\"name\":\"Payer Full Name\",\"label\":\"payer_full_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"transaction_id\":{\"name\":\"Transaction ID\",\"label\":\"transaction_id\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"cash_amount\":{\"name\":\"Cash Amount\",\"label\":\"cash_amount\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"branch_name\":{\"name\":\"Branch Name\",\"label\":\"branch_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"email_for_notification\":{\"name\":\"Email for Notification\",\"label\":\"email_for_notification\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2025-06-29 03:32:11', '2025-09-21 07:24:06'),
(24, 'withdraw_method', '{\"account_holder_name\":{\"name\":\"Account Holder Name\",\"label\":\"account_holder_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"bank_name\":{\"name\":\"Bank Name\",\"label\":\"bank_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"branch_code\":{\"name\":\"Branch Code\",\"label\":\"branch_code\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"account_number\":{\"name\":\"Account Number\",\"label\":\"account_number\",\"is_required\":\"optional\",\"extensions\":null,\"options\":[],\"type\":\"text\"},\"email_for_confirmation\":{\"name\":\"Email for Confirmation\",\"label\":\"email_for_confirmation\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2025-06-29 04:40:12', '2025-09-21 07:24:39'),
(25, 'manual_deposit', '{\"trx\":{\"name\":\"TRX\",\"label\":\"trx\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"full_name\":{\"name\":\"Full Name\",\"label\":\"full_name\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"},\"email\":{\"name\":\"Email\",\"label\":\"email\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2025-08-13 02:19:06', '2025-10-26 06:37:11'),
(26, 'withdraw_method', '{\"full_name\":{\"name\":\"Full Name\",\"label\":\"full_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2025-10-02 03:39:46', '2025-10-02 03:51:05'),
(27, 'withdraw_method', '{\"education\":{\"name\":\"Education\",\"label\":\"education\",\"is_required\":\"required\",\"extensions\":\"\",\"options\":[],\"type\":\"text\"}}', '2025-10-02 03:51:41', '2025-10-02 03:51:41'),
(28, 'manual_deposit', '{\"full_name\":{\"name\":\"Full Name\",\"label\":\"full_name\",\"is_required\":\"required\",\"extensions\":null,\"options\":[],\"type\":\"text\"}}', '2025-10-02 04:00:36', '2025-10-02 04:01:00');

-- --------------------------------------------------------

--
-- Table structure for table `frontends`
--

CREATE TABLE `frontends` (
  `id` bigint UNSIGNED NOT NULL,
  `data_keys` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `data_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `frontends`
--

INSERT INTO `frontends` (`id`, `data_keys`, `data_values`, `created_at`, `updated_at`) VALUES
(1, 'seo.data', '{\"seo_image\":\"1\",\"keywords\":[\"website\",\"AI\",\"logo\",\"logo maker\",\"AI Prompt\"],\"description\":\"Create stunning brand logos effortlessly with our AI-powered logo maker. Design professional, unique, and memorable logos in minutes\\u2014no design skills required. Customize colors, fonts, and icons to match your brand identity perfectly. Boost your business presence with a logo that truly stands out.\",\"social_title\":\"Design Your Perfect Brand Logo in Minutes with Our Smart AI Logo Maker \\u2014 Fast, Creative, and Professional\",\"social_description\":\"Bring your brand vision to life with our AI-powered logo maker. Whether you\\u2019re launching a startup or rebranding your business, create a professional-quality logo in just minutes. Choose from thousands of templates, customize colors, icons, and fonts to reflect your identity, and download instantly. No design experience needed\\u2014just your imagination. Stand out from the competition with a logo that defines your story and connects with your audience.\",\"image\":\"690a0173ec6551762263411.png\"}', '2020-07-04 23:42:52', '2025-11-04 07:39:46'),
(24, 'about.content', '{\"title\":\"Who We Are\",\"heading\":\"Can I track form submissions in real-time?\",\"subheading\":\"Streamline data collection, automate workflows, and gain real-time insights effortlessly\",\"has_image\":\"1\",\"image\":\"68fe06c2270f71761478338.png\"}', '2020-10-28 00:51:20', '2025-10-26 05:32:18'),
(25, 'blog.content', '{\"title\":\"Blog Post\",\"heading\":\"Insights and Tips From Our Experts\",\"subheading\":\"Stay updated with the latest trends, tutorials, and best practices for forms and analytics\"}', '2020-10-28 00:51:34', '2025-10-23 07:35:59'),
(26, 'blog.element', '{\"has_image\":[\"1\"],\"title\":\"How Real-Time Feedback Transforms Customer Experience\",\"quote\":\"\\u201cReal-time feedback turns customer voices into immediate action. When businesses listen instantly, they don\\u2019t just collect data \\u2014 they build trust, loyalty, and lasting relationships that define their long-term success.\\u201d\",\"description\":\"<p>Real-time feedback is revolutionizing how companies understand and serve their customers. By using instant survey systems, brands can immediately capture user opinions during or after an interaction \\u2014 whether it\\u2019s a product purchase, a service experience, or a digital engagement.<br \\/>This approach eliminates delays in decision-making, allowing businesses to respond faster and more effectively. A customer reporting an issue can receive help within minutes, not days, creating a sense of trust and satisfaction. Moreover, analytics dashboards connected to these live survey systems allow managers to monitor performance trends and identify improvement areas instantly.<br \\/>With the growing demand for personalized experiences, real-time surveys help brands tailor their services according to customer needs and expectations.<\\/p><ul><li>Captures customer opinions instantly during interactions.<\\/li><li>Enables immediate response to service or product issues.<\\/li><li>Builds strong customer trust and loyalty.<\\/li><li>Uses analytics dashboards for live performance tracking.<\\/li><li>Turns feedback into a real-time communication bridge.<\\/li><\\/ul><p>This makes feedback not just a formality but a dynamic communication bridge between the brand and its audience.<br \\/>In essence, the faster a company listens, the better it performs.<\\/p>\",\"blog_image\":\"690b2c6a2facb1762339946.jpg\"}', '2020-10-28 00:57:19', '2025-11-05 04:52:26'),
(27, 'contact_us.content', '{\"heading\":\"Got Questions? We\\u2019ve Got Answers\",\"short_description\":\"Create your perfect kit effortlessly with kitme\'s AI kit logo maker. No design skills required\",\"button_text\":\"Send Message\",\"footer_short_details\":\"Empowering smarter decisions through modern, data-driven, and interactive online form builder.\",\"email_address\":\"admin@test.com\",\"contact_details\":\"Innovation City, USA\",\"contact_number\":\"9876897689698\",\"support_number\":\"24\\/7 Expert Support Team\",\"website_footer\":\"<p>Copyright 2025. All rights reserved.<\\/p>\"}', '2020-10-28 00:59:19', '2025-11-05 06:38:08'),
(28, 'counter.content', '{\"heading\":\"Clients\",\"subheading\":\"Auctor gravida vestibulu\"}', '2020-10-28 01:04:02', '2022-09-28 14:02:14'),
(31, 'social_icon.element', '{\"title\":\"Facebook\",\"social_icon\":\"<i class=\\\"fab fa-facebook-f\\\"><\\/i>\",\"url\":\"https:\\/\\/facebook.com\"}', '2020-11-12 04:07:30', '2025-10-23 06:55:11'),
(33, 'feature.content', '{\"title\":\"Key Features\",\"heading\":\"Everything You Need in One Platform\",\"subheading\":\"Build smarter forms and unlock insights without switching platforms.\"}', '2021-01-03 23:40:54', '2025-10-23 00:46:21'),
(34, 'feature.element', '{\"heading\":\"Generate a premium brand kit with AI\",\"description\":\"<p>Build professional forms effortlessly with our intuitive drag &amp; drop interface. \\u00a0No coding skills required \\u2014 just your imagination and a few clicks!<\\/p><ul><li>Add fields instantly with simple dragging<\\/li><li>Customize layouts, labels, and styles easily<\\/li><li>Preview and publish your forms instantly<\\/li><\\/ul>\",\"button\":\"Get started for free\",\"has_image\":[\"1\"],\"image\":\"690b3cb906a8d1762344121.png\"}', '2021-01-03 23:41:02', '2025-11-05 06:02:01'),
(35, 'feature.element', '{\"heading\":\"Build your interface easily using modular and customizable components.\",\"description\":\"<p>Everything is designed to be flexible, editable, and reusable \\u2014 no coding required.<\\/p><ul><li>Drag and drop to edit instantly<\\/li><li>Fully responsive across all devices<\\/li><li>Save and reuse components easily<\\/li><\\/ul>\",\"button\":\"Get started for free\",\"has_image\":[\"1\"],\"image\":\"690b3cc247bf21762344130.png\"}', '2021-03-06 01:12:10', '2025-11-05 06:02:10'),
(36, 'feature.element', '{\"heading\":\"Instant Sharing Made Simple\",\"description\":\"<p>Easily distribute your content with just a single link. No attachments, no hassle \\u2014 just copy, share, and connect instantly.<\\/p><ul><li>One-click link generation<\\/li><li>Secure and trackable sharing<\\/li><li>Works across all devices and platforms<\\/li><\\/ul>\",\"button\":\"Get started for free\",\"has_image\":[\"1\"],\"image\":\"690b3cccb43091762344140.png\"}', '2021-03-06 01:27:34', '2025-11-05 06:02:20'),
(39, 'banner.content', '{\"heading\":\"Design Your Stunning Brand Logo With AI\",\"subheading\":\"Create powerful forms in minutes and get real-time insights to boost your conversions\"}', '2021-05-02 06:09:30', '2025-11-04 08:47:42'),
(41, 'cookie.data', '{\"short_desc\":\"We use cookies to enhance your browsing experience, serve personalized ads or content, and analyze our traffic. By clicking \\\"Accept\\\", you consent to our use of cookies.\",\"description\":\"<h4><strong>Introduction<\\/strong><\\/h4><p>Brandify uses cookies to improve your experience and ensure the proper functioning of our website. This Cookie Policy explains what cookies are, how we use them, and how you can manage or disable them based on your preferences.<\\/p><h4><strong>What Are Cookies<\\/strong><\\/h4><p>We use cookies to enhance your browsing experience, ensure security, and personalize the tools and design services we offer through Brandify. Cookies allow us to:<\\/p><ul><li>Remember your preferences, such as selected themes, color palettes, and saved logo drafts.<\\/li><li>Maintain your login session so you don\\u2019t need to re-enter your credentials every time.<\\/li><li>Analyze user behavior to enhance performance and usability.<\\/li><\\/ul><p>Cookies are small text files stored on your device when you visit our site. They do not provide access to your computer or personal data beyond what you choose to share.<\\/p><h4><strong>How We Use Cookies<\\/strong><\\/h4><p>We use cookies to enhance functionality and improve your overall experience with Brandify. Cookies help us:<\\/p><ul><li>Remember your login and customization settings.<\\/li><li>Analyze how users interact with our platform and design tools.<\\/li><li>Personalize templates, recommendations, and design suggestions.<\\/li><li>Ensure secure sessions while you create and manage your logos.<\\/li><li>By using cookies, we make sure Brandify runs smoothly and delivers a tailored design experience.<\\/li><\\/ul><h4><strong>Sharing Information Collected by Cookies<\\/strong><\\/h4><p>We may share cookie-based information with trusted third parties, such as:<\\/p><ul><li>Hosting providers, analytics services, and performance monitoring tools.<\\/li><li>Marketing and advertising partners (only with your explicit consent).<\\/li><li>Legal or regulatory authorities, if required to comply with applicable laws.<\\/li><li>We <strong>never sell or rent<\\/strong> cookie-related data to third parties.<\\/li><\\/ul><h4><strong>Types of Cookies We Use<\\/strong><\\/h4><ul><li>Required for the platform to function (e.g., secure login, navigation).<\\/li><li>Help us understand usage patterns and improve system performance.<\\/li><li>Remember your saved settings, such as preferred logo styles or colors.<\\/li><li>Track design interactions to make Brandify smarter and more intuitive.<\\/li><\\/ul><h4><strong>Third-Party Cookies<\\/strong><\\/h4><ul><li>Some third-party tools (like analytics or social media integrations) may set their own cookies on your device.<br>We do not control these cookies, but you can manage or disable them anytime through your browser settings.<\\/li><\\/ul><h4><strong>Your Privacy Rights<\\/strong><\\/h4><p>As part of GDPR, CCPA, and other privacy standards, you have the right to:<\\/p><ul><li>Access, update, or delete cookie-related data.<\\/li><li>Opt out of analytics or marketing cookies at any time.<\\/li><li>Request details on how your data is used and shared.<\\/li><li>Withdraw consent without affecting the legality of prior usage.<\\/li><\\/ul><h4><strong>Managing Cookies<\\/strong><\\/h4><p>You can accept, refuse, or delete cookies through your browser or device settings. Please note that disabling certain cookies may affect the performance or availability of some Brandify features.<\\/p><h4><strong>Updates to This Policy<\\/strong><\\/h4><ul><li>We may update this Cookie Policy from time to time.<br>Any updates will be posted on this page with a revised date at the top.<\\/li><\\/ul><h4><strong>Contact Us<\\/strong><\\/h4><p>If you have any questions about this Cookie Policy, please contact us:<\\/p><p>\\ud83d\\udce7 <strong>Email:<\\/strong> support@brandify.com<br>\\ud83d\\udcde <strong>Phone:<\\/strong> +1-800-432-9876<br>\\ud83c\\udfe2 <strong>Address:<\\/strong> 101 Creative Avenue, Innovation City, NY 10005, USA<\\/p>\",\"status\":1}', '2020-07-04 23:42:52', '2025-11-15 05:49:06'),
(42, 'policy_pages.element', '{\"title\":\"Privacy Policy\",\"details\":\"<h4><strong>Introduction<\\/strong><\\/h4><p>At <strong>Brandify<\\/strong>, we value your privacy and are committed to protecting your personal information. This Privacy Policy explains how we collect, use, and safeguard your data when you use our AI-powered logo design platform. By accessing or using Brandify, you agree to the terms described below.<\\/p><h4><strong>Information We Collect<\\/strong><\\/h4><p>We may collect the following types of information when you use Brandify:<\\/p><ul><li><strong>Account Details:<\\/strong> Your name, email address, and password when you register or log in.<\\/li><li><strong>Design Activity:<\\/strong> Logos, color schemes, and branding preferences you create or upload.<\\/li><li><strong>Usage Data:<\\/strong> Information about your interactions with the platform, such as device type, browser, IP address, and session history.<\\/li><li><strong>Payment Information:<\\/strong> If you purchase premium features, we securely collect billing and payment details through trusted third-party payment processors.<\\/li><\\/ul><h4><strong>How We Use Your Information<\\/strong><\\/h4><p>We use your information to:<\\/p><ul><li>Provide and maintain Brandify\\u2019s logo design services efficiently.<\\/li><li>Store your designs, templates, and customization history securely.<\\/li><li>Improve AI logo recommendations and enhance user experience.<\\/li><li>Send updates, support responses, and service-related notifications.<\\/li><li>Prevent unauthorized access, fraud, or misuse of the platform.<\\/li><li>Process payments and manage subscription plans.<\\/li><li>We <strong>never sell or rent<\\/strong> your personal data to third parties.<\\/li><\\/ul><h4><strong>Data Security<\\/strong><\\/h4><ul><li>We use <strong>industry-standard encryption<\\/strong> and secure servers to protect your information. Access to your data is limited to authorized personnel who are required to keep your information confidential.<\\/li><li>However, no online service can guarantee 100% security. By using Brandify, you acknowledge and accept that data transmission over the internet carries some risk.<\\/li><\\/ul><h4><strong>Cookies and Tracking<\\/strong><\\/h4><p>Brandify uses cookies to:<\\/p><ul><li>Remember your login sessions and design preferences.<\\/li><li>Analyze platform performance and optimize your experience.<\\/li><li>Personalize logo templates and AI suggestions.<\\/li><li>You can disable cookies in your browser settings, but this may limit some platform functionalities.<\\/li><\\/ul><h4><strong>Data Sharing<\\/strong><\\/h4><p>We may share limited information with trusted third parties, such as:<\\/p><ul><li>Hosting, analytics, and payment service providers.<\\/li><li>Legal or regulatory authorities, if required by law.<\\/li><li>All third parties are <strong>contractually obligated<\\/strong> to protect your information and comply with this Privacy Policy.<\\/li><\\/ul><h4><strong>User Rights<\\/strong><\\/h4><p>As a Brandify user, you have the right to:<\\/p><ul><li>Access, correct, or delete your personal data.<\\/li><li>Withdraw consent for data processing at any time.<\\/li><li>Request a copy of your stored information by contacting our support team.<\\/li><\\/ul><h4><strong>Account Deletion<\\/strong><\\/h4><ul><li>You can delete your Brandify account at any time.<br \\/>Once deleted, your account data, logo designs, and project history will be <strong>permanently removed<\\/strong> from our servers within a reasonable timeframe.<\\/li><\\/ul><h4><strong>Changes to This Policy<\\/strong><\\/h4><ul><li>We may update this Privacy Policy periodically to reflect new features, compliance updates, or improved security measures.<br \\/>Any updates will be posted on this page with an updated <strong>\\u201cLast Revised\\u201d<\\/strong> date. Continued use of Brandify after updates means you accept the new policy terms.<\\/li><\\/ul><h4><strong>Contact Us<\\/strong><\\/h4><p>If you have any questions or concerns about this Privacy Policy, please contact us:<\\/p><p>\\ud83d\\udce7 <strong>Email:<\\/strong> support@brandify.com<br \\/>\\ud83d\\udcde <strong>Phone:<\\/strong> +1-800-432-9876<br \\/>\\ud83c\\udfe2 <strong>Address:<\\/strong> 101 Creative Avenue, Innovation City, NY 10005, USA<\\/p>\"}', '2021-06-09 08:50:42', '2025-11-15 05:50:46'),
(43, 'policy_pages.element', '{\"title\":\"Terms of Service\",\"details\":\"<h4><strong>Introduction<\\/strong><\\/h4><p>At <strong>Brandify<\\/strong>, we are dedicated to providing a secure, creative, and reliable platform for designing professional logos using artificial intelligence. By accessing or using our platform, you agree to comply with the following Terms of Service.<br \\/>Please read these terms carefully, as they outline your rights, responsibilities, and limitations while using Brandify.<\\/p><h4><strong>Acceptance of Terms<\\/strong><\\/h4><ul><li>By creating an account, accessing, or using Brandify, you confirm that you have read, understood, and agreed to these Terms of Service and our Privacy Policy.<br \\/>If you do not agree with these terms, you should discontinue using our platform immediately.<\\/li><\\/ul><h4><strong>User Accounts<\\/strong><\\/h4><p>To access premium features of Brandify, you may need to create an account. You agree to:<\\/p><ul><li>Provide accurate, up-to-date registration details.<\\/li><li>Keep your account credentials confidential.<\\/li><li>Notify us immediately of any unauthorized access or suspicious activity.<\\/li><li>Take full responsibility for all actions performed under your account.<\\/li><li>Brandify is not liable for any losses resulting from unauthorized use of your account due to your failure to maintain security.<\\/li><\\/ul><h4><strong>Use of the Platform<\\/strong><\\/h4><p>You agree to use Brandify responsibly and in compliance with all applicable laws and regulations. You must not:<\\/p><ul><li>Use the platform for illegal, fraudulent, or harmful purposes.<\\/li><li>Upload, generate, or share offensive, misleading, or copyrighted materials without authorization.<\\/li><li>Attempt to hack, disrupt, or manipulate the platform\\u2019s code or data.<\\/li><li>Misuse Brandify for sending spam or engaging in automated scraping.<\\/li><li>Brandify reserves the right to suspend or terminate accounts found violating these terms.<\\/li><\\/ul><h4><strong>Designs, Data, and Ownership<\\/strong><\\/h4><ul><li>You retain full ownership of all <strong>logos, designs, and creative assets<\\/strong> generated through Brandify.<br \\/>However, by using our platform, you grant us a limited, non-exclusive, royalty-free license to host, store, and process your designs solely for the purpose of operating and improving Brandify.<\\/li><li>All AI tools, code, design algorithms, and brand templates remain the exclusive property of <strong>Brandify<\\/strong> and are protected under intellectual property laws.<\\/li><\\/ul><h4><strong>Data Usage and Privacy<\\/strong><\\/h4><ul><li>Brandify collects limited data (such as account details, design activity, and usage analytics) to improve the platform experience.<br \\/>We are committed to protecting your data and handling it in accordance with our <strong>Privacy Policy<\\/strong>.<br \\/>We do <strong>not sell, rent, or trade<\\/strong> your personal information with third parties.<\\/li><\\/ul><h4><strong>Payments and Subscriptions<\\/strong><\\/h4><p>If you purchase premium logo packages or design credits, you agree to:<\\/p><ul><li>Provide valid payment and billing information.<\\/li><li>Allow us to process authorized payments securely via trusted payment providers.<\\/li><li>Understand that all payments are non-refundable, except as required by law.<\\/li><li>Subscriptions may <strong>renew automatically<\\/strong> unless canceled before the renewal date.<br \\/>You can manage or cancel your subscription anytime from your account dashboard.<\\/li><\\/ul><h4><strong>Limitation of Liability<\\/strong><\\/h4><ul><li>Brandify is provided on an <strong>\\u201cas-is\\u201d and \\u201cas-available\\u201d<\\/strong> basis.<br \\/>We strive for reliability but do not guarantee uninterrupted or error-free service.<\\/li><li>Brandify shall not be held responsible for:<\\/li><li>Direct, indirect, or incidental damages arising from your use of the platform.<\\/li><li>Loss of logo files or project data due to technical or user errors.<\\/li><li>Unauthorized access, service interruptions, or system downtime.<\\/li><li>You are encouraged to <strong>download and back up your designs<\\/strong> regularly.<\\/li><\\/ul><h4><strong>Termination of Service<\\/strong><\\/h4><p>We reserve the right to suspend or terminate your access if you:<\\/p><ul><li>Violate these Terms of Service.<\\/li><li>Engage in fraudulent, abusive, or harmful behavior.<\\/li><li>Attempt to compromise platform integrity or user data.<\\/li><li>Upon termination, your account access will be revoked, and your data may be deleted in accordance with our data retention policy.<\\/li><\\/ul><h4><strong>Governing Law<\\/strong><\\/h4><ul><li>These Terms of Service are governed by the laws of the jurisdiction in which <strong>Brandify<\\/strong> operates.<br \\/>Any disputes arising from these terms shall be resolved through the appropriate legal channels within that jurisdiction.<\\/li><\\/ul><h4><strong>Changes to These Terms<\\/strong><\\/h4><ul><li>Brandify may update these Terms of Service from time to time to reflect new features, compliance changes, or updated business practices.<br \\/>You will be notified of significant updates via email or in-app notice.<br \\/>Continued use of the platform after such updates constitutes your acceptance of the revised terms.<\\/li><\\/ul><h4><strong>Contact Us<\\/strong><\\/h4><p>If you have any questions, concerns, or feedback regarding these Terms of Service, please contact us:<\\/p><p>\\ud83d\\udce7 <strong>Email:<\\/strong> support@brandify.com<br \\/>\\ud83d\\udcde <strong>Phone:<\\/strong> +1-800-432-9876<br \\/>\\ud83c\\udfe2 <strong>Address:<\\/strong> 101 Creative Avenue, Innovation City, NY 10005, USA<\\/p>\"}', '2021-06-09 08:51:18', '2025-11-15 05:53:44'),
(44, 'maintenance.data', '{\"description\":\"<h4>We\'ll Be Back Soon!<\\/h4><p>&nbsp;<\\/p><p>Thank you for visiting our website. We are currently performing scheduled maintenance to improve your experience.&nbsp;We appreciate your patience and understanding. If you need immediate assistance, please contact us at info@arsignal.com.&nbsp;Thank you for your support!<\\/p>\"}', '2020-07-04 23:42:52', '2025-06-28 02:39:26'),
(52, 'blog.element', '{\"has_image\":[\"1\"],\"title\":\"Form Builder with AI The Next Step in Research Innovation\",\"quote\":\"\\u201cAI isn\\u2019t replacing surveys \\u2014 it\\u2019s revolutionizing them. Smart systems now turn responses into insights faster, helping organizations make intelligent, data-driven decisions like never before.\\u201d\",\"description\":\"<p>Artificial Intelligence is transforming the way surveys are created, distributed, and analyzed. Traditional surveys relied heavily on manual setup and human interpretation, but AI-driven platforms now automate everything \\u2014 from question optimization to predictive response analysis.<br \\/>With intelligent algorithms, surveys can adapt dynamically based on respondent behavior, ensuring higher engagement and accuracy. AI tools like sentiment analysis, keyword extraction, and automated summaries allow researchers to uncover deep insights within minutes.<br \\/>Moreover, AI helps eliminate bias and improve data reliability, making survey outcomes more trustworthy. For businesses and researchers, this means faster results, deeper understanding, and smarter decision-making powered by machine intelligence. Moreover, analytics dashboards connected to these live survey systems allow managers to monitor performance trends and identify improvement areas instantly.<\\/p><ul><li>Uses AI to automate and enhance survey performance<\\/li><li>Adapts questions in real-time for better engagement<\\/li><li>Provides instant insights with sentiment and keyword analysis<\\/li><li>Reduces human bias and improves accuracy<\\/li><li>Saves time and boosts productivity in research<\\/li><li>Enhances decision-making with predictive analytics<\\/li><\\/ul><p>\\u00a0With the growing demand for personalized experiences, real-time surveys help brands tailor their services according to customer needs and expectations.<\\/p>\",\"blog_image\":\"68fdefc96d9871761472457.jpg\"}', '2023-03-21 08:45:08', '2025-11-04 02:46:15'),
(53, 'service.element', '{\"heading\":\"Generate a premium brand kit with AI\",\"subheading\":\"Create your perfect kit effortlessly with kits AI kit maker. No design skill\",\"has_image\":\"1\",\"image\":\"690b0c5e831861762331742.png\"}', '2025-07-15 03:30:30', '2025-11-05 02:35:44'),
(65, 'social_icon.element', '{\"title\":\"x.com\",\"social_icon\":\"<i class=\\\"fa-brands fa-x-twitter\\\"><\\/i>\",\"url\":\"https:\\/\\/x.com\\/home\"}', '2025-09-24 03:53:00', '2025-10-23 06:55:25'),
(66, 'social_icon.element', '{\"title\":\"Instagram\",\"social_icon\":\"<i class=\\\"fab fa-instagram\\\"><\\/i>\",\"url\":\"https:\\/\\/instragram.com\"}', '2025-09-24 03:53:31', '2025-10-23 06:55:48'),
(67, 'social_icon.element', '{\"title\":\"LinkedIn\",\"social_icon\":\"<i class=\\\"fab fa-linkedin-in\\\"><\\/i>\",\"url\":\"https:\\/\\/www.linkedin.com\\/\"}', '2025-09-24 03:53:50', '2025-10-23 06:56:06'),
(68, 'brand.content', '{\"heading\":\"Join 10,000+ Teams Achieving Goals Efficiently\"}', '2025-10-23 00:41:44', '2025-10-23 00:41:44'),
(69, 'brand.element', '{\"has_image\":\"1\",\"brand_image\":\"68f9ce371d07e1761201719.png\"}', '2025-10-23 00:41:59', '2025-10-23 00:41:59'),
(70, 'brand.element', '{\"has_image\":\"1\",\"brand_image\":\"68f9ce41c6b0c1761201729.png\"}', '2025-10-23 00:42:09', '2025-10-23 00:42:09'),
(71, 'brand.element', '{\"has_image\":\"1\",\"brand_image\":\"68f9ce4a712151761201738.png\"}', '2025-10-23 00:42:18', '2025-10-23 00:42:18'),
(72, 'brand.element', '{\"has_image\":\"1\",\"brand_image\":\"68f9ce5f941091761201759.png\"}', '2025-10-23 00:42:39', '2025-10-23 00:42:39'),
(73, 'brand.element', '{\"has_image\":\"1\",\"brand_image\":\"68f9ce649bae51761201764.png\"}', '2025-10-23 00:42:44', '2025-10-23 00:42:44'),
(75, 'how_it_work.content', '{\"title\":\"How It Works\",\"heading\":\"How Our Platform Works\",\"subheading\":\"Build smarter forms and unlock insights without switching platforms.\"}', '2025-10-23 02:57:38', '2025-10-23 02:57:38'),
(76, 'how_it_work.element', '{\"heading\":\"Create form\",\"subheading\":\"Design professional and engaging forms in minutes. Use drag-and-drop tools to customize every question with ease.\"}', '2025-10-23 02:57:53', '2025-10-23 03:03:40'),
(77, 'how_it_work.element', '{\"heading\":\"Share Link\",\"subheading\":\"Instantly share your form with anyone, anywhere. Generate a unique link or embed it directly on your website.\"}', '2025-10-23 02:58:12', '2025-10-23 03:03:53'),
(78, 'how_it_work.element', '{\"heading\":\"Analyze\",\"subheading\":\"Track real-time responses with detailed insights. Make smarter decisions using visual analytics and reports.\"}', '2025-10-23 03:04:11', '2025-10-23 03:04:11'),
(79, 'use_cases.content', '{\"title\":\"Use Cases\",\"heading\":\"Empowering Businesses with Smarter Forms\",\"subheading\":\"Streamline data collection, automate workflows, and gain real-time insights effortlessly\",\"has_image\":\"1\",\"image\":\"68fa0039af3981761214521.png\"}', '2025-10-23 03:50:19', '2025-10-23 04:15:21'),
(80, 'use_cases.element', '{\"title\":\"Marketing Campaigns\",\"icon\":\"<i class=\\\"fas fa-rocket\\\"><\\/i>\",\"has_image\":[\"1\"],\"image\":\"68f9fbff9939a1761213439.png\"}', '2025-10-23 03:52:00', '2025-10-23 03:57:19'),
(81, 'use_cases.element', '{\"title\":\"Lead Generation\",\"icon\":\"<i class=\\\"fas fa-magnet\\\"><\\/i>\",\"has_image\":[\"1\"],\"image\":\"68f9faf8068051761213176.png\"}', '2025-10-23 03:52:56', '2025-10-23 03:52:56'),
(82, 'use_cases.element', '{\"title\":\"Premium Quality Survey Solutions\",\"icon\":\"<i class=\\\"fas fa-calendar-check\\\"><\\/i>\",\"has_image\":[\"1\"],\"image\":\"68f9fb13576f71761213203.png\"}', '2025-10-23 03:53:23', '2025-10-23 03:53:23'),
(83, 'use_cases.element', '{\"title\":\"Surveys And Feedback\",\"icon\":\"<i class=\\\"fas fa-list\\\"><\\/i>\",\"has_image\":[\"1\"],\"image\":\"68f9fc09088191761213449.png\"}', '2025-10-23 03:53:57', '2025-10-23 03:57:29'),
(84, 'use_cases.element', '{\"title\":\"Job Application\",\"icon\":\"<i class=\\\"fas fa-users\\\"><\\/i>\",\"has_image\":[\"1\"],\"image\":\"68f9fb57f1cdd1761213271.png\"}', '2025-10-23 03:54:31', '2025-10-23 03:54:32'),
(85, 'pricing.content', '{\"title\":\"Pricing\",\"heading\":\"Everything You Need in One Platform\",\"subheading\":\"Build smarter forms and unlock insights without switching platforms.\"}', '2025-10-23 04:47:12', '2025-10-23 04:47:12'),
(86, 'faq.content', '{\"title\":\"Faq\",\"heading\":\"Can I track form submissions in real-time?\",\"subheading\":\"Our analytics dashboard provides live updates on submissions, conversion rates, and drop-offs\",\"has_image\":\"1\",\"image\":\"68fa229d304321761223325.png\"}', '2025-10-23 06:38:36', '2025-10-23 06:42:05'),
(87, 'faq.element', '{\"question\":\"Do I need coding skills to create forms?\",\"answer\":\"<p>Our analytics dashboard provides live updates on submissions, conversion rates, and drop-offs<\\/p>\"}', '2025-10-23 06:38:46', '2025-10-23 06:38:46'),
(88, 'faq.element', '{\"question\":\"Can I integrate forms with third-party apps?\",\"answer\":\"<p>Yes, you can connect forms to popular tools like Zapier, Slack, and Google Sheets.<\\/p>\"}', '2025-10-23 06:39:22', '2025-10-23 06:39:22'),
(89, 'faq.element', '{\"question\":\"Can I customize the form design?\",\"answer\":\"<p>Absolutely! You can customize colors, fonts, and layouts easily.<\\/p>\"}', '2025-10-23 06:39:56', '2025-10-23 06:39:56'),
(90, 'faq.element', '{\"question\":\"Is there a way to collect payments?\",\"answer\":\"<p>Yes, our forms can be integrated with payment gateways like Stripe and PayPal.<\\/p>\"}', '2025-10-23 06:40:10', '2025-10-23 06:40:10'),
(91, 'faq.element', '{\"question\":\"Is there a limit on form submissions?\",\"answer\":\"<p>The free plan has a monthly limit, while premium plans allow unlimited submissions.<\\/p>\"}', '2025-10-23 06:48:57', '2025-10-23 06:48:57'),
(92, 'testimonial.content', '{\"location\":\"Los Angeles, California\",\"title\":\"\\u201cThis tool changed everything\\u2014data collection and analysis became faster, easier, and incredibly efficient for our team.\\u201d\",\"has_image\":\"1\",\"image\":\"68fa27e606d941761224678.jpg\"}', '2025-10-23 07:04:38', '2025-10-23 07:04:38'),
(93, 'testimonial.element', '{\"name\":\"Joe Biden\",\"title\":\"\\u201cThis tool changed everything\\u2014data collection and analysis became faster, easier, and incredibly efficient for our team.\\u201d\",\"location\":\"Los Angeles, California\",\"has_image\":\"1\",\"image\":\"690b1d05315571762336005.jpg\"}', '2025-10-23 07:05:56', '2025-11-05 03:46:45'),
(94, 'testimonial.element', '{\"name\":\"Olivia Carter\",\"title\":\"\\u201cThis platform transformed the way we work\\u2014faster insights, smarter decisions, and seamless collaboration.\\u201d\",\"location\":\"New York, USA\",\"has_image\":\"1\",\"image\":\"690b1d19717311762336025.jpg\"}', '2025-10-23 07:08:51', '2025-11-05 03:47:05'),
(95, 'testimonial.element', '{\"name\":\"Gisela Dillard\",\"title\":\"\\u201cFrom chaos to clarity\\u2014this tool made our data process simple, efficient, and surprisingly enjoyable.\\u201d\",\"location\":\"San Fransisco, California\",\"has_image\":\"1\",\"image\":\"690b1d280f60f1762336040.jpg\"}', '2025-10-23 07:09:19', '2025-11-05 03:47:20'),
(96, 'testimonial.element', '{\"name\":\"Ramona Ramos\",\"title\":\"\\u201cEverything just works perfectly! It\\u2019s intuitive, reliable, and saves us so much time on every project.\\u201d\",\"location\":\"Potonsa, Indonesia\",\"has_image\":\"1\",\"image\":\"690b1d35020191762336053.jpg\"}', '2025-10-23 07:10:15', '2025-11-05 03:47:33'),
(97, 'blog.element', '{\"has_image\":[\"1\"],\"title\":\"The Future of Online Surveys: Smarter Data, Better Decisions\",\"quote\":\"\\u201cModern surveys are no longer about collecting random answers \\u2014 they\\u2019re about understanding emotions, predicting behavior, and helping businesses connect with their audience on a deeper, data-driven level.\\u201d\",\"description\":\"<p>In today\\u2019s digital era, online surveys have become one of the most powerful tools for gathering authentic user feedback and making data-driven decisions. Businesses, researchers, and organizations are increasingly turning to modern survey platforms that combine automation, analytics, and AI-powered insights to better understand audience behavior.<br \\/>Unlike traditional methods, online surveys provide instant responses, detailed analytics, and cost-effective reach across global audiences. The integration of technologies like sentiment analysis and data visualization has made it possible to interpret large sets of responses in a matter of seconds.<br \\/>Moreover, the focus is shifting toward <strong>user experience<\\/strong>, where interactive forms, personalized questions, and mobile-friendly designs are ensuring higher completion rates.<\\/p><ul><li>Collects instant and accurate feedback from global users.<\\/li><li>Integrates AI and analytics for deeper data understanding.<\\/li><li>Focuses on improving user experience and engagement.<\\/li><li>Enhances decision-making through smart interpretation.<\\/li><li>Transforms surveys into meaningful business intelligence tools.<\\/li><\\/ul><p>The future lies in smarter surveys \\u2014 ones that not only collect data but also interpret it intelligently to reveal real human emotions and preferences.<br \\/>As the world moves towards personalization, surveys are evolving into powerful engagement tools rather than mere questionnaires.<\\/p>\",\"blog_image\":\"68fdec576ec2f1761471575.jpg\"}', '2023-03-21 08:45:08', '2025-10-26 03:39:39'),
(98, 'blog.element', '{\"has_image\":[\"1\"],\"title\":\"Data-Driven Decisions: How Form builder Empower Businesses\",\"quote\":\"\\u201cSurveys turn opinions into opportunities. When businesses listen to their customers, every response becomes a data point that leads to smarter, more impactful decisions.\\u201d\",\"description\":\"<p>In today\\u2019s competitive market, businesses can no longer rely on assumptions they need data. Surveys have become a cornerstone of smart business strategies, helping organizations understand their customers, improve products, and enhance overall service quality. Through well-structured online surveys, companies can gather real-time insights directly from their audience, allowing them to make informed and data-backed decisions.<br \\/>From product satisfaction to brand perception, every response collected paints a clearer picture of what the market truly wants. With modern tools and automation, analyzing thousands of responses has become seamless and efficient. Businesses are now using survey analytics to discover patterns, identify pain points, and predict future trends.<\\/p><ul><li>Gathers real-time customer insights for better decision-making<\\/li><li>Identifies market needs and business improvement areas<\\/li><li>Enhances customer engagement through targeted feedback<\\/li><li>Simplifies analytics using automated survey tools<\\/li><li>Converts raw data into strategic business actions<\\/li><\\/ul><p>Ultimately, the data collected through surveys translates into action \\u2014 driving innovation, improving customer experience, and boosting revenue growth.<\\/p>\",\"blog_image\":\"68fa347099a831761227888.jpg\"}', '2023-03-21 08:45:08', '2025-11-05 04:47:35'),
(99, 'blog.element', '{\"has_image\":[\"1\"],\"title\":\"The Power of Customer Feedback in Shaping Brands\",\"quote\":\"\\u201cListening to your customers isn\\u2019t just good practice \\u2014 it\\u2019s the foundation of brand loyalty, trust, and long-term success in a customer-driven world.\\u201d\",\"description\":\"<p>Customer feedback is the most powerful yet often underutilized asset for brand growth. Every response from a survey reveals something valuable \\u2014 a strength to celebrate or an issue to fix. Modern survey systems allow brands to instantly collect, categorize, and interpret feedback across multiple channels.<br \\/>By listening to customers, brands gain insights that help them refine their products, personalize services, and build long-term trust. When customers feel heard, they become loyal advocates who naturally promote the brand. Feedback also plays a vital role in identifying hidden challenges before they escalate.<br \\/>Successful brands treat feedback not as criticism, but as a continuous improvement tool \\u2014 one that keeps them relevant and customer-centric in an ever-changing market.<\\/p><ul><li>Helps brands understand customer emotions and expectations<\\/li><li>Builds trust through transparent feedback handling<\\/li><li>Strengthens loyalty and advocacy among satisfied customers<\\/li><li>Detects problems early for proactive solutions<\\/li><li>Encourages data-based decision-making for brand growth<\\/li><\\/ul><p>Through well-structured online surveys, companies can gather real-time insights directly from their audience, allowing them to make informed and data-backed decisions. From product satisfaction to brand perception, every response collected paints a clearer picture of what the market truly wants.<\\/p>\",\"blog_image\":\"68fa3461710481761227873.jpg\"}', '2023-03-21 08:45:08', '2025-10-23 07:57:54'),
(100, 'blog.element', '{\"has_image\":[\"1\"],\"title\":\"How We Protect Your Data During Every Form builder\",\"quote\":\"\\\"Modern surveys are no longer about collecting random answers \\u2014 they\\u2019re about understanding emotions, predicting behavior, and helping businesses connect with their audience on a deeper, data-driven level.\\\"\",\"description\":\"<p>In today\\u2019s digital era, online surveys have become one of the most powerful tools for gathering authentic user feedback and making data-driven decisions. Businesses, researchers, and organizations are increasingly turning to modern survey platforms that combine automation, analytics, and AI-powered insights to better understand audience behavior.<br \\/>Unlike traditional methods, online surveys provide instant responses, detailed analytics, and cost-effective reach across global audiences. The integration of technologies like sentiment analysis and data visualization has made it possible to interpret large sets of responses in a matter of seconds.<br \\/>Moreover, the focus is shifting toward user experience, where interactive forms, personalized questions, and mobile-friendly designs are ensuring higher completion rates.\\u00a0<\\/p><ul><li>Collects instant and accurate feedback from global users.<\\/li><li>Integrates AI and analytics for deeper data understanding.<\\/li><li>Focuses on improving user experience and engagement.<\\/li><li>Enhances decision-making through smart interpretation.<\\/li><li>Transforms surveys into meaningful business intelligence tools.<\\/li><\\/ul><p>The future lies in smarter surveys \\u2014 ones that not only collect data but also interpret it intelligently to reveal real human emotions and preferences. As the world moves towards personalization, surveys are evolving into powerful engagement tools rather than mere questionnaires.<\\/p>\",\"blog_image\":\"68fdee3f63b721761472063.png\"}', '2023-03-21 08:45:08', '2025-11-04 02:44:58'),
(101, 'about.element', '{\"key_feature\":\"Based on user behavior, such as purchasing habits, product usage, or brand loyalty.\"}', '2025-10-26 05:32:32', '2025-10-26 05:32:32'),
(102, 'about.element', '{\"key_feature\":\"Nights guide the creation of products\\/services that meet audience demands.\"}', '2025-10-26 05:32:38', '2025-10-26 05:32:38'),
(103, 'about.element', '{\"key_feature\":\"Run campaigns for each segment, measure success, and refine strategies.\"}', '2025-10-26 05:32:44', '2025-10-26 05:32:44'),
(104, 'banner.element', '{\"has_image\":\"1\",\"image\":\"690a129c6b6a01762267804.png\"}', '2025-11-04 08:50:04', '2025-11-04 08:50:04'),
(105, 'banner.element', '{\"has_image\":\"1\",\"image\":\"690a12c0d88081762267840.png\"}', '2025-11-04 08:50:40', '2025-11-04 08:50:40'),
(106, 'banner.element', '{\"has_image\":\"1\",\"image\":\"690a12c771f111762267847.png\"}', '2025-11-04 08:50:47', '2025-11-04 08:50:47'),
(107, 'banner.element', '{\"has_image\":\"1\",\"image\":\"690a12cd02c541762267853.png\"}', '2025-11-04 08:50:53', '2025-11-04 08:50:53'),
(108, 'banner.element', '{\"has_image\":\"1\",\"image\":\"690a12d3b5fd71762267859.png\"}', '2025-11-04 08:50:59', '2025-11-04 08:50:59'),
(109, 'banner.element', '{\"has_image\":\"1\",\"image\":\"690a12ded5d3f1762267870.png\"}', '2025-11-04 08:51:10', '2025-11-04 08:51:10'),
(110, 'banner.element', '{\"has_image\":\"1\",\"image\":\"690a12e69c2301762267878.png\"}', '2025-11-04 08:51:18', '2025-11-04 08:51:18'),
(111, 'counter.element', '{\"title\":\"Logos Generated\",\"counter\":\"4580\",\"icon\":\"<i class=\\\"fas fa-users\\\"><\\/i>\"}', '2025-11-05 01:11:23', '2025-11-05 01:11:23'),
(112, 'counter.element', '{\"title\":\"Brand Kits Created\",\"counter\":\"2568\",\"icon\":\"<i class=\\\"fas fa-users\\\"><\\/i>\"}', '2025-11-05 01:11:59', '2025-11-05 01:20:50'),
(113, 'counter.element', '{\"title\":\"Active Users\",\"counter\":\"2587\",\"icon\":\"<i class=\\\"fas fa-users\\\"><\\/i>\"}', '2025-11-05 01:12:24', '2025-11-05 01:12:24'),
(114, 'counter.element', '{\"title\":\"Countries Served\",\"counter\":\"2560\",\"icon\":\"<i class=\\\"fas fa-users\\\"><\\/i>\"}', '2025-11-05 01:13:32', '2025-11-05 01:13:32'),
(115, 'service.content', '{\"heading\":\"Where Creativity Meets Recognition\",\"subheading\":\"Create your perfect kit effortlessly with kitme\'s AI kit maker. No design skills required\"}', '2025-11-05 02:34:56', '2025-11-05 02:34:56'),
(116, 'service.element', '{\"heading\":\"Generate Your own Company name\",\"subheading\":\"Streamline data collection, and gain real-time insights effortlessly\",\"has_image\":\"1\",\"image\":\"690b0ca3b60181762331811.png\"}', '2025-11-05 02:36:51', '2025-11-05 02:36:51'),
(117, 'service.element', '{\"heading\":\"Join our growing network of readers\",\"subheading\":\"Build smarter logo and unlock insights without switching platforms.\",\"has_image\":\"1\",\"image\":\"690b0cd616bc81762331862.png\"}', '2025-11-05 02:37:42', '2025-11-05 02:47:15'),
(118, 'action.content', '{\"heading\":\"See the Magic in Action\",\"subheading\":\"Create your perfect kit effortlessly with kitme\'s AI kit maker. No design skills required\"}', '2025-11-05 02:52:16', '2025-11-05 02:52:16'),
(120, 'action.element', '{\"has_image\":\"1\",\"image\":\"691acdd15a3f21763364305.png\"}', '2025-11-05 02:54:58', '2025-11-17 01:25:05'),
(121, 'action.element', '{\"has_image\":\"1\",\"image\":\"691acdda1f0a11763364314.png\"}', '2025-11-05 02:55:16', '2025-11-17 01:25:14'),
(122, 'action.element', '{\"has_image\":\"1\",\"image\":\"691acde2832081763364322.png\"}', '2025-11-05 02:55:22', '2025-11-17 01:25:22'),
(123, 'action.element', '{\"has_image\":\"1\",\"image\":\"691acdeb2f5331763364331.png\"}', '2025-11-05 02:55:33', '2025-11-17 01:25:31'),
(124, 'action.element', '{\"has_image\":\"1\",\"image\":\"691ace212cb731763364385.png\"}', '2025-11-05 02:55:43', '2025-11-17 01:26:25'),
(125, 'tutorial.element', '{\"heading\":\"Enter Your Brand Info\",\"subheading\":\"Type your brand name, industry, and style preferences.\"}', '2025-11-05 03:22:35', '2025-11-05 03:22:35'),
(126, 'tutorial.element', '{\"heading\":\"AI Generates Your Brand Kit\",\"subheading\":\"Get instant logo options, color palettes, and font pairings.\"}', '2025-11-05 03:22:47', '2025-11-05 03:22:47'),
(127, 'tutorial.element', '{\"heading\":\"Customize And Download\",\"subheading\":\"Type your brand name, industry, and style preferences.\"}', '2025-11-05 03:22:57', '2025-11-05 03:29:09'),
(128, 'tutorial.content', '{\"heading\":\"Build Your Brand in 3 Simple Steps\",\"subheading\":\"Just enter your brand name, choose your style, and let AI do the magic\"}', '2025-11-05 03:28:03', '2025-11-05 03:28:03');

-- --------------------------------------------------------

--
-- Table structure for table `gateways`
--

CREATE TABLE `gateways` (
  `id` bigint UNSIGNED NOT NULL,
  `form_id` int UNSIGNED NOT NULL DEFAULT '0',
  `code` int DEFAULT NULL,
  `name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `alias` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'NULL',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=>enable, 2=>disable',
  `gateway_parameters` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `supported_currencies` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `crypto` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: fiat currency, 1: crypto currency',
  `extra` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gateways`
--

INSERT INTO `gateways` (`id`, `form_id`, `code`, `name`, `alias`, `status`, `gateway_parameters`, `supported_currencies`, `crypto`, `extra`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 0, 101, 'Paypal', 'Paypal', 1, '{\"paypal_email\":{\"title\":\"PayPal Email\",\"global\":true,\"value\":\"sb-58ira22618401@business.example.com\"}}', '{\"AUD\":\"AUD\",\"BRL\":\"BRL\",\"CAD\":\"CAD\",\"CZK\":\"CZK\",\"DKK\":\"DKK\",\"EUR\":\"EUR\",\"HKD\":\"HKD\",\"HUF\":\"HUF\",\"INR\":\"INR\",\"ILS\":\"ILS\",\"JPY\":\"JPY\",\"MYR\":\"MYR\",\"MXN\":\"MXN\",\"TWD\":\"TWD\",\"NZD\":\"NZD\",\"NOK\":\"NOK\",\"PHP\":\"PHP\",\"PLN\":\"PLN\",\"GBP\":\"GBP\",\"RUB\":\"RUB\",\"SGD\":\"SGD\",\"SEK\":\"SEK\",\"CHF\":\"CHF\",\"THB\":\"THB\",\"USD\":\"$\"}', 0, NULL, NULL, '68ad6c4a8e06b1756195914.png', '2019-09-14 13:14:22', '2025-08-26 02:11:54'),
(2, 0, 102, 'Perfect Money', 'PerfectMoney', 1, '{\"passphrase\":{\"title\":\"ALTERNATE PASSPHRASE\",\"global\":true,\"value\":\"---------------------\"},\"wallet_id\":{\"title\":\"PM Wallet\",\"global\":false,\"value\":\"\"}}', '{\"USD\":\"$\",\"EUR\":\"\\u20ac\"}', 0, NULL, NULL, '68ad6bf7d53731756195831.png', '2019-09-14 13:14:22', '2025-08-26 02:10:31'),
(3, 0, 105, 'PayTM', 'Paytm', 1, '{\"MID\":{\"title\":\"Merchant ID\",\"global\":true,\"value\":\"-----------\"},\"merchant_key\":{\"title\":\"Merchant Key\",\"global\":true,\"value\":\"--------------------\"},\"WEBSITE\":{\"title\":\"Paytm Website\",\"global\":true,\"value\":\"example.com\"},\"INDUSTRY_TYPE_ID\":{\"title\":\"Industry Type\",\"global\":true,\"value\":\"Retail\"},\"CHANNEL_ID\":{\"title\":\"CHANNEL ID\",\"global\":true,\"value\":\"WEB\"},\"transaction_url\":{\"title\":\"Transaction URL\",\"global\":true,\"value\":\"https:\\/\\/pguat.paytm.com\\/oltp-web\\/processTransaction\"},\"transaction_status_url\":{\"title\":\"Transaction STATUS URL\",\"global\":true,\"value\":\"https:\\/\\/pguat.paytm.com\\/paytmchecksum\\/paytmCallback.jsp\"}}', '{\"AUD\":\"AUD\",\"ARS\":\"ARS\",\"BDT\":\"BDT\",\"BRL\":\"BRL\",\"BGN\":\"BGN\",\"CAD\":\"CAD\",\"CLP\":\"CLP\",\"CNY\":\"CNY\",\"COP\":\"COP\",\"HRK\":\"HRK\",\"CZK\":\"CZK\",\"DKK\":\"DKK\",\"EGP\":\"EGP\",\"EUR\":\"EUR\",\"GEL\":\"GEL\",\"GHS\":\"GHS\",\"HKD\":\"HKD\",\"HUF\":\"HUF\",\"INR\":\"INR\",\"IDR\":\"IDR\",\"ILS\":\"ILS\",\"JPY\":\"JPY\",\"KES\":\"KES\",\"MYR\":\"MYR\",\"MXN\":\"MXN\",\"MAD\":\"MAD\",\"NPR\":\"NPR\",\"NZD\":\"NZD\",\"NGN\":\"NGN\",\"NOK\":\"NOK\",\"PKR\":\"PKR\",\"PEN\":\"PEN\",\"PHP\":\"PHP\",\"PLN\":\"PLN\",\"RON\":\"RON\",\"RUB\":\"RUB\",\"SGD\":\"SGD\",\"ZAR\":\"ZAR\",\"KRW\":\"KRW\",\"LKR\":\"LKR\",\"SEK\":\"SEK\",\"CHF\":\"CHF\",\"THB\":\"THB\",\"TRY\":\"TRY\",\"UGX\":\"UGX\",\"UAH\":\"UAH\",\"AED\":\"AED\",\"GBP\":\"GBP\",\"USD\":\"USD\",\"VND\":\"VND\",\"XOF\":\"XOF\"}', 0, NULL, NULL, '68ad6c1ac3b1d1756195866.png', '2019-09-14 13:14:22', '2025-08-26 02:11:06'),
(4, 0, 107, 'PayStack', 'Paystack', 1, '{\"public_key\":{\"title\":\"Public key\",\"global\":true,\"value\":\"--------\"},\"secret_key\":{\"title\":\"Secret key\",\"global\":true,\"value\":\"----------------\"}}', '{\"USD\":\"USD\",\"NGN\":\"NGN\"}', 0, '{\"callback\":{\"title\": \"Callback URL\",\"value\":\"ipn.Paystack\"},\"webhook\":{\"title\": \"Webhook URL\",\"value\":\"ipn.Paystack\"}}\r\n', NULL, '68ad6c289ed011756195880.png', '2019-09-14 13:14:22', '2025-08-26 02:11:20'),
(5, 0, 108, 'VoguePay', 'Voguepay', 1, '{\"merchant_id\":{\"title\":\"MERCHANT ID\",\"global\":true,\"value\":\"-------------------\"}}', '{\"USD\":\"USD\",\"GBP\":\"GBP\",\"EUR\":\"EUR\",\"GHS\":\"GHS\",\"NGN\":\"NGN\",\"ZAR\":\"ZAR\"}', 0, NULL, NULL, '68ad6bba02fe21756195770.png', '2019-09-14 13:14:22', '2025-08-26 02:09:30'),
(6, 0, 109, 'Flutterwave', 'Flutterwave', 0, '{\"public_key\":{\"title\":\"Public Key\",\"global\":true,\"value\":\"----------------\"},\"secret_key\":{\"title\":\"Secret Key\",\"global\":true,\"value\":\"-----------------------\"},\"encryption_key\":{\"title\":\"Encryption Key\",\"global\":true,\"value\":\"------------------\"}}', '{\"BIF\":\"BIF\",\"CAD\":\"CAD\",\"CDF\":\"CDF\",\"CVE\":\"CVE\",\"EUR\":\"EUR\",\"GBP\":\"GBP\",\"GHS\":\"GHS\",\"GMD\":\"GMD\",\"GNF\":\"GNF\",\"KES\":\"KES\",\"LRD\":\"LRD\",\"MWK\":\"MWK\",\"MZN\":\"MZN\",\"NGN\":\"NGN\",\"RWF\":\"RWF\",\"SLL\":\"SLL\",\"STD\":\"STD\",\"TZS\":\"TZS\",\"UGX\":\"UGX\",\"USD\":\"USD\",\"XAF\":\"XAF\",\"XOF\":\"XOF\",\"ZMK\":\"ZMK\",\"ZMW\":\"ZMW\",\"ZWD\":\"ZWD\"}', 0, NULL, NULL, '68ad6c83913901756195971.png', '2019-09-14 13:14:22', '2025-08-26 02:12:51'),
(7, 0, 110, 'RazorPay', 'Razorpay', 1, '{\"key_id\":{\"title\":\"Key Id\",\"global\":true,\"value\":\"------------\"},\"key_secret\":{\"title\":\"Key Secret \",\"global\":true,\"value\":\"--------\"}}', '{\"INR\":\"INR\"}', 0, NULL, NULL, '68ad6beb086241756195819.png', '2019-09-14 13:14:22', '2025-08-26 02:10:19'),
(8, 0, 112, 'Instamojo', 'Instamojo', 1, '{\"api_key\":{\"title\":\"API KEY\",\"global\":true,\"value\":\"------------\"},\"auth_token\":{\"title\":\"Auth Token\",\"global\":true,\"value\":\"---------\"},\"salt\":{\"title\":\"Salt\",\"global\":true,\"value\":\"-------\"}}', '{\"INR\":\"INR\"}', 0, NULL, NULL, '68ad6c7c20a921756195964.png', '2019-09-14 13:14:22', '2025-08-26 02:12:44'),
(9, 0, 503, 'CoinPayments', 'Coinpayments', 0, '{\"public_key\":{\"title\":\"Public Key\",\"global\":true,\"value\":\"---------------\"},\"private_key\":{\"title\":\"Private Key\",\"global\":true,\"value\":\"------------\"},\"merchant_id\":{\"title\":\"Merchant ID\",\"global\":true,\"value\":\"----------------\"}}', '{\"BTC\":\"Bitcoin\",\"BTC.LN\":\"Bitcoin (Lightning Network)\",\"LTC\":\"Litecoin\",\"CPS\":\"CPS Coin\",\"VLX\":\"Velas\",\"APL\":\"Apollo\",\"AYA\":\"Aryacoin\",\"BAD\":\"Badcoin\",\"BCD\":\"Bitcoin Diamond\",\"BCH\":\"Bitcoin Cash\",\"BCN\":\"Bytecoin\",\"BEAM\":\"BEAM\",\"BITB\":\"Bean Cash\",\"BLK\":\"BlackCoin\",\"BSV\":\"Bitcoin SV\",\"BTAD\":\"Bitcoin Adult\",\"BTG\":\"Bitcoin Gold\",\"BTT\":\"BitTorrent\",\"CLOAK\":\"CloakCoin\",\"CLUB\":\"ClubCoin\",\"CRW\":\"Crown\",\"CRYP\":\"CrypticCoin\",\"CRYT\":\"CryTrExCoin\",\"CURE\":\"CureCoin\",\"DASH\":\"DASH\",\"DCR\":\"Decred\",\"DEV\":\"DeviantCoin\",\"DGB\":\"DigiByte\",\"DOGE\":\"Dogecoin\",\"EBST\":\"eBoost\",\"EOS\":\"EOS\",\"ETC\":\"Ether Classic\",\"ETH\":\"Ethereum\",\"ETN\":\"Electroneum\",\"EUNO\":\"EUNO\",\"EXP\":\"EXP\",\"Expanse\":\"Expanse\",\"FLASH\":\"FLASH\",\"GAME\":\"GameCredits\",\"GLC\":\"Goldcoin\",\"GRS\":\"Groestlcoin\",\"KMD\":\"Komodo\",\"LOKI\":\"LOKI\",\"LSK\":\"LSK\",\"MAID\":\"MaidSafeCoin\",\"MUE\":\"MonetaryUnit\",\"NAV\":\"NAV Coin\",\"NEO\":\"NEO\",\"NMC\":\"Namecoin\",\"NVST\":\"NVO Token\",\"NXT\":\"NXT\",\"OMNI\":\"OMNI\",\"PINK\":\"PinkCoin\",\"PIVX\":\"PIVX\",\"POT\":\"PotCoin\",\"PPC\":\"Peercoin\",\"PROC\":\"ProCurrency\",\"PURA\":\"PURA\",\"QTUM\":\"QTUM\",\"RES\":\"Resistance\",\"RVN\":\"Ravencoin\",\"RVR\":\"RevolutionVR\",\"SBD\":\"Steem Dollars\",\"SMART\":\"SmartCash\",\"SOXAX\":\"SOXAX\",\"STEEM\":\"STEEM\",\"STRAT\":\"STRAT\",\"SYS\":\"Syscoin\",\"TPAY\":\"TokenPay\",\"TRIGGERS\":\"Triggers\",\"TRX\":\" TRON\",\"UBQ\":\"Ubiq\",\"UNIT\":\"UniversalCurrency\",\"USDT\":\"Tether USD (Omni Layer)\",\"USDT.BEP20\":\"Tether USD (BSC Chain)\",\"USDT.ERC20\":\"Tether USD (ERC20)\",\"USDT.TRC20\":\"Tether USD (Tron/TRC20)\",\"VTC\":\"Vertcoin\",\"WAVES\":\"Waves\",\"XCP\":\"Counterparty\",\"XEM\":\"NEM\",\"XMR\":\"Monero\",\"XSN\":\"Stakenet\",\"XSR\":\"SucreCoin\",\"XVG\":\"VERGE\",\"XZC\":\"ZCoin\",\"ZEC\":\"ZCash\",\"ZEN\":\"Horizen\"}', 1, NULL, NULL, '68ad6cc15eb401756196033.png', '2019-09-14 13:14:22', '2025-08-26 02:13:53'),
(10, 0, 506, 'Coinbase Commerce', 'CoinbaseCommerce', 0, '{\"api_key\":{\"title\":\"API Key\",\"global\":true,\"value\":\"---------\"},\"secret\":{\"title\":\"Webhook Shared Secret\",\"global\":true,\"value\":\"----------------\"}}', '{\"USD\":\"USD\",\"EUR\":\"EUR\",\"JPY\":\"JPY\",\"GBP\":\"GBP\",\"AUD\":\"AUD\",\"CAD\":\"CAD\",\"CHF\":\"CHF\",\"CNY\":\"CNY\",\"SEK\":\"SEK\",\"NZD\":\"NZD\",\"MXN\":\"MXN\",\"SGD\":\"SGD\",\"HKD\":\"HKD\",\"NOK\":\"NOK\",\"KRW\":\"KRW\",\"TRY\":\"TRY\",\"RUB\":\"RUB\",\"INR\":\"INR\",\"BRL\":\"BRL\",\"ZAR\":\"ZAR\",\"AED\":\"AED\",\"AFN\":\"AFN\",\"ALL\":\"ALL\",\"AMD\":\"AMD\",\"ANG\":\"ANG\",\"AOA\":\"AOA\",\"ARS\":\"ARS\",\"AWG\":\"AWG\",\"AZN\":\"AZN\",\"BAM\":\"BAM\",\"BBD\":\"BBD\",\"BDT\":\"BDT\",\"BGN\":\"BGN\",\"BHD\":\"BHD\",\"BIF\":\"BIF\",\"BMD\":\"BMD\",\"BND\":\"BND\",\"BOB\":\"BOB\",\"BSD\":\"BSD\",\"BTN\":\"BTN\",\"BWP\":\"BWP\",\"BYN\":\"BYN\",\"BZD\":\"BZD\",\"CDF\":\"CDF\",\"CLF\":\"CLF\",\"CLP\":\"CLP\",\"COP\":\"COP\",\"CRC\":\"CRC\",\"CUC\":\"CUC\",\"CUP\":\"CUP\",\"CVE\":\"CVE\",\"CZK\":\"CZK\",\"DJF\":\"DJF\",\"DKK\":\"DKK\",\"DOP\":\"DOP\",\"DZD\":\"DZD\",\"EGP\":\"EGP\",\"ERN\":\"ERN\",\"ETB\":\"ETB\",\"FJD\":\"FJD\",\"FKP\":\"FKP\",\"GEL\":\"GEL\",\"GGP\":\"GGP\",\"GHS\":\"GHS\",\"GIP\":\"GIP\",\"GMD\":\"GMD\",\"GNF\":\"GNF\",\"GTQ\":\"GTQ\",\"GYD\":\"GYD\",\"HNL\":\"HNL\",\"HRK\":\"HRK\",\"HTG\":\"HTG\",\"HUF\":\"HUF\",\"IDR\":\"IDR\",\"ILS\":\"ILS\",\"IMP\":\"IMP\",\"IQD\":\"IQD\",\"IRR\":\"IRR\",\"ISK\":\"ISK\",\"JEP\":\"JEP\",\"JMD\":\"JMD\",\"JOD\":\"JOD\",\"KES\":\"KES\",\"KGS\":\"KGS\",\"KHR\":\"KHR\",\"KMF\":\"KMF\",\"KPW\":\"KPW\",\"KWD\":\"KWD\",\"KYD\":\"KYD\",\"KZT\":\"KZT\",\"LAK\":\"LAK\",\"LBP\":\"LBP\",\"LKR\":\"LKR\",\"LRD\":\"LRD\",\"LSL\":\"LSL\",\"LYD\":\"LYD\",\"MAD\":\"MAD\",\"MDL\":\"MDL\",\"MGA\":\"MGA\",\"MKD\":\"MKD\",\"MMK\":\"MMK\",\"MNT\":\"MNT\",\"MOP\":\"MOP\",\"MRO\":\"MRO\",\"MUR\":\"MUR\",\"MVR\":\"MVR\",\"MWK\":\"MWK\",\"MYR\":\"MYR\",\"MZN\":\"MZN\",\"NAD\":\"NAD\",\"NGN\":\"NGN\",\"NIO\":\"NIO\",\"NPR\":\"NPR\",\"OMR\":\"OMR\",\"PAB\":\"PAB\",\"PEN\":\"PEN\",\"PGK\":\"PGK\",\"PHP\":\"PHP\",\"PKR\":\"PKR\",\"PLN\":\"PLN\",\"PYG\":\"PYG\",\"QAR\":\"QAR\",\"RON\":\"RON\",\"RSD\":\"RSD\",\"RWF\":\"RWF\",\"SAR\":\"SAR\",\"SBD\":\"SBD\",\"SCR\":\"SCR\",\"SDG\":\"SDG\",\"SHP\":\"SHP\",\"SLL\":\"SLL\",\"SOS\":\"SOS\",\"SRD\":\"SRD\",\"SSP\":\"SSP\",\"STD\":\"STD\",\"SVC\":\"SVC\",\"SYP\":\"SYP\",\"SZL\":\"SZL\",\"THB\":\"THB\",\"TJS\":\"TJS\",\"TMT\":\"TMT\",\"TND\":\"TND\",\"TOP\":\"TOP\",\"TTD\":\"TTD\",\"TWD\":\"TWD\",\"TZS\":\"TZS\",\"UAH\":\"UAH\",\"UGX\":\"UGX\",\"UYU\":\"UYU\",\"UZS\":\"UZS\",\"VEF\":\"VEF\",\"VND\":\"VND\",\"VUV\":\"VUV\",\"WST\":\"WST\",\"XAF\":\"XAF\",\"XAG\":\"XAG\",\"XAU\":\"XAU\",\"XCD\":\"XCD\",\"XDR\":\"XDR\",\"XOF\":\"XOF\",\"XPD\":\"XPD\",\"XPF\":\"XPF\",\"XPT\":\"XPT\",\"YER\":\"YER\",\"ZMW\":\"ZMW\",\"ZWL\":\"ZWL\"}\r\n\r\n', 0, '{\"endpoint\":{\"title\": \"Webhook Endpoint\",\"value\":\"ipn.CoinbaseCommerce\"}}', NULL, '68ad6af1dab631756195569.png', '2019-09-14 13:14:22', '2025-08-26 03:03:20'),
(11, 0, 113, 'Paypal Express', 'PaypalSdk', 1, '{\"clientId\":{\"title\":\"Paypal Client ID\",\"global\":true,\"value\":\"------------\"},\"clientSecret\":{\"title\":\"Client Secret\",\"global\":true,\"value\":\"-----------\"}}', '{\"AUD\":\"AUD\",\"BRL\":\"BRL\",\"CAD\":\"CAD\",\"CZK\":\"CZK\",\"DKK\":\"DKK\",\"EUR\":\"EUR\",\"HKD\":\"HKD\",\"HUF\":\"HUF\",\"INR\":\"INR\",\"ILS\":\"ILS\",\"JPY\":\"JPY\",\"MYR\":\"MYR\",\"MXN\":\"MXN\",\"TWD\":\"TWD\",\"NZD\":\"NZD\",\"NOK\":\"NOK\",\"PHP\":\"PHP\",\"PLN\":\"PLN\",\"GBP\":\"GBP\",\"RUB\":\"RUB\",\"SGD\":\"SGD\",\"SEK\":\"SEK\",\"CHF\":\"CHF\",\"THB\":\"THB\",\"USD\":\"$\"}', 0, NULL, NULL, '68ad6c40c252c1756195904.png', '2019-09-14 13:14:22', '2025-08-26 02:11:44'),
(12, 0, 114, 'Stripe Checkout', 'StripeV3', 1, '{\"secret_key\":{\"title\":\"Secret Key\",\"global\":true,\"value\":\"sk_test_51M8Ks2CL65BWuH7eCBcWsLP2yPfWaLtfJVxG3zfii7cCWJE1izM4jkhucmBSm6izmVtSGZyp0JDYYCVmx9E4WmQY004gfnctzD\"},\"publishable_key\":{\"title\":\"PUBLISHABLE KEY\",\"global\":true,\"value\":\"pk_test_51M8Ks2CL65BWuH7eju6khGxJMpeeFuw2Rwrjr8UYCz6ZnQ3PiFxb1gVu1i1dBto9MQrnjkBimHkFJgNcqsrJHTak0010kCY41h\"},\"end_point\":{\"title\":\"End Point Secret\",\"global\":true,\"value\":\"abcd\"}}', '{\"USD\":\"USD\",\"AUD\":\"AUD\",\"BRL\":\"BRL\",\"CAD\":\"CAD\",\"CHF\":\"CHF\",\"DKK\":\"DKK\",\"EUR\":\"EUR\",\"GBP\":\"GBP\",\"HKD\":\"HKD\",\"INR\":\"INR\",\"JPY\":\"JPY\",\"MXN\":\"MXN\",\"MYR\":\"MYR\",\"NOK\":\"NOK\",\"NZD\":\"NZD\",\"PLN\":\"PLN\",\"SEK\":\"SEK\",\"SGD\":\"SGD\"}', 0, '{\"webhook\":{\"title\": \"Webhook Endpoint\",\"value\":\"ipn.StripeV3\"}}', NULL, '68ad6baf71dc81756195759.png', '2019-09-14 13:14:22', '2025-08-26 02:09:19'),
(49, 21, 1000, 'Bank Transfer', 'bank_transfer', 1, '[]', '[]', 0, NULL, '<p>Transfer funds to our official bank account. Enter the details exactly as shown on your transfer receipt. Bank deposits may take 1–3 business days to appear depending on your bank.</p>', '68ad62d32cb781756193491.png', '2025-06-28 07:50:58', '2025-09-21 07:23:28'),
(50, 22, 1001, 'Mobile Money', 'mobile_money', 1, '[]', '[]', 0, NULL, '<p>Please send the deposit to our official mobile money number. Make sure to include the correct transaction reference for quick approval. Mobile money deposits are usually processed within a few hours.</p>', '68ad62c6cdb141756193478.png', '2025-06-29 03:30:33', '2025-09-21 07:21:49'),
(51, 23, 1002, 'Cash Pay', 'cash_pay', 1, '[]', '[]', 0, NULL, '<p><i>Deposit cash directly at our office or approved agent location. Provide the agent name or receipt number for verification. Funds will be credited to your account after confirmation.</i></p>', '68ad62b3590361756193459.png', '2025-06-29 03:32:11', '2025-09-21 07:24:06'),
(52, 0, 115, 'Mercado Pago', 'MercadoPago', 1, '{\"access_token\":{\"title\":\"Access Token\",\"global\":true,\"value\":\"APP_USR-7924565816849832-082312-21941521997fab717db925cf1ea2c190-1071840315\"}}', '{\"USD\":\"USD\",\"CAD\":\"CAD\",\"CHF\":\"CHF\",\"DKK\":\"DKK\",\"EUR\":\"EUR\",\"GBP\":\"GBP\",\"NOK\":\"NOK\",\"PLN\":\"PLN\",\"SEK\":\"SEK\",\"AUD\":\"AUD\",\"NZD\":\"NZD\",\"BRL\":\"BRL\"}', 0, '{\"webhook\":{\"title\": \"Webhook Endpoint\",\"value\":\"ipn.MercadoPago\"}}', NULL, '68ad6c58c0d201756195928.png', '2019-09-14 13:14:22', '2025-08-26 02:12:08'),
(53, 25, 1003, 'Manual Transfer', 'manual_transfer', 1, '[]', '[]', 0, NULL, '<p><i>Please transfer the deposit amount to the provided account manually. After transferring, submit the details and upload the reference number for quick verification. Processing may take 1–2 business days after admin approval.</i></p>', '68ad62a1206e81756193441.png', '2025-08-13 02:19:07', '2025-09-21 07:23:50');

-- --------------------------------------------------------

--
-- Table structure for table `gateway_currencies`
--

CREATE TABLE `gateway_currencies` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `currency` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `symbol` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `method_code` int DEFAULT NULL,
  `gateway_alias` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `min_amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `max_amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `percent_charge` decimal(5,2) NOT NULL DEFAULT '0.00',
  `fixed_charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `rate` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `gateway_parameter` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gateway_currencies`
--

INSERT INTO `gateway_currencies` (`id`, `name`, `currency`, `symbol`, `method_code`, `gateway_alias`, `min_amount`, `max_amount`, `percent_charge`, `fixed_charge`, `rate`, `image`, `gateway_parameter`, `created_at`, `updated_at`) VALUES
(4, 'Bank Transfer', '$', '', 1000, 'bank_transfer', 1.00000000, 1000.00000000, 1.00, 1.00000000, 1.00000000, NULL, NULL, '2025-06-28 07:50:58', '2025-09-21 07:23:28'),
(8, 'Mobile Money', '$', '', 1001, 'mobile_money', 1.00000000, 1000000000.00000000, 0.25, 1.00000000, 1.00000000, NULL, NULL, '2025-06-29 03:30:33', '2025-09-21 07:21:49'),
(9, 'Cash Pay', '$', '', 1002, 'cash_pay', 1.00000000, 1000000000.00000000, 0.25, 1.00000000, 1.00000000, NULL, NULL, '2025-06-29 03:32:11', '2025-09-21 07:24:06'),
(17, 'Manual Transfer', '$', '', 1003, 'manual_transfer', 1.00000000, 1000000000.00000000, 0.25, 1.00000000, 1.00000000, NULL, NULL, '2025-08-13 02:19:07', '2025-10-26 06:37:11'),
(19, 'Paypal - USD', 'USD', '$', 101, 'Paypal', 10.00000000, 1000.00000000, 0.00, 0.00000000, 1.00000000, NULL, '{\"paypal_email\":\"sb-58ira22618401@business.example.com\"}', '2025-08-26 02:11:54', '2025-08-26 02:11:54'),
(20, 'Mercado Pago - CAD', 'CAD', '$', 115, 'MercadoPago', 1.00000000, 1000000.00000000, 0.25, 0.25000000, 1.00000000, NULL, '{\"access_token\":\"APP_USR-7924565816849832-082312-21941521997fab717db925cf1ea2c190-1071840315\"}', '2025-08-26 02:12:08', '2025-08-26 02:12:08'),
(21, 'Bank Transferddddddd', '$$', '', 1004, 'bank_transferddddddd', 1.00000000, 1000000000.00000000, 1.00, 1.00000000, 1.00000000, NULL, NULL, '2025-10-02 04:00:36', '2025-10-02 04:01:00'),
(22, 'Coinbase Commerce - JPY', 'JPY', '₦', 506, 'CoinbaseCommerce', 1.00000000, 10000.00000000, 1.00, 1.00000000, 1.00000000, NULL, '{\"api_key\":\"---------\",\"secret\":\"----------------\"}', '2025-10-02 05:29:15', '2025-10-02 05:29:15');

-- --------------------------------------------------------

--
-- Table structure for table `general_settings`
--

CREATE TABLE `general_settings` (
  `id` bigint UNSIGNED NOT NULL,
  `site_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `cur_text` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'currency text',
  `open_ai_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `per_credit_price` decimal(18,0) NOT NULL,
  `credit_cost_per_logo` decimal(18,2) NOT NULL DEFAULT '0.00',
  `cur_sym` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'currency symbol',
  `email_from` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email_template` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `sms_body` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sms_from` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `base_color` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `secondary_color` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mail_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'email configuration',
  `sms_config` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `global_shortcodes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `kv` tinyint(1) NOT NULL DEFAULT '0',
  `ev` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'email verification, 0 - dont check, 1 - check',
  `en` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'email notification, 0 - dont send, 1 - send',
  `sv` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'mobile verication, 0 - dont check, 1 - check',
  `sn` tinyint(1) NOT NULL DEFAULT '0' COMMENT 'sms notification, 0 - dont send, 1 - send',
  `force_ssl` tinyint(1) NOT NULL DEFAULT '0',
  `maintenance_mode` tinyint(1) NOT NULL DEFAULT '0',
  `secure_password` tinyint(1) NOT NULL DEFAULT '0',
  `agree` tinyint(1) NOT NULL DEFAULT '0',
  `registration` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: Off	, 1: On',
  `active_template` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `system_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `socialite_credentials` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `general_settings`
--

INSERT INTO `general_settings` (`id`, `site_name`, `cur_text`, `open_ai_key`, `per_credit_price`, `credit_cost_per_logo`, `cur_sym`, `email_from`, `email_template`, `sms_body`, `sms_from`, `base_color`, `secondary_color`, `mail_config`, `sms_config`, `global_shortcodes`, `kv`, `ev`, `en`, `sv`, `sn`, `force_ssl`, `maintenance_mode`, `secure_password`, `agree`, `registration`, `active_template`, `system_info`, `socialite_credentials`, `created_at`, `updated_at`) VALUES
(1, 'Brandify', 'USD', 'AIzaSyD6_qyDgJ0qKu5TYqEvqJCSMPFCuwlXkHg', 20, 2.00, '$', 'notify@example.com', '<p>Hi {{fullname}} ({{username}}),&nbsp;</p><p>{{message}}</p>', 'Hi {{fullname}} ({{username}}), \r\n{{message}}', 'Brandify', '11a259', '2b2b36', '{\"name\":\"php\"}', '{\"name\":\"clickatell\",\"clickatell\":{\"api_key\":\"==============ck\"},\"infobip\":{\"username\":\"=================in\",\"password\":\"================in\"},\"message_bird\":{\"api_key\":\"=============mb\"},\"nexmo\":{\"api_key\":\"----------------------nx\",\"api_secret\":\"----------------------nx\"},\"sms_broadcast\":{\"username\":\"================sb\",\"password\":\"=================sb\"},\"twilio\":{\"account_sid\":\"-----------------------tw\",\"auth_token\":\"---------------------------tw\",\"from\":\"----------------------tw\"},\"custom\":{\"method\":\"get\",\"url\":\"https:\\/\\/hostname\\/demo-api-v1\",\"headers\":{\"name\":[\"api_key\"],\"value\":[\"test_api 555\"]},\"body\":{\"name\":[\"from_number\"],\"value\":[\"5657545757\"]}}}', '{\n    \"site_name\":\"Name of your site\",\n    \"site_currency\":\"Currency of your site\",\n    \"currency_symbol\":\"Symbol of currency\"\n}', 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 'default', '[]', '{\"google\":{\"client_id\":\"959894800111-743odo92gdre71v9vt1u6pqkc5vo9v3g.apps.googleusercontent.com\",\"client_secret\":\"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\",\"status\":0},\"facebook\":{\"client_id\":\"================\",\"client_secret\":\"==============\",\"status\":0}}', NULL, '2025-11-13 07:14:21');

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `text_align` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: left to right text align, 1: right to left text align',
  `is_default` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: not default language, 1: default language',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `name`, `code`, `image`, `text_align`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'English', 'en', '68cfe345448ad1758454597.png', 0, 1, '2020-07-06 03:47:55', '2025-09-21 05:36:37'),
(16, 'Spanish', 'es', '68cfe376103511758454646.jpg', 0, 0, '2025-06-26 00:14:07', '2025-09-21 05:37:26');

-- --------------------------------------------------------

--
-- Table structure for table `logos`
--

CREATE TABLE `logos` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `category_id` int UNSIGNED NOT NULL,
  `brand_name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `is_remove_background` tinyint NOT NULL COMMENT ' 0 = no , 1 =yes',
  `updated_at` timestamp NULL DEFAULT NULL,
  `tagline` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `color` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `font_style` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `logo_count` int NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logos`
--

INSERT INTO `logos` (`id`, `user_id`, `category_id`, `brand_name`, `is_remove_background`, `updated_at`, `tagline`, `created_at`, `color`, `font_style`, `logo_count`) VALUES
(1, 1, 4, 'Squed gamer', 0, '2025-11-11 06:35:35', 'Gaming', '2025-01-22 06:35:35', 'f4261e', 'Roboto', 2),
(2, 1, 4, 'Squed gamer', 0, '2025-11-11 06:36:45', 'Gaming', '2025-02-15 06:36:45', 'f4261e', 'Roboto', 1),
(3, 1, 4, 'Squad Gamer', 0, '2025-11-11 06:45:47', 'Gaming', '2025-11-11 06:45:47', 'a21a11', 'Poppins', 1),
(4, 1, 4, 'squed gamer', 0, '2025-11-11 07:20:04', 'Gaming', '2025-11-11 07:20:04', 'f6400f', 'Open Sans', 1),
(5, 1, 4, 'squed gamer', 0, '2025-11-11 07:24:40', 'Gaming', '2025-11-11 07:24:40', 'f6400f', 'Open Sans', 1),
(6, 1, 4, 'squed gamer', 0, '2025-11-11 07:25:46', 'Gaming', '2025-11-11 07:25:46', 'f6400f', 'Open Sans', 1),
(7, 1, 4, 'squed gamer', 1, '2025-11-11 07:26:32', 'Gaming', '2025-11-11 07:26:32', 'ee5925', 'Ubuntu', 1),
(8, 1, 4, 'squed gamer', 0, '2025-11-11 07:27:19', 'Gaming', '2025-11-11 07:27:19', '11a259', 'Ubuntu', 1),
(9, 1, 4, 'Squed gamer', 1, '2025-11-11 08:05:04', 'Gaming', '2025-11-11 08:05:04', 'f41e0b', 'Open Sans', 2),
(10, 1, 3, 'squed gamer', 0, '2025-11-11 08:23:09', 'Business', '2025-11-11 08:23:09', '11a259', 'Lato', 1),
(12, 2, 4, 'Squed gamer', 0, '2025-11-11 06:35:35', 'Gaming', '2025-01-22 06:35:35', 'f4261e', 'Roboto', 30),
(13, 2, 4, 'Squed gamer', 0, '2025-11-11 06:36:45', 'Gaming', '2025-02-15 06:36:45', 'f4261e', 'Roboto', 70),
(14, 2, 4, 'Squad Gamer', 0, '2025-11-11 06:45:47', 'Gaming', '2025-03-16 06:45:47', 'a21a11', 'Poppins', 10),
(15, 2, 4, 'squed gamer', 0, '2025-11-11 07:20:04', 'Gaming', '2025-04-26 07:20:04', 'f6400f', 'Open Sans', 50),
(16, 2, 4, 'squed gamer', 0, '2025-11-11 07:24:40', 'Gaming', '2025-05-09 07:24:40', 'f6400f', 'Open Sans', 40),
(17, 2, 4, 'squed gamer', 0, '2025-11-11 07:25:46', 'Gaming', '2025-06-11 07:25:46', 'f6400f', 'Open Sans', 20),
(18, 2, 4, 'squed gamer', 1, '2025-11-11 07:26:32', 'Gaming', '2025-07-02 07:26:32', 'ee5925', 'Ubuntu', 30),
(19, 2, 4, 'squed gamer', 0, '2025-11-11 07:27:19', 'Gaming', '2025-08-20 07:27:19', '11a259', 'Ubuntu', 50),
(20, 2, 4, 'Squed gamer', 1, '2025-11-11 08:05:04', 'Gaming', '2025-09-24 08:05:04', 'f41e0b', 'Open Sans', 40),
(21, 2, 3, 'squed gamer', 0, '2025-11-11 08:23:09', 'Business', '2025-10-24 08:23:09', '11a259', 'Lato', 80),
(22, 1, 3, 'dsd', 0, '2025-11-13 04:50:41', 'Business', '2025-11-13 04:50:41', '11a259', 'Raleway', 1),
(23, 1, 3, 'dsd', 0, '2025-11-13 04:51:09', 'Business', '2025-11-13 04:51:09', '11a259', 'Raleway', 1),
(24, 1, 8, 'RHK Gaming', 0, '2025-11-13 07:08:15', 'Food & Cooking', '2025-11-13 07:08:15', 'fc4412', 'Playfair Display', 1),
(25, 1, 13, 'Tech Gaming', 0, '2025-11-13 07:20:40', 'Tech News', '2025-11-13 07:20:40', 'fc0303', 'Libre Baskerville', 1),
(26, 1, 7, 'wstacks', 0, '2025-11-13 09:03:47', 'Science & Innovation', '2025-11-13 09:03:47', '1479f0', 'Raleway', 1),
(27, 1, 4, 'Hanzo', 0, '2025-11-16 05:04:20', 'Gaming', '2025-11-16 05:04:20', '11a259', 'Raleway', 1);

-- --------------------------------------------------------

--
-- Table structure for table `logo_images`
--

CREATE TABLE `logo_images` (
  `id` int NOT NULL,
  `logo_id` bigint UNSIGNED NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logo_images`
--

INSERT INTO `logo_images` (`id`, `logo_id`, `image`, `created_at`, `updated_at`) VALUES
(1, 3, 'image_1762865147_74808.png', '2025-11-11 06:45:47', '2025-11-11 06:45:47'),
(2, 4, 'image_1762867204_30080.png', '2025-11-11 07:20:04', '2025-11-11 07:20:04'),
(3, 5, 'image_1762867480_30953.png', '2025-11-11 07:24:40', '2025-11-11 07:24:40'),
(4, 6, 'image_1762867546_89970.png', '2025-11-11 07:25:46', '2025-11-11 07:25:46'),
(5, 7, 'image_1762867592_51400.png', '2025-11-11 07:26:32', '2025-11-11 07:26:32'),
(6, 8, 'image_1762867639_38280.png', '2025-11-11 07:27:19', '2025-11-11 07:27:19'),
(7, 9, 'image_1762869904_43119.png', '2025-11-11 08:05:04', '2025-11-11 08:05:04'),
(8, 9, 'image_1762869904_28768.png', '2025-11-11 08:05:04', '2025-11-11 08:05:04'),
(9, 10, 'image_1762870989_78047.png', '2025-11-11 08:23:09', '2025-11-11 08:23:09'),
(11, 22, 'image_1763031041_27777.png', '2025-11-13 04:50:41', '2025-11-13 04:50:41'),
(12, 23, 'image_1763031069_58399.png', '2025-11-13 04:51:09', '2025-11-13 04:51:09'),
(13, 24, 'image_1763039295_78212.png', '2025-11-13 07:08:15', '2025-11-13 07:08:15'),
(14, 25, 'image_1763040040_77855.png', '2025-11-13 07:20:40', '2025-11-13 07:20:40'),
(15, 26, 'image_1763046227_58964.png', '2025-11-13 09:03:47', '2025-11-13 09:03:47'),
(16, 27, 'image_1763291060_44517.png', '2025-11-16 05:04:20', '2025-11-16 05:04:20');

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `code`, `created_at`, `updated_at`) VALUES
(1, 'Header Menu', 'header_menu', '2025-09-16 02:39:26', '2025-09-16 02:39:26'),
(2, 'Quick Link', 'important_link', '2025-09-16 02:39:37', '2025-10-23 00:04:03'),
(4, 'Company Link', 'company_link', '2025-10-23 00:03:54', '2025-10-23 00:03:54');

-- --------------------------------------------------------

--
-- Table structure for table `menu_items`
--

CREATE TABLE `menu_items` (
  `id` bigint UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `link_type` tinyint(1) NOT NULL DEFAULT '1',
  `page_id` bigint NOT NULL DEFAULT '0',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_items`
--

INSERT INTO `menu_items` (`id`, `title`, `link_type`, `page_id`, `url`, `created_at`, `updated_at`) VALUES
(6, 'Privacy Policy', 1, 0, 'policy/privacy-policy/42', '2025-09-20 03:05:05', '2025-09-20 03:05:05'),
(7, 'Terms of Service', 1, 0, 'policy/terms-of-service/43', '2025-09-20 03:05:23', '2025-09-20 03:05:23'),
(8, 'Cookie Policy', 1, 0, 'cookie-policy', '2025-09-20 03:05:37', '2025-09-20 03:05:37'),
(10, 'Blog', 3, 4, 'blog', '2025-10-23 08:04:50', '2025-10-23 08:04:50'),
(11, 'Contact', 3, 5, 'contact', '2025-10-23 08:05:07', '2025-10-23 08:05:07'),
(12, 'Home', 3, 1, '/', '2025-10-23 08:07:28', '2025-10-23 08:07:28'),
(14, 'About', 3, 21, 'about', '2025-10-26 05:59:22', '2025-10-26 05:59:22'),
(15, 'Features', 3, 23, 'features', '2025-10-26 06:12:19', '2025-10-26 06:12:19');

-- --------------------------------------------------------

--
-- Table structure for table `menu_menu_items`
--

CREATE TABLE `menu_menu_items` (
  `id` bigint NOT NULL,
  `menu_id` bigint NOT NULL,
  `menu_item_id` bigint NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `menu_menu_items`
--

INSERT INTO `menu_menu_items` (`id`, `menu_id`, `menu_item_id`, `created_at`, `updated_at`) VALUES
(21, 2, 1, '2025-09-15 03:49:34', '2025-09-15 03:49:34'),
(26, 2, 2, '2025-09-15 03:49:34', '2025-09-15 03:49:34'),
(27, 2, 5, '2025-09-15 03:49:34', '2025-09-15 03:49:34'),
(46, 1, 1, '2025-09-30 09:40:54', '2025-09-30 09:40:54'),
(50, 1, 2, '2025-09-30 09:40:54', '2025-09-30 09:40:54'),
(51, 1, 5, '2025-09-30 09:40:54', '2025-09-30 09:40:54'),
(52, 7, 14, '2025-10-04 03:36:16', '2025-10-04 03:36:16'),
(53, 7, 15, '2025-10-04 03:36:16', '2025-10-04 03:36:16'),
(68, 4, 12, '2025-10-25 00:28:38', '2025-10-25 00:28:38'),
(69, 4, 11, '2025-10-25 00:28:38', '2025-10-25 00:28:38'),
(70, 4, 10, '2025-10-25 00:28:38', '2025-10-25 00:28:38'),
(83, 1, 12, '2025-10-26 06:12:26', '2025-10-26 06:12:26'),
(85, 1, 15, '2025-10-26 06:12:26', '2025-10-26 06:12:26'),
(86, 1, 14, '2025-10-26 06:12:26', '2025-10-26 06:12:26'),
(87, 1, 10, '2025-10-26 06:12:26', '2025-10-26 06:12:26'),
(88, 1, 11, '2025-10-26 06:12:26', '2025-10-26 06:12:26'),
(92, 2, 8, '2025-11-05 05:07:19', '2025-11-05 05:07:19'),
(93, 2, 7, '2025-11-05 05:07:19', '2025-11-05 05:07:19'),
(94, 2, 6, '2025-11-05 05:07:19', '2025-11-05 05:07:19');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(2, '2025_07_19_024836_create_menus_table', 1),
(3, '2025_07_19_024852_create_menu_items_table', 2),
(4, '2025_07_19_024918_create_menu_menu_items_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `notification_logs`
--

CREATE TABLE `notification_logs` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL DEFAULT '0',
  `sender` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sent_from` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `sent_to` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `notification_type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification_logs`
--

INSERT INTO `notification_logs` (`id`, `user_id`, `sender`, `sent_from`, `sent_to`, `subject`, `message`, `notification_type`, `created_at`, `updated_at`) VALUES
(1, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Credit Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your Credit payment request of&nbsp;400.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Credit Payment:</p><p>Amount : 400.00 USD</p><p>Purchase Credit : {{ purchase_credit_count }}</p><p>Charge:&nbsp;2.00 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 402.00 $</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : {{trx}}</p></p>', 'email', '2025-10-27 01:27:32', '2025-10-27 01:27:32'),
(2, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Credit Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n400.00 USD Credit Payment requested by Manual Transfer. Charge: 2.00 . Trx: {{trx}}', 'sms', '2025-10-27 01:27:33', '2025-10-27 01:27:33'),
(3, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Credit Payment is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your credit payment request of&nbsp;{{amount}} USD&nbsp;is via&nbsp; Manual Transfer&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Credit Payment:<br>&nbsp;</p><p>Amount : {{amount}} USD</p><p>Credits: {{ number_of_credit }}</p><p>Charge:&nbsp;2.00 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 402.00 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Transaction Number : {{trx}}<br>&nbsp;</p><p>Your current Balance is&nbsp;80.00 USD</p></p>', 'email', '2025-10-27 01:29:57', '2025-10-27 01:29:57'),
(4, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Credit Payment is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD Credit payment request by Manual Transfer transaction : {{trx}}', 'sms', '2025-10-27 01:29:58', '2025-10-27 01:29:58'),
(5, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Credit Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your Credit payment request of&nbsp;200.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Credit Payment:</p><p>Amount : 200.00 USD</p><p>Purchase Credit : {{ purchase_credit_count }}</p><p>Charge:&nbsp;1.50 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 201.50 $</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : {{trx}}</p></p>', 'email', '2025-10-27 01:30:38', '2025-10-27 01:30:38'),
(6, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Credit Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n200.00 USD Credit Payment requested by Manual Transfer. Charge: 1.50 . Trx: {{trx}}', 'sms', '2025-10-27 01:30:39', '2025-10-27 01:30:39'),
(7, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Credit Payment Request is Rejected', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your Credit Payment request of&nbsp;200.00 USD&nbsp;is via&nbsp; Manual Transfer has been rejected.<br>&nbsp;</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 201.50 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Charge: 1.50</p><p>Transaction Number was : {{trx}}</p><p>if you have any queries, feel free to contact us.<br>&nbsp;</p><p>&nbsp;</p><p>Your payment is not valid<br>&nbsp;</p></p>', 'email', '2025-10-27 01:31:32', '2025-10-27 01:31:32'),
(8, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Credit Payment Request is Rejected', 'Hi test user (testuser), \r\nAdmin Rejected Your 200.00 USD Credit payment request by Manual Transfer\r\n\r\nYour payment is not valid', 'sms', '2025-10-27 01:31:33', '2025-10-27 01:31:33'),
(9, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Deposit Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><div>Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">20.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer&nbsp;</span>submitted successfully<span style=\"font-weight: bolder;\">&nbsp;.<br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : 20.00 USD</div><div>Charge:&nbsp;<font color=\"#FF0000\">1.05 USD</font></div><div><br></div><div>Conversion Rate : 1 USD = 1.00 $</div><div>Payable : 21.05 $<br></div><div>Pay via :&nbsp; Manual Transfer</div><div><br></div><div>Transaction Number : WB7BTZWJQO2X</div><div><br></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-10-27 01:32:28', '2025-10-27 01:32:28'),
(10, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Deposit Request Submitted Successfully', 'Hi test user (testuser), \r\n20.00 USD Deposit requested by Manual Transfer. Charge: 1.05 . Trx: WB7BTZWJQO2X', 'sms', '2025-10-27 01:32:29', '2025-10-27 01:32:29'),
(11, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Deposit is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">{{amount}} USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer&nbsp;</span>is Approved .<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : {{amount}} USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">1.05 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 $</div><div style=\"font-family: Montserrat, sans-serif;\">Received : 21.05 $<br></div><div style=\"font-family: Montserrat, sans-serif;\">Paid via :&nbsp; Manual Transfer</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : WB7BTZWJQO2X</div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\"><span style=\"font-weight: bolder;\"><br></span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">100.00 USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div></p>', 'email', '2025-10-27 01:32:56', '2025-10-27 01:32:56'),
(12, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Deposit is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD payment request by Manual Transfer transaction : WB7BTZWJQO2X', 'sms', '2025-10-27 01:32:57', '2025-10-27 01:32:57'),
(13, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Deposit Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><div>Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">30.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer&nbsp;</span>submitted successfully<span style=\"font-weight: bolder;\">&nbsp;.<br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : 30.00 USD</div><div>Charge:&nbsp;<font color=\"#FF0000\">1.08 USD</font></div><div><br></div><div>Conversion Rate : 1 USD = 1.00 $</div><div>Payable : 31.08 $<br></div><div>Pay via :&nbsp; Manual Transfer</div><div><br></div><div>Transaction Number : PTCDPKKW11FO</div><div><br></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-10-27 01:33:44', '2025-10-27 01:33:44'),
(14, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Deposit Request Submitted Successfully', 'Hi test user (testuser), \r\n30.00 USD Deposit requested by Manual Transfer. Charge: 1.08 . Trx: PTCDPKKW11FO', 'sms', '2025-10-27 01:33:45', '2025-10-27 01:33:45'),
(15, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Deposit Request is Rejected', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">30.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer has been rejected</span>.<span style=\"font-weight: bolder;\"><br></span></div><div><br></div><div><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 $</div><div style=\"font-family: Montserrat, sans-serif;\">Received : 31.08 $<br></div><div style=\"font-family: Montserrat, sans-serif;\">Paid via :&nbsp; Manual Transfer</div><div style=\"font-family: Montserrat, sans-serif;\">Charge: 1.08</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number was : PTCDPKKW11FO</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">if you have any queries, feel free to contact us.<br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><br><br></div><span style=\"color: rgb(33, 37, 41); font-family: Montserrat, sans-serif;\">TRX number is wrong</span><br></p>', 'email', '2025-10-27 01:34:04', '2025-10-27 01:34:04'),
(16, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Deposit Request is Rejected', 'Hi test user (testuser), \r\nAdmin Rejected Your 30.00 USD payment request by Manual Transfer\r\n\r\nTRX number is wrong', 'sms', '2025-10-27 01:34:05', '2025-10-27 01:34:05'),
(17, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Plan Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan payment request of&nbsp;50.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Plan Payment:<br>&nbsp;</p><p>Amount : 50.00 USD</p><p>Charge:&nbsp;1.13 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 51.13 $<br>&nbsp;</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : NHODAF66YBJY</p></p>', 'email', '2025-10-27 03:10:49', '2025-10-27 03:10:49'),
(18, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Plan Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n50.00 USD Plan payment requested by Manual Transfer. Charge: 1.13 . Trx: NHODAF66YBJY', 'sms', '2025-10-27 03:10:50', '2025-10-27 03:10:50'),
(19, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Plan Payment is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan payment request of&nbsp;{{amount}} USD&nbsp;is via&nbsp; Manual Transfer&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Plan Payment:<br>&nbsp;</p><p>Amount : {{amount}} USD</p><p>Charge:&nbsp;1.13 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 51.13 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Transaction Number : NHODAF66YBJY</p><p>&nbsp;</p><p>Your current Balance is&nbsp;60.00 USD</p></p>', 'email', '2025-10-27 03:12:20', '2025-10-27 03:12:20'),
(20, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Plan Payment is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD plan payment request by Manual Transfer transaction : NHODAF66YBJY', 'sms', '2025-10-27 03:12:21', '2025-10-27 03:12:21'),
(21, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Plan Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan payment request of&nbsp;100.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Plan Payment:<br>&nbsp;</p><p>Amount : 100.00 USD</p><p>Charge:&nbsp;1.25 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 101.25 $<br>&nbsp;</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : PO2YWXSMQXXN</p></p>', 'email', '2025-10-27 03:15:29', '2025-10-27 03:15:29'),
(22, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Plan Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n100.00 USD Plan payment requested by Manual Transfer. Charge: 1.25 . Trx: PO2YWXSMQXXN', 'sms', '2025-10-27 03:15:31', '2025-10-27 03:15:31'),
(23, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Plan Payment Request is Rejected', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan payment &nbsp;request of&nbsp;100.00 USD&nbsp;is via&nbsp; Manual Transfer has been rejected.<br>&nbsp;</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 101.25 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Charge: 1.25</p><p>Transaction Number was : PO2YWXSMQXXN</p><p>if you have any queries, feel free to contact us.<br>&nbsp;</p><p>&nbsp;</p><p>fghjdf<br>&nbsp;</p></p>', 'email', '2025-10-27 03:16:47', '2025-10-27 03:16:47'),
(24, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Plan Payment Request is Rejected', 'Hi test user (testuser), \r\nAdmin Rejected Your 100.00 USD plan payment request by Manual Transfer\r\n\r\nfghjdf', 'sms', '2025-10-27 03:16:48', '2025-10-27 03:16:48'),
(25, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Plan Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan payment request of&nbsp;100.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Plan Payment:<br>&nbsp;</p><p>Amount : 100.00 USD</p><p>Charge:&nbsp;1.25 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 101.25 $<br>&nbsp;</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : K27FZHW9TZRO</p></p>', 'email', '2025-10-27 04:16:37', '2025-10-27 04:16:37'),
(26, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Plan Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n100.00 USD Plan payment requested by Manual Transfer. Charge: 1.25 . Trx: K27FZHW9TZRO', 'sms', '2025-10-27 04:16:39', '2025-10-27 04:16:39'),
(27, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Plan Payment is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan payment request of&nbsp;{{amount}} USD&nbsp;is via&nbsp; Manual Transfer&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Plan Payment:<br>&nbsp;</p><p>Amount : {{amount}} USD</p><p>Charge:&nbsp;1.25 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 101.25 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Transaction Number : K27FZHW9TZRO</p><p>&nbsp;</p><p>Your current Balance is&nbsp;2,960.00 USD</p></p>', 'email', '2025-10-27 04:17:44', '2025-10-27 04:17:44'),
(28, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Plan Payment is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD plan payment request by Manual Transfer transaction : K27FZHW9TZRO', 'sms', '2025-10-27 04:17:45', '2025-10-27 04:17:45'),
(29, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Plan Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan payment request of&nbsp;100.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Plan Payment:<br>&nbsp;</p><p>Amount : 100.00 USD</p><p>Charge:&nbsp;1.25 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 101.25 $<br>&nbsp;</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : KO28RH5SSYWS</p></p>', 'email', '2025-10-27 04:18:33', '2025-10-27 04:18:33'),
(30, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Plan Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n100.00 USD Plan payment requested by Manual Transfer. Charge: 1.25 . Trx: KO28RH5SSYWS', 'sms', '2025-10-27 04:18:34', '2025-10-27 04:18:34'),
(31, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Plan Payment Request is Rejected', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan payment &nbsp;request of&nbsp;100.00 USD&nbsp;is via&nbsp; Manual Transfer has been rejected.<br>&nbsp;</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 101.25 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Charge: 1.25</p><p>Transaction Number was : KO28RH5SSYWS</p><p>if you have any queries, feel free to contact us.<br>&nbsp;</p><p>&nbsp;</p><p>Your payment not valid<br>&nbsp;</p></p>', 'email', '2025-10-27 04:19:11', '2025-10-27 04:19:11'),
(32, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Plan Payment Request is Rejected', 'Hi test user (testuser), \r\nAdmin Rejected Your 100.00 USD plan payment request by Manual Transfer\r\n\r\nYour payment not valid', 'sms', '2025-10-27 04:19:12', '2025-10-27 04:19:12'),
(33, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Plan Subscription Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;50.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : 50.00 USD</p><p>Charge:&nbsp;1.13 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 51.13 $<br>&nbsp;</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : VKQHOR6WCXYA</p></p>', 'email', '2025-10-27 04:54:34', '2025-10-27 04:54:34'),
(34, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Plan Subscription Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n50.00 USD Plan Subscription payment requested by Manual Transfer. Charge: 1.13 . Trx: VKQHOR6WCXYA', 'sms', '2025-10-27 04:54:35', '2025-10-27 04:54:35'),
(35, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Plan Subscription Payment is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;{{amount}} USD&nbsp;is via&nbsp; Manual Transfer&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : {{amount}} USD</p><p>Charge:&nbsp;1.13 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 51.13 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Transaction Number : VKQHOR6WCXYA</p><p>&nbsp;</p><p>Your current Balance is&nbsp;2,960.00 USD</p></p>', 'email', '2025-10-27 04:54:47', '2025-10-27 04:54:47'),
(36, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Plan Subscription Payment is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD Plan Subscription Payment request by Manual Transfer transaction : VKQHOR6WCXYA', 'sms', '2025-10-27 04:54:48', '2025-10-27 04:54:48'),
(37, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Plan Subscription Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;50.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : 50.00 USD</p><p>Charge:&nbsp;1.13 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 51.13 $<br>&nbsp;</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : 64VS34VQW5EJ</p></p>', 'email', '2025-10-27 04:56:43', '2025-10-27 04:56:43'),
(38, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Plan Subscription Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n50.00 USD Plan Subscription payment requested by Manual Transfer. Charge: 1.13 . Trx: 64VS34VQW5EJ', 'sms', '2025-10-27 04:56:44', '2025-10-27 04:56:44'),
(39, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Plan Subscription Payment is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;{{amount}} USD&nbsp;is via&nbsp; Manual Transfer&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : {{amount}} USD</p><p>Charge:&nbsp;1.13 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 51.13 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Transaction Number : 64VS34VQW5EJ</p><p>&nbsp;</p><p>Your current Balance is&nbsp;2,960.00 USD</p></p>', 'email', '2025-10-27 04:56:50', '2025-10-27 04:56:50'),
(40, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Plan Subscription Payment is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD Plan Subscription Payment request by Manual Transfer transaction : 64VS34VQW5EJ', 'sms', '2025-10-27 04:56:51', '2025-10-27 04:56:51'),
(41, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Plan Subscription Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;100.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : 100.00 USD</p><p>Charge:&nbsp;1.25 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 101.25 $<br>&nbsp;</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : FRVKPM4NVCQC</p></p>', 'email', '2025-10-27 04:57:10', '2025-10-27 04:57:10'),
(42, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Plan Subscription Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n100.00 USD Plan Subscription payment requested by Manual Transfer. Charge: 1.25 . Trx: FRVKPM4NVCQC', 'sms', '2025-10-27 04:57:11', '2025-10-27 04:57:11'),
(43, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Plan Subscription Payment Request is Rejected', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment &nbsp;request of&nbsp;100.00 USD&nbsp;is via&nbsp; Manual Transfer has been rejected.<br>&nbsp;</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 101.25 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Charge: 1.25</p><p>Transaction Number was : FRVKPM4NVCQC</p><p>if you have any queries, feel free to contact us.<br>&nbsp;</p><p>&nbsp;</p><p>Your TRX number is wrong<br>&nbsp;</p></p>', 'email', '2025-10-27 04:57:44', '2025-10-27 04:57:44'),
(44, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Plan Subscription Payment Request is Rejected', 'Hi test user (testuser), \r\nAdmin Rejected Your 100.00 USD Plan Subscription Payment request by Manual Transfer\r\n\r\nYour TRX number is wrong', 'sms', '2025-10-27 04:57:45', '2025-10-27 04:57:45'),
(45, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Credit Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your Credit payment request of&nbsp;200.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Credit Payment:</p><p>Amount : 200.00 USD</p><p>Purchase Credit : {{ purchase_credit_count }}</p><p>Charge:&nbsp;1.50 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 201.50 $</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : {{trx}}</p></p>', 'email', '2025-10-27 05:00:20', '2025-10-27 05:00:20'),
(46, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Credit Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n200.00 USD Credit Payment requested by Manual Transfer. Charge: 1.50 . Trx: {{trx}}', 'sms', '2025-10-27 05:00:22', '2025-10-27 05:00:22'),
(47, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Credit Payment is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your credit payment request of&nbsp;{{amount}} USD&nbsp;is via&nbsp; Manual Transfer&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Credit Payment:<br>&nbsp;</p><p>Amount : {{amount}} USD</p><p>Credits: {{ number_of_credit }}</p><p>Charge:&nbsp;1.50 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 201.50 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Transaction Number : {{trx}}<br>&nbsp;</p><p>Your current Balance is&nbsp;2,910.00 USD</p></p>', 'email', '2025-10-27 05:00:37', '2025-10-27 05:00:37'),
(48, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Credit Payment is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD Credit payment request by Manual Transfer transaction : {{trx}}', 'sms', '2025-10-27 05:00:39', '2025-10-27 05:00:39'),
(49, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Credit Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your Credit payment request of&nbsp;300.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Credit Payment:</p><p>Amount : 300.00 USD</p><p>Purchase Credit : {{ purchase_credit_count }}</p><p>Charge:&nbsp;1.75 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 301.75 $</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : {{trx}}</p></p>', 'email', '2025-10-27 05:01:14', '2025-10-27 05:01:14'),
(50, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Credit Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n300.00 USD Credit Payment requested by Manual Transfer. Charge: 1.75 . Trx: {{trx}}', 'sms', '2025-10-27 05:01:15', '2025-10-27 05:01:15'),
(51, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Credit Payment Request is Rejected', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your Credit Payment request of&nbsp;300.00 USD&nbsp;is via&nbsp; Manual Transfer has been rejected.<br>&nbsp;</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 301.75 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Charge: 1.75</p><p>Transaction Number was : {{trx}}</p><p>if you have any queries, feel free to contact us.<br>&nbsp;</p><p>&nbsp;</p><p>Your Trx number is wrong<br>&nbsp;</p></p>', 'email', '2025-10-27 05:01:41', '2025-10-27 05:01:41'),
(52, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Credit Payment Request is Rejected', 'Hi test user (testuser), \r\nAdmin Rejected Your 300.00 USD Credit payment request by Manual Transfer\r\n\r\nYour Trx number is wrong', 'sms', '2025-10-27 05:01:42', '2025-10-27 05:01:42'),
(53, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Deposit Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><div>Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">90.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer&nbsp;</span>submitted successfully<span style=\"font-weight: bolder;\">&nbsp;.<br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : 90.00 USD</div><div>Charge:&nbsp;<font color=\"#FF0000\">1.23 USD</font></div><div><br></div><div>Conversion Rate : 1 USD = 1.00 $</div><div>Payable : 91.23 $<br></div><div>Pay via :&nbsp; Manual Transfer</div><div><br></div><div>Transaction Number : D21XD79H1WOK</div><div><br></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-10-27 05:02:28', '2025-10-27 05:02:28'),
(54, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Deposit Request Submitted Successfully', 'Hi test user (testuser), \r\n90.00 USD Deposit requested by Manual Transfer. Charge: 1.23 . Trx: D21XD79H1WOK', 'sms', '2025-10-27 05:02:29', '2025-10-27 05:02:29'),
(55, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Deposit is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">{{amount}} USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer&nbsp;</span>is Approved .<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : {{amount}} USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">1.23 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 $</div><div style=\"font-family: Montserrat, sans-serif;\">Received : 91.23 $<br></div><div style=\"font-family: Montserrat, sans-serif;\">Paid via :&nbsp; Manual Transfer</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : D21XD79H1WOK</div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\"><span style=\"font-weight: bolder;\"><br></span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">3,000.00 USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div></p>', 'email', '2025-10-27 05:02:36', '2025-10-27 05:02:36'),
(56, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Deposit is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD payment request by Manual Transfer transaction : D21XD79H1WOK', 'sms', '2025-10-27 05:02:37', '2025-10-27 05:02:37'),
(57, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Deposit Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><div>Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">30.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer&nbsp;</span>submitted successfully<span style=\"font-weight: bolder;\">&nbsp;.<br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : 30.00 USD</div><div>Charge:&nbsp;<font color=\"#FF0000\">1.08 USD</font></div><div><br></div><div>Conversion Rate : 1 USD = 1.00 $</div><div>Payable : 31.08 $<br></div><div>Pay via :&nbsp; Manual Transfer</div><div><br></div><div>Transaction Number : 8XN5J7115XQV</div><div><br></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-10-27 05:03:06', '2025-10-27 05:03:06'),
(58, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Deposit Request Submitted Successfully', 'Hi test user (testuser), \r\n30.00 USD Deposit requested by Manual Transfer. Charge: 1.08 . Trx: 8XN5J7115XQV', 'sms', '2025-10-27 05:03:07', '2025-10-27 05:03:07'),
(59, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Deposit Request is Rejected', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">30.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer has been rejected</span>.<span style=\"font-weight: bolder;\"><br></span></div><div><br></div><div><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 $</div><div style=\"font-family: Montserrat, sans-serif;\">Received : 31.08 $<br></div><div style=\"font-family: Montserrat, sans-serif;\">Paid via :&nbsp; Manual Transfer</div><div style=\"font-family: Montserrat, sans-serif;\">Charge: 1.08</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number was : 8XN5J7115XQV</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">if you have any queries, feel free to contact us.<br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><br><br></div><span style=\"color: rgb(33, 37, 41); font-family: Montserrat, sans-serif;\">Your Trx number is wrong</span><br></p>', 'email', '2025-10-27 05:03:26', '2025-10-27 05:03:26'),
(60, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Deposit Request is Rejected', 'Hi test user (testuser), \r\nAdmin Rejected Your 30.00 USD payment request by Manual Transfer\r\n\r\nYour Trx number is wrong', 'sms', '2025-10-27 05:03:28', '2025-10-27 05:03:28'),
(61, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Plan Subscription Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;50.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : 50.00 USD</p><p>Charge:&nbsp;1.13 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 51.13 $<br>&nbsp;</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : 9F7T82PJJMB8</p></p>', 'email', '2025-10-27 05:04:51', '2025-10-27 05:04:51'),
(62, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Plan Subscription Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n50.00 USD Plan Subscription payment requested by Manual Transfer. Charge: 1.13 . Trx: 9F7T82PJJMB8', 'sms', '2025-10-27 05:04:52', '2025-10-27 05:04:52'),
(63, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Plan Subscription Payment is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;{{amount}} USD&nbsp;is via&nbsp; Manual Transfer&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : {{amount}} USD</p><p>Charge:&nbsp;1.13 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 51.13 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Transaction Number : 9F7T82PJJMB8</p><p>&nbsp;</p><p>Your current Balance is&nbsp;3,000.00 USD</p></p>', 'email', '2025-10-27 05:05:09', '2025-10-27 05:05:09'),
(64, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Plan Subscription Payment is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD Plan Subscription Payment request by Manual Transfer transaction : 9F7T82PJJMB8', 'sms', '2025-10-27 05:05:10', '2025-10-27 05:05:10'),
(65, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Plan Subscription Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;100.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : 100.00 USD</p><p>Charge:&nbsp;1.25 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 101.25 $<br>&nbsp;</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : H4343UWU499O</p></p>', 'email', '2025-10-27 05:06:11', '2025-10-27 05:06:11'),
(66, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Plan Subscription Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n100.00 USD Plan Subscription payment requested by Manual Transfer. Charge: 1.25 . Trx: H4343UWU499O', 'sms', '2025-10-27 05:06:13', '2025-10-27 05:06:13'),
(67, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Plan Subscription Payment Request is Rejected', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment &nbsp;request of&nbsp;100.00 USD&nbsp;is via&nbsp; Manual Transfer has been rejected.<br>&nbsp;</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 101.25 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Charge: 1.25</p><p>Transaction Number was : H4343UWU499O</p><p>if you have any queries, feel free to contact us.<br>&nbsp;</p><p>&nbsp;</p><p>Your Trx number is wrong<br>&nbsp;</p></p>', 'email', '2025-10-27 05:06:31', '2025-10-27 05:06:31'),
(68, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Plan Subscription Payment Request is Rejected', 'Hi test user (testuser), \r\nAdmin Rejected Your 100.00 USD Plan Subscription Payment request by Manual Transfer\r\n\r\nYour Trx number is wrong', 'sms', '2025-10-27 05:06:32', '2025-10-27 05:06:32'),
(69, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Plan Subscription Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;50.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : 50.00 USD</p><p>Charge:&nbsp;1.13 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 51.13 $<br>&nbsp;</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : SAM7FE6S71PW</p></p>', 'email', '2025-10-27 06:49:30', '2025-10-27 06:49:30'),
(70, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Plan Subscription Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n50.00 USD Plan Subscription payment requested by Manual Transfer. Charge: 1.13 . Trx: SAM7FE6S71PW', 'sms', '2025-10-27 06:49:32', '2025-10-27 06:49:32'),
(71, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Plan Subscription Payment is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;{{amount}} USD&nbsp;is via&nbsp; Manual Transfer&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : {{amount}} USD</p><p>Charge:&nbsp;1.13 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 51.13 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Transaction Number : SAM7FE6S71PW</p><p>&nbsp;</p><p>Your current Balance is&nbsp;2,300.00 USD</p></p>', 'email', '2025-10-27 06:49:42', '2025-10-27 06:49:42'),
(72, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Plan Subscription Payment is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD Plan Subscription Payment request by Manual Transfer transaction : SAM7FE6S71PW', 'sms', '2025-10-27 06:49:44', '2025-10-27 06:49:44'),
(73, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Plan Subscription Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;300.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : 300.00 USD</p><p>Charge:&nbsp;1.75 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 301.75 $<br>&nbsp;</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : J1TV11UTVKE4</p></p>', 'email', '2025-10-27 07:09:27', '2025-10-27 07:09:27'),
(74, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Plan Subscription Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n300.00 USD Plan Subscription payment requested by Manual Transfer. Charge: 1.75 . Trx: J1TV11UTVKE4', 'sms', '2025-10-27 07:09:28', '2025-10-27 07:09:28'),
(75, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Plan Subscription Payment is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;{{amount}} USD&nbsp;is via&nbsp; Manual Transfer&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : {{amount}} USD</p><p>Charge:&nbsp;1.75 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 301.75 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Transaction Number : J1TV11UTVKE4</p><p>&nbsp;</p><p>Your current Balance is&nbsp;2,200.00 USD</p></p>', 'email', '2025-10-27 07:09:35', '2025-10-27 07:09:35'),
(76, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Plan Subscription Payment is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD Plan Subscription Payment request by Manual Transfer transaction : J1TV11UTVKE4', 'sms', '2025-10-27 07:09:36', '2025-10-27 07:09:36'),
(77, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Withdraw Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your withdraw request of&nbsp;<span style=\"font-weight: bolder;\">30.00 USD</span>&nbsp; via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Bank Transfer&nbsp;</span>has been submitted Successfully.<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your withdraw:<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : 30.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">1.08 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 $</div><div style=\"font-family: Montserrat, sans-serif;\">You will get: 28.93 $<br></div><div style=\"font-family: Montserrat, sans-serif;\">Via :&nbsp; Bank Transfer</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : GCKNMFPTWTPP</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">1,670.00 USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br><br><br></div></p>', 'email', '2025-10-27 07:22:10', '2025-10-27 07:22:10'),
(78, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Withdraw Request Submitted Successfully', 'Hi test user (testuser), \r\n30.00 USD withdraw requested by Bank Transfer. You will get 28.93 $ Trx: GCKNMFPTWTPP', 'sms', '2025-10-27 07:22:15', '2025-10-27 07:22:15'),
(79, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Withdraw Request has been Processed and your money is sent', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your withdraw request of&nbsp;<span style=\"font-weight: bolder;\">30.00 USD</span>&nbsp; via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Bank Transfer&nbsp;</span>has been Processed Successfully.<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your withdraw:<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : 30.00 USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">1.08 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 $</div><div style=\"font-family: Montserrat, sans-serif;\">You will get: 28.93 $<br></div><div style=\"font-family: Montserrat, sans-serif;\">Via :&nbsp; Bank Transfer</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : GCKNMFPTWTPP</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">-----</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\">Details of Processed Payment :</font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\"><span style=\"font-weight: bolder;\">#DIJD34563#</span></font></div></p>', 'email', '2025-10-27 07:23:08', '2025-10-27 07:23:08'),
(80, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Withdraw Request has been Processed and your money is sent', 'Hi test user (testuser), \r\nAdmin Approve Your 30.00 USD withdraw request by Bank Transfer. Transaction GCKNMFPTWTPP', 'sms', '2025-10-27 07:23:10', '2025-10-27 07:23:10'),
(81, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Plan Subscription Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;300.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : 300.00 USD</p><p>Charge:&nbsp;1.75 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 301.75 $<br>&nbsp;</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : QTUDS7XSY5WE</p></p>', 'email', '2025-11-04 02:21:59', '2025-11-04 02:21:59'),
(82, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Plan Subscription Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n300.00 USD Plan Subscription payment requested by Manual Transfer. Charge: 1.75 . Trx: QTUDS7XSY5WE', 'sms', '2025-11-04 02:22:01', '2025-11-04 02:22:01'),
(83, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Plan Subscription Payment is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your plan subscription payment request of&nbsp;{{amount}} USD&nbsp;is via&nbsp; Manual Transfer&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Plan Subscription Payment:<br>&nbsp;</p><p>Amount : {{amount}} USD</p><p>Charge:&nbsp;1.75 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 301.75 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Transaction Number : QTUDS7XSY5WE</p><p>&nbsp;</p><p>Your current Balance is&nbsp;1,620.00 USD</p></p>', 'email', '2025-11-04 02:23:46', '2025-11-04 02:23:46'),
(84, 1, 'clickatell', 'notify@example.com', '939344452354527', 'Your Plan Subscription Payment is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD Plan Subscription Payment request by Manual Transfer transaction : QTUDS7XSY5WE', 'sms', '2025-11-04 02:23:48', '2025-11-04 02:23:48'),
(85, 3, 'php', 'notify@example.com', 'dffd@gmailcom', 'Please verify your email address', '<p>Hi @rtytryerty (rtytryerty),&nbsp;</p><p><br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;369044</span></font></div></div></p>', 'email', '2025-11-05 09:09:54', '2025-11-05 09:09:54'),
(86, 3, 'php', 'notify@example.com', 'dffd@gmailcom', 'Please verify your email address', '<p>Hi @rtytryerty (rtytryerty),&nbsp;</p><p><br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;125597</span></font></div></div></p>', 'email', '2025-11-05 09:11:54', '2025-11-05 09:11:54'),
(87, 3, 'php', 'notify@example.com', 'dffd@gmailcom', 'Please verify your email address', '<p>Hi @rtytryerty (rtytryerty),&nbsp;</p><p><br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;935766</span></font></div></div></p>', 'email', '2025-11-05 09:14:42', '2025-11-05 09:14:42'),
(88, 3, 'php', 'notify@example.com', 'dffd@gmailcom', 'Please verify your email address', '<p>Hi @rtytryerty (rtytryerty),&nbsp;</p><p><br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;452029</span></font></div></div></p>', 'email', '2025-11-05 09:16:59', '2025-11-05 09:16:59'),
(89, 3, 'clickatell', 'notify@example.com', '934563453', 'Verify Your Mobile Number', 'Hi @rtytryerty (rtytryerty), \r\nYour phone verification code is: 342349', 'sms', '2025-11-05 09:18:06', '2025-11-05 09:18:06');
INSERT INTO `notification_logs` (`id`, `user_id`, `sender`, `sent_from`, `sent_to`, `subject`, `message`, `notification_type`, `created_at`, `updated_at`) VALUES
(90, 3, 'php', 'notify@example.com', 'dffd@gmailcom', 'Please verify your email address', '<p>Hi @rtytryerty (rtytryerty),&nbsp;</p><p><br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;622292</span></font></div></div></p>', 'email', '2025-11-05 09:20:07', '2025-11-05 09:20:07'),
(91, 3, 'php', 'notify@example.com', 'dffd@gmailcom', 'Please verify your email address', '<p>Hi @rtytryerty (rtytryerty),&nbsp;</p><p><br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;944675</span></font></div></div></p>', 'email', '2025-11-05 09:22:24', '2025-11-05 09:22:24'),
(92, 3, 'php', 'notify@example.com', 'dffd@gmailcom', 'Please verify your email address', '<p>Hi @rtytryerty (rtytryerty),&nbsp;</p><p><br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;352748</span></font></div></div></p>', 'email', '2025-11-05 09:26:19', '2025-11-05 09:26:19'),
(93, 3, 'php', 'notify@example.com', 'dffd@gmailcom', 'Please verify your email address', '<p>Hi @rtytryerty (rtytryerty),&nbsp;</p><p><br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;204022</span></font></div></div></p>', 'email', '2025-11-05 09:32:37', '2025-11-05 09:32:37'),
(94, 3, 'php', 'notify@example.com', 'dffd@gmailcom', 'Please verify your email address', '<p>Hi @rtytryerty (rtytryerty),&nbsp;</p><p><br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;395532</span></font></div></div></p>', 'email', '2025-11-05 09:44:29', '2025-11-05 09:44:29'),
(95, 3, 'clickatell', 'notify@example.com', '934563453', 'Verify Your Mobile Number', 'Hi @rtytryerty (rtytryerty), \r\nYour phone verification code is: 850454', 'sms', '2025-11-05 09:44:42', '2025-11-05 09:44:42'),
(96, 3, 'clickatell', 'notify@example.com', '934563453', 'Verify Your Mobile Number', 'Hi @rtytryerty (rtytryerty), \r\nYour phone verification code is: 142246', 'sms', '2025-11-05 09:46:52', '2025-11-05 09:46:52'),
(97, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Password Reset', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">We have received a request to reset the password for your account on&nbsp;<span style=\"font-weight: bolder;\">2025-11-05 03:50:41 PM .<br></span></div><div style=\"font-family: Montserrat, sans-serif;\">Requested From IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Chrome</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Windows 10&nbsp;</span>.</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><div>Your account recovery code is:&nbsp;&nbsp;&nbsp;<font size=\"6\"><span style=\"font-weight: bolder;\">425669</span></font></div><div><br></div></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\" color=\"#CC0000\">If you do not wish to reset your password, please disregard this message.&nbsp;</font><br></div><div><font size=\"4\" color=\"#CC0000\"><br></font></div></p>', 'email', '2025-11-05 09:50:41', '2025-11-05 09:50:41'),
(98, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Password Reset', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">We have received a request to reset the password for your account on&nbsp;<span style=\"font-weight: bolder;\">2025-11-05 03:52:42 PM .<br></span></div><div style=\"font-family: Montserrat, sans-serif;\">Requested From IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Chrome</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Windows 10&nbsp;</span>.</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><div>Your account recovery code is:&nbsp;&nbsp;&nbsp;<font size=\"6\"><span style=\"font-weight: bolder;\">455894</span></font></div><div><br></div></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\" color=\"#CC0000\">If you do not wish to reset your password, please disregard this message.&nbsp;</font><br></div><div><font size=\"4\" color=\"#CC0000\"><br></font></div></p>', 'email', '2025-11-05 09:52:42', '2025-11-05 09:52:42'),
(99, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Password Reset', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">We have received a request to reset the password for your account on&nbsp;<span style=\"font-weight: bolder;\">2025-11-05 03:55:08 PM .<br></span></div><div style=\"font-family: Montserrat, sans-serif;\">Requested From IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Chrome</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Windows 10&nbsp;</span>.</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><div>Your account recovery code is:&nbsp;&nbsp;&nbsp;<font size=\"6\"><span style=\"font-weight: bolder;\">350009</span></font></div><div><br></div></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\" color=\"#CC0000\">If you do not wish to reset your password, please disregard this message.&nbsp;</font><br></div><div><font size=\"4\" color=\"#CC0000\"><br></font></div></p>', 'email', '2025-11-05 09:55:08', '2025-11-05 09:55:08'),
(100, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Password Reset', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">We have received a request to reset the password for your account on&nbsp;<span style=\"font-weight: bolder;\">2025-11-05 03:57:08 PM .<br></span></div><div style=\"font-family: Montserrat, sans-serif;\">Requested From IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Chrome</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Windows 10&nbsp;</span>.</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><div>Your account recovery code is:&nbsp;&nbsp;&nbsp;<font size=\"6\"><span style=\"font-weight: bolder;\">697528</span></font></div><div><br></div></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\" color=\"#CC0000\">If you do not wish to reset your password, please disregard this message.&nbsp;</font><br></div><div><font size=\"4\" color=\"#CC0000\"><br></font></div></p>', 'email', '2025-11-05 09:57:08', '2025-11-05 09:57:08'),
(101, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'You have reset your password', '<p>Hi test user (testuser),&nbsp;</p><p><p style=\"font-family: Montserrat, sans-serif;\">You have successfully reset your password.</p><p style=\"font-family: Montserrat, sans-serif;\">You changed from&nbsp; IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Chrome</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Windows 10&nbsp;</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">2025-11-05 03:58:24 PM</span></p><p style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></p><p style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><font color=\"#ff0000\">If you did not change that, please contact us as soon as possible.</font></span></p></p>', 'email', '2025-11-05 09:58:24', '2025-11-05 09:58:24'),
(102, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Credit Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your Credit payment request of&nbsp;240.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Credit Payment:</p><p>Amount : 240.00 USD</p><p>Purchase Credit : {{ purchase_credit_count }}</p><p>Charge:&nbsp;1.60 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 241.60 $</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : {{trx}}</p></p>', 'email', '2025-11-06 04:48:34', '2025-11-06 04:48:34'),
(103, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Credit Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n240.00 USD Credit Payment requested by Manual Transfer. Charge: 1.60 . Trx: {{trx}}', 'sms', '2025-11-06 04:48:35', '2025-11-06 04:48:35'),
(104, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Credit Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your Credit payment request of&nbsp;240.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Credit Payment:</p><p>Amount : 240.00 USD</p><p>Purchase Credit : {{ purchase_credit_count }}</p><p>Charge:&nbsp;1.60 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 241.60 $</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : {{trx}}</p></p>', 'email', '2025-11-09 03:00:46', '2025-11-09 03:00:46'),
(105, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Credit Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n240.00 USD Credit Payment requested by Manual Transfer. Charge: 1.60 . Trx: {{trx}}', 'sms', '2025-11-09 03:00:48', '2025-11-09 03:00:48'),
(106, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Credit Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your Credit payment request of&nbsp;200.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Credit Payment:</p><p>Amount : 200.00 USD</p><p>Purchase Credit : {{ purchase_credit_count }}</p><p>Charge:&nbsp;1.50 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 201.50 $</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : {{trx}}</p></p>', 'email', '2025-11-09 03:10:18', '2025-11-09 03:10:18'),
(107, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Credit Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n200.00 USD Credit Payment requested by Manual Transfer. Charge: 1.50 . Trx: {{trx}}', 'sms', '2025-11-09 03:10:19', '2025-11-09 03:10:19'),
(108, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Credit Payment is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your credit payment request of&nbsp;{{amount}} USD&nbsp;is via&nbsp; Manual Transfer&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Credit Payment:<br>&nbsp;</p><p>Amount : {{amount}} USD</p><p>Credits: {{ number_of_credit }}</p><p>Charge:&nbsp;1.60 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 241.60 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Transaction Number : {{trx}}<br>&nbsp;</p><p>Your current Balance is&nbsp;1,020.00 USD</p></p>', 'email', '2025-11-09 03:13:04', '2025-11-09 03:13:04'),
(109, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Your Credit Payment is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD Credit payment request by Manual Transfer transaction : {{trx}}', 'sms', '2025-11-09 03:13:05', '2025-11-09 03:13:05'),
(110, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Credit Payment is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your credit payment request of&nbsp;{{amount}} USD&nbsp;is via&nbsp; Manual Transfer&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Credit Payment:<br>&nbsp;</p><p>Amount : {{amount}} USD</p><p>Credits: {{ number_of_credit }}</p><p>Charge:&nbsp;1.50 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 201.50 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Transaction Number : {{trx}}<br>&nbsp;</p><p>Your current Balance is&nbsp;1,020.00 USD</p></p>', 'email', '2025-11-09 03:13:54', '2025-11-09 03:13:54'),
(111, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Your Credit Payment is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD Credit payment request by Manual Transfer transaction : {{trx}}', 'sms', '2025-11-09 03:13:55', '2025-11-09 03:13:55'),
(112, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Credit Payment Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your Credit payment request of&nbsp;200.00 USD&nbsp;is via&nbsp; Manual Transfer&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Credit Payment:</p><p>Amount : 200.00 USD</p><p>Purchase Credit : {{ purchase_credit_count }}</p><p>Charge:&nbsp;1.50 USD</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Payable : 201.50 $</p><p>Pay via :&nbsp; Manual Transfer</p><p>Transaction Number : {{trx}}</p></p>', 'email', '2025-11-09 03:14:56', '2025-11-09 03:14:56'),
(113, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Credit Payment Request Submitted Successfully', 'Hi test user (testuser), \r\n200.00 USD Credit Payment requested by Manual Transfer. Charge: 1.50 . Trx: {{trx}}', 'sms', '2025-11-09 03:14:58', '2025-11-09 03:14:58'),
(114, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Credit Payment Request is Rejected', '<p>Hi test user (testuser),&nbsp;</p><p><p>Your Credit Payment request of&nbsp;200.00 USD&nbsp;is via&nbsp; Manual Transfer has been rejected.<br>&nbsp;</p><p>Conversion Rate : 1 USD = 1.00 $</p><p>Received : 201.50 $<br>&nbsp;</p><p>Paid via :&nbsp; Manual Transfer</p><p>Charge: 1.50</p><p>Transaction Number was : {{trx}}</p><p>if you have any queries, feel free to contact us.<br>&nbsp;</p><p>&nbsp;</p><p>zxcvzvdfsvzf<br>&nbsp;</p></p>', 'email', '2025-11-09 03:15:17', '2025-11-09 03:15:17'),
(115, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Your Credit Payment Request is Rejected', 'Hi test user (testuser), \r\nAdmin Rejected Your 200.00 USD Credit payment request by Manual Transfer\r\n\r\nzxcvzvdfsvzf', 'sms', '2025-11-09 03:15:19', '2025-11-09 03:15:19'),
(116, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Deposit Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><div>Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">210.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer&nbsp;</span>submitted successfully<span style=\"font-weight: bolder;\">&nbsp;.<br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : 210.00 USD</div><div>Charge:&nbsp;<font color=\"#FF0000\">1.53 USD</font></div><div><br></div><div>Conversion Rate : 1 USD = 1.00 $</div><div>Payable : 211.53 $<br></div><div>Pay via :&nbsp; Manual Transfer</div><div><br></div><div>Transaction Number : SOSOFWDVQR34</div><div><br></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-11-09 03:19:33', '2025-11-09 03:19:33'),
(117, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Deposit Request Submitted Successfully', 'Hi test user (testuser), \r\n210.00 USD Deposit requested by Manual Transfer. Charge: 1.53 . Trx: SOSOFWDVQR34', 'sms', '2025-11-09 03:19:34', '2025-11-09 03:19:34'),
(118, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Deposit is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">{{amount}} USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer&nbsp;</span>is Approved .<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : {{amount}} USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">1.53 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 $</div><div style=\"font-family: Montserrat, sans-serif;\">Received : 211.53 $<br></div><div style=\"font-family: Montserrat, sans-serif;\">Paid via :&nbsp; Manual Transfer</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : SOSOFWDVQR34</div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\"><span style=\"font-weight: bolder;\"><br></span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">1,020.00 USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div></p>', 'email', '2025-11-09 03:19:48', '2025-11-09 03:19:48'),
(119, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Your Deposit is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD payment request by Manual Transfer transaction : SOSOFWDVQR34', 'sms', '2025-11-09 03:19:49', '2025-11-09 03:19:49'),
(120, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Deposit Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><div>Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">30.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer&nbsp;</span>submitted successfully<span style=\"font-weight: bolder;\">&nbsp;.<br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : 30.00 USD</div><div>Charge:&nbsp;<font color=\"#FF0000\">1.08 USD</font></div><div><br></div><div>Conversion Rate : 1 USD = 1.00 $</div><div>Payable : 31.08 $<br></div><div>Pay via :&nbsp; Manual Transfer</div><div><br></div><div>Transaction Number : QOBCZWMQNM1E</div><div><br></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-11-09 03:20:28', '2025-11-09 03:20:28'),
(121, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Deposit Request Submitted Successfully', 'Hi test user (testuser), \r\n30.00 USD Deposit requested by Manual Transfer. Charge: 1.08 . Trx: QOBCZWMQNM1E', 'sms', '2025-11-09 03:20:30', '2025-11-09 03:20:30'),
(122, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Deposit is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">{{amount}} USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer&nbsp;</span>is Approved .<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : {{amount}} USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">1.08 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 $</div><div style=\"font-family: Montserrat, sans-serif;\">Received : 31.08 $<br></div><div style=\"font-family: Montserrat, sans-serif;\">Paid via :&nbsp; Manual Transfer</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : QOBCZWMQNM1E</div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\"><span style=\"font-weight: bolder;\"><br></span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">1,020.00 USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div></p>', 'email', '2025-11-09 03:20:56', '2025-11-09 03:20:56'),
(123, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Your Deposit is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD payment request by Manual Transfer transaction : QOBCZWMQNM1E', 'sms', '2025-11-09 03:20:58', '2025-11-09 03:20:58'),
(124, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Deposit Request Submitted Successfully', '<p>Hi test user (testuser),&nbsp;</p><p><div>Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">50.00 USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer&nbsp;</span>submitted successfully<span style=\"font-weight: bolder;\">&nbsp;.<br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : 50.00 USD</div><div>Charge:&nbsp;<font color=\"#FF0000\">1.13 USD</font></div><div><br></div><div>Conversion Rate : 1 USD = 1.00 $</div><div>Payable : 51.13 $<br></div><div>Pay via :&nbsp; Manual Transfer</div><div><br></div><div>Transaction Number : 46M8VKRKJ2AW</div><div><br></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div></p>', 'email', '2025-11-09 03:21:53', '2025-11-09 03:21:53'),
(125, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Deposit Request Submitted Successfully', 'Hi test user (testuser), \r\n50.00 USD Deposit requested by Manual Transfer. Charge: 1.13 . Trx: 46M8VKRKJ2AW', 'sms', '2025-11-09 03:21:54', '2025-11-09 03:21:54'),
(126, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Your Deposit is Approved', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">{{amount}} USD</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">Manual Transfer&nbsp;</span>is Approved .<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : {{amount}} USD</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">1.13 USD</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 USD = 1.00 $</div><div style=\"font-family: Montserrat, sans-serif;\">Received : 51.13 $<br></div><div style=\"font-family: Montserrat, sans-serif;\">Paid via :&nbsp; Manual Transfer</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : 46M8VKRKJ2AW</div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\"><span style=\"font-weight: bolder;\"><br></span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">1,070.00 USD</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div></p>', 'email', '2025-11-09 03:22:03', '2025-11-09 03:22:03'),
(127, 1, 'clickatell', 'notify@example.com', '355939344452354527', 'Your Deposit is Approved', 'Hi test user (testuser), \r\nAdmin Approve Your {{amount}} USD payment request by Manual Transfer transaction : 46M8VKRKJ2AW', 'sms', '2025-11-09 03:22:05', '2025-11-09 03:22:05'),
(128, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'Password Reset', '<p>Hi test user (testuser),&nbsp;</p><p><div style=\"font-family: Montserrat, sans-serif;\">We have received a request to reset the password for your account on&nbsp;<span style=\"font-weight: bolder;\">2025-11-15 06:51:01 AM .<br></span></div><div style=\"font-family: Montserrat, sans-serif;\">Requested From IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Chrome</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Windows 10&nbsp;</span>.</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><div>Your account recovery code is:&nbsp;&nbsp;&nbsp;<font size=\"6\"><span style=\"font-weight: bolder;\">723997</span></font></div><div><br></div></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\" color=\"#CC0000\">If you do not wish to reset your password, please disregard this message.&nbsp;</font><br></div><div><font size=\"4\" color=\"#CC0000\"><br></font></div></p>', 'email', '2025-11-15 00:51:02', '2025-11-15 00:51:02'),
(129, 1, 'php', 'notify@example.com', 'testuser@gmail.com', 'You have reset your password', '<p>Hi test user (testuser),&nbsp;</p><p><p style=\"font-family: Montserrat, sans-serif;\">You have successfully reset your password.</p><p style=\"font-family: Montserrat, sans-serif;\">You changed from&nbsp; IP:&nbsp;<span style=\"font-weight: bolder;\">127.0.0.1</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">Chrome</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">Windows 10&nbsp;</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">2025-11-15 06:52:02 AM</span></p><p style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></p><p style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><font color=\"#ff0000\">If you did not change that, please contact us as soon as possible.</font></span></p></p>', 'email', '2025-11-15 00:52:02', '2025-11-15 00:52:02');

-- --------------------------------------------------------

--
-- Table structure for table `notification_templates`
--

CREATE TABLE `notification_templates` (
  `id` bigint UNSIGNED NOT NULL,
  `act` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `subj` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `email_body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `sms_body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `shortcodes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `email_status` tinyint(1) NOT NULL DEFAULT '1',
  `sms_status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notification_templates`
--

INSERT INTO `notification_templates` (`id`, `act`, `name`, `subj`, `email_body`, `sms_body`, `shortcodes`, `email_status`, `sms_status`, `created_at`, `updated_at`) VALUES
(1, 'BAL_ADD', 'Balance - Added', 'Your Account has been Credited', '<div><div style=\"font-family: Montserrat, sans-serif;\">{{amount}} {{site_currency}} has been added to your account .</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : {{trx}}</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><span style=\"color: rgb(33, 37, 41); font-family: Montserrat, sans-serif;\">Your Current Balance is :&nbsp;</span><font style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">{{post_balance}}&nbsp; {{site_currency}}&nbsp;</span></font><br></div><div><font style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></font></div><div>Admin note:&nbsp;<span style=\"color: rgb(33, 37, 41); font-size: 12px; font-weight: 600; white-space: nowrap; text-align: var(--bs-body-text-align);\">{{remark}}</span></div>', '{{amount}} {{site_currency}} credited in your account. Your Current Balance {{post_balance}} {{site_currency}} . Transaction: #{{trx}}. Admin note is \"{{remark}}\"', '{\"trx\":\"Transaction number for the action\",\"amount\":\"Amount inserted by the admin\",\"remark\":\"Remark inserted by the admin\",\"post_balance\":\"Balance of the user after this transaction\"}', 1, 0, '2021-11-03 12:00:00', '2022-09-21 13:04:13'),
(2, 'BAL_SUB', 'Balance - Subtracted', 'Your Account has been Debited', '<div style=\"font-family: Montserrat, sans-serif;\">{{amount}} {{site_currency}} has been subtracted from your account .</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : {{trx}}</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><span style=\"color: rgb(33, 37, 41); font-family: Montserrat, sans-serif;\">Your Current Balance is :&nbsp;</span><font style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">{{post_balance}}&nbsp; {{site_currency}}</span></font><br><div><font style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></font></div><div>Admin Note: {{remark}}</div>', '{{amount}} {{site_currency}} debited from your account. Your Current Balance {{post_balance}} {{site_currency}} . Transaction: #{{trx}}. Admin Note is {{remark}}', '{\"trx\":\"Transaction number for the action\",\"amount\":\"Amount inserted by the admin\",\"remark\":\"Remark inserted by the admin\",\"post_balance\":\"Balance of the user after this transaction\"}', 1, 1, '2021-11-03 12:00:00', '2022-04-03 02:24:11'),
(3, 'DEPOSIT_COMPLETE', 'Deposit - Automated - Successful', 'Deposit Completed Successfully', '<div>Your deposit of&nbsp;<span style=\"font-weight: bolder;\">{{amount}} {{site_currency}}</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">{{method_name}}&nbsp;</span>has been completed Successfully.<span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : {{amount}} {{site_currency}}</div><div>Charge:&nbsp;<font color=\"#000000\">{{charge}} {{site_currency}}</font></div><div><br></div><div>Conversion Rate : 1 {{site_currency}} = {{rate}} {{method_currency}}</div><div>Received : {{method_amount}} {{method_currency}}<br></div><div>Paid via :&nbsp; {{method_name}}</div><div><br></div><div>Transaction Number : {{trx}}</div><div><font size=\"5\"><span style=\"font-weight: bolder;\"><br></span></font></div><div><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">{{post_balance}} {{site_currency}}</span></font></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div>', '{{amount}} {{site_currency}} Deposit successfully by {{method_name}}', '{\"trx\":\"Transaction number for the deposit\",\"amount\":\"Amount inserted by the user\",\"charge\":\"Gateway charge set by the admin\",\"rate\":\"Conversion rate between base currency and method currency\",\"method_name\":\"Name of the deposit method\",\"method_currency\":\"Currency of the deposit method\",\"method_amount\":\"Amount after conversion between base currency and method currency\",\"post_balance\":\"Balance of the user after this transaction\"}', 1, 1, '2021-11-03 12:00:00', '2022-04-03 02:25:43'),
(4, 'DEPOSIT_APPROVE', 'Deposit - Manual - Approved', 'Your Deposit is Approved', '<div style=\"font-family: Montserrat, sans-serif;\">Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">{{amount}} {{site_currency}}</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">{{method_name}}&nbsp;</span>is Approved .<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : {{amount}} {{site_currency}}</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">{{charge}} {{site_currency}}</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 {{site_currency}} = {{rate}} {{method_currency}}</div><div style=\"font-family: Montserrat, sans-serif;\">Received : {{method_amount}} {{method_currency}}<br></div><div style=\"font-family: Montserrat, sans-serif;\">Paid via :&nbsp; {{method_name}}</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : {{trx}}</div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\"><span style=\"font-weight: bolder;\"><br></span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">{{post_balance}} {{site_currency}}</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div>', 'Admin Approve Your {{amount}} {{site_currency}} payment request by {{method_name}} transaction : {{trx}}', '{\"trx\":\"Transaction number for the deposit\",\"amount\":\"Amount inserted by the user\",\"charge\":\"Gateway charge set by the admin\",\"rate\":\"Conversion rate between base currency and method currency\",\"method_name\":\"Name of the deposit method\",\"method_currency\":\"Currency of the deposit method\",\"method_amount\":\"Amount after conversion between base currency and method currency\",\"post_balance\":\"Balance of the user after this transaction\"}', 1, 1, '2021-11-03 12:00:00', '2022-04-03 02:26:07'),
(5, 'DEPOSIT_REJECT', 'Deposit - Manual - Rejected', 'Your Deposit Request is Rejected', '<div style=\"font-family: Montserrat, sans-serif;\">Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">{{amount}} {{site_currency}}</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">{{method_name}} has been rejected</span>.<span style=\"font-weight: bolder;\"><br></span></div><div><br></div><div><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 {{site_currency}} = {{rate}} {{method_currency}}</div><div style=\"font-family: Montserrat, sans-serif;\">Received : {{method_amount}} {{method_currency}}<br></div><div style=\"font-family: Montserrat, sans-serif;\">Paid via :&nbsp; {{method_name}}</div><div style=\"font-family: Montserrat, sans-serif;\">Charge: {{charge}}</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number was : {{trx}}</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">if you have any queries, feel free to contact us.<br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><br><br></div><span style=\"color: rgb(33, 37, 41); font-family: Montserrat, sans-serif;\">{{rejection_message}}</span><br>', 'Admin Rejected Your {{amount}} {{site_currency}} payment request by {{method_name}}\r\n\r\n{{rejection_message}}', '{\"trx\":\"Transaction number for the deposit\",\"amount\":\"Amount inserted by the user\",\"charge\":\"Gateway charge set by the admin\",\"rate\":\"Conversion rate between base currency and method currency\",\"method_name\":\"Name of the deposit method\",\"method_currency\":\"Currency of the deposit method\",\"method_amount\":\"Amount after conversion between base currency and method currency\",\"rejection_message\":\"Rejection message by the admin\"}', 1, 1, '2021-11-03 12:00:00', '2022-04-05 03:45:27'),
(6, 'DEPOSIT_REQUEST', 'Deposit - Manual - Requested', 'Deposit Request Submitted Successfully', '<div>Your deposit request of&nbsp;<span style=\"font-weight: bolder;\">{{amount}} {{site_currency}}</span>&nbsp;is via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">{{method_name}}&nbsp;</span>submitted successfully<span style=\"font-weight: bolder;\">&nbsp;.<br></span></div><div><span style=\"font-weight: bolder;\"><br></span></div><div><span style=\"font-weight: bolder;\">Details of your Deposit :<br></span></div><div><br></div><div>Amount : {{amount}} {{site_currency}}</div><div>Charge:&nbsp;<font color=\"#FF0000\">{{charge}} {{site_currency}}</font></div><div><br></div><div>Conversion Rate : 1 {{site_currency}} = {{rate}} {{method_currency}}</div><div>Payable : {{method_amount}} {{method_currency}}<br></div><div>Pay via :&nbsp; {{method_name}}</div><div><br></div><div>Transaction Number : {{trx}}</div><div><br></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div>', '{{amount}} {{site_currency}} Deposit requested by {{method_name}}. Charge: {{charge}} . Trx: {{trx}}', '{\"trx\":\"Transaction number for the deposit\",\"amount\":\"Amount inserted by the user\",\"charge\":\"Gateway charge set by the admin\",\"rate\":\"Conversion rate between base currency and method currency\",\"method_name\":\"Name of the deposit method\",\"method_currency\":\"Currency of the deposit method\",\"method_amount\":\"Amount after conversion between base currency and method currency\"}', 1, 1, '2021-11-03 12:00:00', '2022-04-03 02:29:19'),
(7, 'PASS_RESET_CODE', 'Password - Reset - Code', 'Password Reset', '<div style=\"font-family: Montserrat, sans-serif;\">We have received a request to reset the password for your account on&nbsp;<span style=\"font-weight: bolder;\">{{time}} .<br></span></div><div style=\"font-family: Montserrat, sans-serif;\">Requested From IP:&nbsp;<span style=\"font-weight: bolder;\">{{ip}}</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">{{browser}}</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">{{operating_system}}&nbsp;</span>.</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><br style=\"font-family: Montserrat, sans-serif;\"><div style=\"font-family: Montserrat, sans-serif;\"><div>Your account recovery code is:&nbsp;&nbsp;&nbsp;<font size=\"6\"><span style=\"font-weight: bolder;\">{{code}}</span></font></div><div><br></div></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\" color=\"#CC0000\">If you do not wish to reset your password, please disregard this message.&nbsp;</font><br></div><div><font size=\"4\" color=\"#CC0000\"><br></font></div>', 'Your account recovery code is: {{code}}', '{\"code\":\"Verification code for password reset\",\"ip\":\"IP address of the user\",\"browser\":\"Browser of the user\",\"operating_system\":\"Operating system of the user\",\"time\":\"Time of the request\"}', 1, 0, '2021-11-03 12:00:00', '2022-03-20 20:47:05'),
(8, 'PASS_RESET_DONE', 'Password - Reset - Confirmation', 'You have reset your password', '<p style=\"font-family: Montserrat, sans-serif;\">You have successfully reset your password.</p><p style=\"font-family: Montserrat, sans-serif;\">You changed from&nbsp; IP:&nbsp;<span style=\"font-weight: bolder;\">{{ip}}</span>&nbsp;using&nbsp;<span style=\"font-weight: bolder;\">{{browser}}</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">{{operating_system}}&nbsp;</span>&nbsp;on&nbsp;<span style=\"font-weight: bolder;\">{{time}}</span></p><p style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></p><p style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><font color=\"#ff0000\">If you did not change that, please contact us as soon as possible.</font></span></p>', 'Your password has been changed successfully', '{\"ip\":\"IP address of the user\",\"browser\":\"Browser of the user\",\"operating_system\":\"Operating system of the user\",\"time\":\"Time of the request\"}', 1, 1, '2021-11-03 12:00:00', '2022-04-05 03:46:35'),
(9, 'ADMIN_SUPPORT_REPLY', 'Support - Reply', 'Reply Support Ticket', '<div><p><span data-mce-style=\"font-size: 11pt;\" style=\"font-size: 11pt;\"><span style=\"font-weight: bolder;\">A member from our support team has replied to the following ticket:</span></span></p><p><span style=\"font-weight: bolder;\"><span data-mce-style=\"font-size: 11pt;\" style=\"font-size: 11pt;\"><span style=\"font-weight: bolder;\"><br></span></span></span></p><p><span style=\"font-weight: bolder;\">[Ticket#{{ticket_id}}] {{ticket_subject}}<br><br>Click here to reply:&nbsp; {{link}}</span></p><p>----------------------------------------------</p><p>Here is the reply :<br></p><p>{{reply}}<br></p></div><div><br style=\"font-family: Montserrat, sans-serif;\"></div>', 'Your Ticket#{{ticket_id}} :  {{ticket_subject}} has been replied.', '{\"ticket_id\":\"ID of the support ticket\",\"ticket_subject\":\"Subject  of the support ticket\",\"reply\":\"Reply made by the admin\",\"link\":\"URL to view the support ticket\"}', 1, 1, '2021-11-03 12:00:00', '2022-03-20 20:47:51'),
(10, 'EVER_CODE', 'Verification - Email', 'Please verify your email address', '<br><div><div style=\"font-family: Montserrat, sans-serif;\">Thanks For joining us.<br></div><div style=\"font-family: Montserrat, sans-serif;\">Please use the below code to verify your email address.<br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Your email verification code is:<font size=\"6\"><span style=\"font-weight: bolder;\">&nbsp;{{code}}</span></font></div></div>', '---', '{\"code\":\"Email verification code\"}', 1, 0, '2021-11-03 12:00:00', '2022-04-03 02:32:07'),
(11, 'SVER_CODE', 'Verification - SMS', 'Verify Your Mobile Number', '---', 'Your phone verification code is: {{code}}', '{\"code\":\"SMS Verification Code\"}', 0, 1, '2021-11-03 12:00:00', '2022-03-20 19:24:37'),
(12, 'WITHDRAW_APPROVE', 'Withdraw - Approved', 'Withdraw Request has been Processed and your money is sent', '<div style=\"font-family: Montserrat, sans-serif;\">Your withdraw request of&nbsp;<span style=\"font-weight: bolder;\">{{amount}} {{site_currency}}</span>&nbsp; via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">{{method_name}}&nbsp;</span>has been Processed Successfully.<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your withdraw:<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : {{amount}} {{site_currency}}</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">{{charge}} {{site_currency}}</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 {{site_currency}} = {{rate}} {{method_currency}}</div><div style=\"font-family: Montserrat, sans-serif;\">You will get: {{method_amount}} {{method_currency}}<br></div><div style=\"font-family: Montserrat, sans-serif;\">Via :&nbsp; {{method_name}}</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : {{trx}}</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">-----</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\">Details of Processed Payment :</font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\"><span style=\"font-weight: bolder;\">{{admin_details}}</span></font></div>', 'Admin Approve Your {{amount}} {{site_currency}} withdraw request by {{method_name}}. Transaction {{trx}}', '{\"trx\":\"Transaction number for the withdraw\",\"amount\":\"Amount requested by the user\",\"charge\":\"Gateway charge set by the admin\",\"rate\":\"Conversion rate between base currency and method currency\",\"method_name\":\"Name of the withdraw method\",\"method_currency\":\"Currency of the withdraw method\",\"method_amount\":\"Amount after conversion between base currency and method currency\",\"admin_details\":\"Details provided by the admin\"}', 1, 1, '2021-11-03 12:00:00', '2022-03-20 20:50:16'),
(13, 'WITHDRAW_REJECT', 'Withdraw - Rejected', 'Withdraw Request has been Rejected and your money is refunded to your account', '<div style=\"font-family: Montserrat, sans-serif;\">Your withdraw request of&nbsp;<span style=\"font-weight: bolder;\">{{amount}} {{site_currency}}</span>&nbsp; via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">{{method_name}}&nbsp;</span>has been Rejected.<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your withdraw:<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : {{amount}} {{site_currency}}</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">{{charge}} {{site_currency}}</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 {{site_currency}} = {{rate}} {{method_currency}}</div><div style=\"font-family: Montserrat, sans-serif;\">You should get: {{method_amount}} {{method_currency}}<br></div><div style=\"font-family: Montserrat, sans-serif;\">Via :&nbsp; {{method_name}}</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : {{trx}}</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">----</div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"3\"><br></font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"3\">{{amount}} {{currency}} has been&nbsp;<span style=\"font-weight: bolder;\">refunded&nbsp;</span>to your account and your current Balance is&nbsp;<span style=\"font-weight: bolder;\">{{post_balance}}</span><span style=\"font-weight: bolder;\">&nbsp;{{site_currency}}</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">-----</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\">Details of Rejection :</font></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"4\"><span style=\"font-weight: bolder;\">{{admin_details}}</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br><br><br><br><br></div><div></div><div></div>', 'Admin Rejected Your {{amount}} {{site_currency}} withdraw request. Your Main Balance {{post_balance}}  {{method_name}} , Transaction {{trx}}', '{\"trx\":\"Transaction number for the withdraw\",\"amount\":\"Amount requested by the user\",\"charge\":\"Gateway charge set by the admin\",\"rate\":\"Conversion rate between base currency and method currency\",\"method_name\":\"Name of the withdraw method\",\"method_currency\":\"Currency of the withdraw method\",\"method_amount\":\"Amount after conversion between base currency and method currency\",\"post_balance\":\"Balance of the user after fter this action\",\"admin_details\":\"Rejection message by the admin\"}', 1, 1, '2021-11-03 12:00:00', '2022-03-20 20:57:46'),
(14, 'WITHDRAW_REQUEST', 'Withdraw - Requested', 'Withdraw Request Submitted Successfully', '<div style=\"font-family: Montserrat, sans-serif;\">Your withdraw request of&nbsp;<span style=\"font-weight: bolder;\">{{amount}} {{site_currency}}</span>&nbsp; via&nbsp;&nbsp;<span style=\"font-weight: bolder;\">{{method_name}}&nbsp;</span>has been submitted Successfully.<span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\"><br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><span style=\"font-weight: bolder;\">Details of your withdraw:<br></span></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Amount : {{amount}} {{site_currency}}</div><div style=\"font-family: Montserrat, sans-serif;\">Charge:&nbsp;<font color=\"#FF0000\">{{charge}} {{site_currency}}</font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Conversion Rate : 1 {{site_currency}} = {{rate}} {{method_currency}}</div><div style=\"font-family: Montserrat, sans-serif;\">You will get: {{method_amount}} {{method_currency}}<br></div><div style=\"font-family: Montserrat, sans-serif;\">Via :&nbsp; {{method_name}}</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\">Transaction Number : {{trx}}</div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><font size=\"5\">Your current Balance is&nbsp;<span style=\"font-weight: bolder;\">{{post_balance}} {{site_currency}}</span></font></div><div style=\"font-family: Montserrat, sans-serif;\"><br></div><div style=\"font-family: Montserrat, sans-serif;\"><br><br><br></div>', '{{amount}} {{site_currency}} withdraw requested by {{method_name}}. You will get {{method_amount}} {{method_currency}} Trx: {{trx}}', '{\"trx\":\"Transaction number for the withdraw\",\"amount\":\"Amount requested by the user\",\"charge\":\"Gateway charge set by the admin\",\"rate\":\"Conversion rate between base currency and method currency\",\"method_name\":\"Name of the withdraw method\",\"method_currency\":\"Currency of the withdraw method\",\"method_amount\":\"Amount after conversion between base currency and method currency\",\"post_balance\":\"Balance of the user after fter this transaction\"}', 1, 1, '2021-11-03 12:00:00', '2022-03-21 04:39:03'),
(15, 'DEFAULT', 'Default Template', '{{subject}}', '{{message}}', '{{message}}', '{\"subject\":\"Subject\",\"message\":\"Message\"}', 1, 1, '2019-09-14 13:14:22', '2021-11-04 09:38:55'),
(18, 'CREDIT_PAYMENT_REQUEST', 'Credit Payment- Manual - Requested', 'Credit Payment Request Submitted Successfully', '<p>Your Credit payment request of&nbsp;{{amount}} {{site_currency}}&nbsp;is via&nbsp; {{method_name}}&nbsp;submitted successfully&nbsp;.<br>&nbsp;</p><p>Details of your Credit Payment:</p><p>Amount : {{amount}} {{site_currency}}</p><p>Purchase Credit : {{ purchase_credit_count }}</p><p>Charge:&nbsp;{{charge}} {{site_currency}}</p><p>Conversion Rate : 1 {{site_currency}} = {{rate}} {{method_currency}}</p><p>Payable : {{method_amount}} {{method_currency}}</p><p>Pay via :&nbsp; {{method_name}}</p><p>Transaction Number : {{trx}}</p>', '{{amount}} {{site_currency}} Credit Payment requested by {{method_name}}. Charge: {{charge}} . Trx: {{trx}}', '{\"trx\":\"Transaction number for the deposit\",\"purchase_credit_count\":\"Credit Purchase Count\",\"amount\":\"Amount inserted by the user\",\"charge\":\"Gateway charge set by the admin\",\"rate\":\"Conversion rate between base currency and method currency\",\"method_name\":\"Name of the deposit method\",\"method_currency\":\"Currency of the deposit method\",\"method_amount\":\"Amount after conversion between base currency and method currency\"}', 1, 1, NULL, '2025-10-26 07:36:23'),
(19, 'CREDIT_PAYMENT_APPROVE', 'Credit Payment- Manual - Approved', 'Your Credit Payment is Approved', '<p>Your credit payment request of&nbsp;{{amount}} {{site_currency}}&nbsp;is via&nbsp; {{method_name}}&nbsp;is Approved .<br>&nbsp;</p><p>Details of your Credit Payment:<br>&nbsp;</p><p>Amount : {{amount}} {{site_currency}}</p><p>Credits: {{ number_of_credit }}</p><p>Charge:&nbsp;{{charge}} {{site_currency}}</p><p>Conversion Rate : 1 {{site_currency}} = {{rate}} {{method_currency}}</p><p>Received : {{method_amount}} {{method_currency}}<br>&nbsp;</p><p>Paid via :&nbsp; {{method_name}}</p><p>Transaction Number : {{trx}}<br>&nbsp;</p><p>Your current Balance is&nbsp;{{post_balance}} {{site_currency}}</p>', 'Admin Approve Your {{amount}} {{site_currency}} Credit payment request by {{method_name}} transaction : {{trx}}', '{\"trx\":\"Transaction number for the deposit\",\"number_of_credit\":\"Number of credit\",\"amount\":\"Amount inserted by the user\",\"charge\":\"Gateway charge set by the admin\",\"rate\":\"Conversion rate between base currency and method currency\",\"method_name\":\"Name of the deposit method\",\"method_currency\":\"Currency of the deposit method\",\"method_amount\":\"Amount after conversion between base currency and method currency\",\"post_balance\":\"Balance of the user after this transaction\"}', 1, 1, NULL, '2025-10-26 07:27:46'),
(20, 'CREDIT_PAYMENT_REJECT', 'Credit Payment- Manual - Rejected', 'Your Credit Payment Request is Rejected', '<p>Your Credit Payment request of&nbsp;{{amount}} {{site_currency}}&nbsp;is via&nbsp; {{method_name}} has been rejected.<br>&nbsp;</p><p>Conversion Rate : 1 {{site_currency}} = {{rate}} {{method_currency}}</p><p>Received : {{method_amount}} {{method_currency}}<br>&nbsp;</p><p>Paid via :&nbsp; {{method_name}}</p><p>Charge: {{charge}}</p><p>Transaction Number was : {{trx}}</p><p>if you have any queries, feel free to contact us.<br>&nbsp;</p><p>&nbsp;</p><p>{{rejection_message}}<br>&nbsp;</p>', 'Admin Rejected Your {{amount}} {{site_currency}} Credit payment request by {{method_name}}\r\n\r\n{{rejection_message}}', '{\"trx\":\"Transaction number for the deposit\",\"number_of_credit\":\"Number of Credit\",\"amount\":\"Amount inserted by the user\",\"charge\":\"Gateway charge set by the admin\",\"rate\":\"Conversion rate between base currency and method currency\",\"method_name\":\"Name of the deposit method\",\"method_currency\":\"Currency of the deposit method\",\"method_amount\":\"Amount after conversion between base currency and method currency\",\"rejection_message\":\"Rejection message by the admin\"}', 1, 1, NULL, '2025-10-26 07:28:03'),
(28, 'CREDIT_PAYMENT_COMPLETE', 'Credit Payment - Automated - Successful', 'Credit Payment Completed Successfully', '<p>Your credit payment of&nbsp;{{amount}} {{site_currency}}&nbsp;is via&nbsp; {{method_name}}&nbsp;has been completed Successfully.<br>&nbsp;</p><p>Details of your Credit Payment:<br>&nbsp;</p><p>Amount : {{amount}} {{site_currency}}</p><p>Charge:&nbsp;{{charge}} {{site_currency}}</p><p>Conversion Rate : 1 {{site_currency}} = {{rate}} {{method_currency}}</p><p>Received : {{method_amount}} {{method_currency}}<br>&nbsp;</p><p>Paid via :&nbsp; {{method_name}}</p><p>Transaction Number : {{trx}}</p><p>&nbsp;</p><p>Your current Balance is&nbsp;{{post_balance}} {{site_currency}}</p>', '{{amount}} {{site_currency}} Credit Payment successfully by {{method_name}}', '{\"trx\":\"Transaction number for the credit payment\",\"amount\":\"Amount inserted by the user\",\"charge\":\"Gateway charge set by the admin\",\"rate\":\"Conversion rate between base currency and method currency\",\"method_name\":\"Name of the deposit method\",\"method_currency\":\"Currency of the deposit method\",\"method_amount\":\"Amount after conversion between base currency and method currency\",\"post_balance\":\"Balance of the user after this transaction\"}', 1, 1, '2021-11-03 12:00:00', '2025-10-26 07:27:20');

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `slug` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `secs` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `name`, `slug`, `secs`, `is_default`, `created_at`, `updated_at`) VALUES
(1, 'Home', '/', '[\"counter\",\"service\",\"action\",\"tutorial\",\"testimonial\",\"blog\"]', 1, '2020-07-11 06:23:58', '2025-11-05 04:13:58'),
(4, 'Blog', 'blog', NULL, 1, '2020-10-22 01:14:43', '2025-11-15 06:08:30'),
(5, 'Contact', 'contact', NULL, 1, '2020-10-22 01:14:53', '2025-11-05 06:27:08'),
(21, 'About', 'about', '[\"feature\",\"blog\"]', 0, '2025-09-16 02:57:01', '2025-11-05 06:16:54'),
(22, 'Pricing', 'pricing', '[\"pricing\",\"feature\",\"how_it_work\"]', 0, '2025-10-26 05:24:24', '2025-10-26 05:25:22'),
(23, 'Features', 'features', '[\"feature\",\"action\"]', 0, '2025-10-26 06:12:05', '2025-11-05 05:59:12');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` bigint NOT NULL,
  `email` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `token` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `email`, `token`, `created_at`) VALUES
(3, 'user@site.com', '251321', '2025-07-02 06:14:08'),
(18, 'testuser@gmail.com', '723997', '2025-11-15 00:51:01');

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint NOT NULL,
  `groupby` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `slug` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 => admin 2 => user',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `groupby`, `name`, `slug`, `type`, `created_at`, `updated_at`) VALUES
(1, 'Dashboard', 'Dashboard', 'dashboard', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(2, 'Role Management', 'Role', 'role', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(3, 'Staff Mangement', 'Staff Management', 'staff', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(4, 'User Management', 'User Management', 'user-management', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(5, 'Subscriber Management', 'Subscriber Management', 'subscriber-management', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(6, 'Deposit Management', 'Deposit Management', 'deposit-management', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(7, 'Withdraw Management', 'Withdraw Management', 'withdraw-management', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(8, 'Payment Method', 'Payment Method', 'payment-method', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(9, 'Withdraw Method', 'Withdraw Method', 'withdraw-method', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(10, 'Support Ticket', 'Support Ticket', 'support-ticket', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(11, 'Report Management', 'Reports', 'reports', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(12, 'Global Settings', 'Settings', 'settings', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(13, 'Page Management', 'Page Management', 'page-management', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(14, 'Section Management', 'Section Management', 'section-management', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(15, 'Language Management', 'Language Management', 'language-management', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(16, 'Plugin Management', 'Plugin Management', 'plugin-management', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(17, 'Kyc Management', 'Kyc', 'kyc', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(18, 'Topbar Notification', 'Admin Notification', 'admin-notification', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(19, 'Form Builder Management', 'Form Builder Management', 'form-builder-management', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14'),
(20, 'Plan Management', 'Plan Management', 'plan-management', 1, '2025-11-01 08:12:14', '2025-11-01 08:12:14');

-- --------------------------------------------------------

--
-- Table structure for table `permission_roles`
--

CREATE TABLE `permission_roles` (
  `id` bigint NOT NULL,
  `role_id` bigint NOT NULL,
  `permission_id` bigint NOT NULL,
  `type` tinyint(1) NOT NULL COMMENT '1 => admin 2 => user',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `plugins`
--

CREATE TABLE `plugins` (
  `id` bigint UNSIGNED NOT NULL,
  `act` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `script` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `shortcode` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'object',
  `support` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'help section',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=>enable, 2=>disable',
  `deleted_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `plugins`
--

INSERT INTO `plugins` (`id`, `act`, `name`, `description`, `image`, `script`, `shortcode`, `support`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'tawk-chat', 'Live Chat(Tawk.to)', 'Key location is shown bellow', 'chat-png.png', '<script>\n                        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();\n                        (function(){\n                        var s1=document.createElement(\"script\"),s0=document.getElementsByTagName(\"script\")[0];\n                        s1.async=true;\n                        s1.src=\"https://embed.tawk.to/{{app_key}}\";\n                        s1.charset=\"UTF-8\";\n                        s1.setAttribute(\"crossorigin\",\"*\");\n                        s0.parentNode.insertBefore(s1,s0);\n                        })();\n                    </script>', '{\"app_key\":{\"title\":\"App Key\",\"value\":\"dddddddddddd\"}}', 'twak.png', 0, NULL, '2019-10-18 23:16:05', '2025-08-24 00:56:53'),
(2, 'google-recaptcha2', 'Google Recaptcha 2', 'Key location is shown bellow', 'recaptcha2.png', '\n<script src=\"https://www.google.com/recaptcha/api.js\"></script>\n<div class=\"g-recaptcha\" data-sitekey=\"{{site_key}}\" data-callback=\"verifyCaptcha\"></div>\n<div id=\"g-recaptcha-error\"></div>', '{\"site_key\":{\"title\":\"Site Key\",\"value\":\"6LdPC88fAAAAADQlUf_DV6Hrvgm-pZuLJFSLDOWV\"},\"secret_key\":{\"title\":\"Secret Key\",\"value\":\"6LdPC88fAAAAAG5SVaRYDnV2NpCrptLg2XLYKRKB\"}}', 'recaptcha.png', 0, NULL, '2019-10-18 23:16:05', '2025-07-01 23:58:26'),
(3, 'google-analytics', 'Google Analytics', 'Key location is shown bellow', 'google_analytics.png', '<script async src=\"https://www.googletagmanager.com/gtag/js?id={{app_key}}\"></script>\r\n                <script>\r\n                  window.dataLayer = window.dataLayer || [];\r\n                  function gtag(){dataLayer.push(arguments);}\r\n                  gtag(\"js\", new Date());\r\n                \r\n                  gtag(\"config\", \"{{app_key}}\");\r\n                </script>', '{\"app_key\":{\"title\":\"App Key\",\"value\":\"G-JGB5GZ3G69\"}}', 'ganalytics.png', 0, '2025-07-20 19:47:55', '2025-07-20 13:47:55', '2025-08-12 05:22:56');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint NOT NULL,
  `user_id` bigint NOT NULL DEFAULT '0',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 => admin, 2 => user',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 => enable, 0 => disable',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `user_id`, `name`, `type`, `status`, `created_at`, `updated_at`) VALUES
(2, 0, 'Contributor', 1, 1, '2025-07-05 05:21:11', '2025-07-24 05:08:37'),
(3, 0, 'Editor', 1, 1, '2025-07-05 05:22:34', '2025-07-24 05:08:13'),
(4, 0, 'Member', 1, 1, '2025-07-07 00:16:17', '2025-07-24 05:08:03'),
(8, 0, 'Moderator', 1, 0, '2025-07-07 01:49:59', '2025-08-23 01:42:32');

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` bigint UNSIGNED NOT NULL,
  `email` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `email`, `created_at`, `updated_at`) VALUES
(1, 'testuser@gmail.com', '2025-11-04 00:44:56', '2025-11-04 00:44:56');

-- --------------------------------------------------------

--
-- Table structure for table `support_attachments`
--

CREATE TABLE `support_attachments` (
  `id` bigint UNSIGNED NOT NULL,
  `support_message_id` int UNSIGNED DEFAULT NULL,
  `attachment` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `support_messages`
--

CREATE TABLE `support_messages` (
  `id` bigint UNSIGNED NOT NULL,
  `support_ticket_id` int UNSIGNED NOT NULL DEFAULT '0',
  `admin_id` int UNSIGNED NOT NULL DEFAULT '0',
  `message` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `support_messages`
--

INSERT INTO `support_messages` (`id`, `support_ticket_id`, `admin_id`, `message`, `created_at`, `updated_at`) VALUES
(1, 1, 0, 'Sequi blanditiis exe', '2025-10-25 09:47:55', '2025-10-25 09:47:55'),
(2, 8, 0, 'sdfa', '2025-11-04 03:12:28', '2025-11-04 03:12:28'),
(3, 9, 0, 'Culpa in quidem nih', '2025-11-05 06:51:06', '2025-11-05 06:51:06'),
(4, 10, 0, 'ujjk', '2025-11-16 05:00:32', '2025-11-16 05:00:32');

-- --------------------------------------------------------

--
-- Table structure for table `support_tickets`
--

CREATE TABLE `support_tickets` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int DEFAULT '0',
  `name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ticket` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: Open, 1: Answered, 2: Replied, 3: Closed',
  `priority` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 = Low, 2 = medium, 3 = heigh',
  `last_reply` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `support_tickets`
--

INSERT INTO `support_tickets` (`id`, `user_id`, `name`, `email`, `ticket`, `subject`, `status`, `priority`, `last_reply`, `created_at`, `updated_at`) VALUES
(1, 1, 'test user', 'testuser@gmail.com', '503740', 'for check', 0, 3, '2025-08-26 13:37:36', '2025-08-26 07:37:36', '2025-08-26 07:37:36'),
(2, 0, 'test user', 'testuser@gmail.com', '03783319', 'Payemnthas been rejected', 0, 2, '2025-09-04 13:50:14', '2025-09-04 07:50:14', '2025-09-04 07:50:14'),
(3, 1, 'Macclum Bon', 'testuser@gmail.com', '387797', 'Transaction issue', 0, 1, '2025-09-07 08:42:31', '2025-09-07 02:42:31', '2025-09-07 02:42:31'),
(4, 0, 'James bon', 'testuser@gmail.com', '03033880', 'Withdraw has been rejected', 0, 2, '2025-09-07 08:44:49', '2025-09-07 02:44:49', '2025-09-07 02:44:49'),
(5, 0, 'test user', 'testuser@gmail.com', '66047628', 'Test', 0, 2, '2025-10-18 05:32:46', '2025-10-17 23:32:46', '2025-10-17 23:32:46'),
(6, 1, 'Test', 'testuser04@gmail.com', '334699', 'Germaine Sears', 0, 2, '2025-10-18 06:02:29', '2025-10-18 00:02:29', '2025-10-18 00:02:29'),
(7, 0, 'test user', 'testuser@gmail.com', '67867805', 'Germaine Sears', 0, 2, '2025-10-18 07:59:37', '2025-10-18 01:59:37', '2025-10-18 01:59:37'),
(8, 0, 'test user', 'testuser@gmail.com', '05166087', 'Germaine Sears', 0, 2, '2025-11-04 09:12:28', '2025-11-04 03:12:28', '2025-11-04 03:12:28'),
(9, 0, 'viryjeguki', 'juhahagyt@mailinator.com', '50034811', 'Ipsam commodo culpa', 0, 2, '2025-11-05 12:51:06', '2025-11-05 06:51:06', '2025-11-05 06:51:06'),
(10, 0, 'Demo', 'guevara3837@gmail.com', '34089573', 'Sociology of Religion and Spiritual Practices', 0, 2, '2025-11-16 11:00:32', '2025-11-16 05:00:32', '2025-11-16 05:00:32');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL DEFAULT '0',
  `amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `post_balance` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `post_credit` int NOT NULL DEFAULT '0',
  `trx_type` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `trx` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `details` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `remark` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `amount`, `charge`, `post_balance`, `post_credit`, `trx_type`, `trx`, `details`, `remark`, `created_at`, `updated_at`) VALUES
(1, 1, 200.00000000, 1.50000000, 2910.00000000, 43, '-', 'RZC2G1HH257G', 'Credit Payment Via from Manual Transfer', 'credit payment', '2025-10-27 05:00:37', '2025-10-27 05:00:37'),
(2, 1, 90.00000000, 1.22500000, 3000.00000000, 43, '+', 'D21XD79H1WOK', 'Deposit Payment Via from Manual Transfer', 'deposit payment', '2025-10-27 05:02:36', '2025-10-27 05:02:36'),
(3, 1, 50.00000000, 1.12500000, 3000.00000000, 43, '-', '9F7T82PJJMB8', 'Plan Subscription Payment Via from Manual Transfer', 'plan subscription payment', '2025-10-27 05:05:09', '2025-10-27 05:05:09'),
(4, 1, 300.00000000, 0.00000000, 3000.00000000, 43, '-', 'FMSRS5CTCN6T', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-27 05:06:52', '2025-10-27 05:06:52'),
(5, 1, 0.00000000, 0.00000000, 2700.00000000, 43, '-', '4MUYWT83K7YG', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-27 05:16:20', '2025-10-27 05:16:20'),
(6, 1, 100.00000000, 0.00000000, 2700.00000000, 43, '-', 'SZ3UFJRSH1DM', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-27 05:33:47', '2025-10-27 05:33:47'),
(7, 1, 100.00000000, 0.00000000, 2700.00000000, 43, '-', 'MF3HDPJX7U9B', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-27 05:34:35', '2025-10-27 05:34:35'),
(8, 1, 100.00000000, 0.00000000, 2700.00000000, 43, '-', '63UBBUY3T12H', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-27 05:35:31', '2025-10-27 05:35:31'),
(9, 1, 300.00000000, 0.00000000, 2600.00000000, 43, '-', 'YS64P5NCEVP5', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-27 06:32:12', '2025-10-27 06:32:12'),
(10, 1, 0.00000000, 0.00000000, 2300.00000000, 43, '-', 'H6WF6KZYVCUR', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-27 06:40:53', '2025-10-27 06:40:53'),
(11, 1, 0.00000000, 0.00000000, 2300.00000000, 43, '-', 'GV79YCCFSTQQ', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-27 06:42:03', '2025-10-27 06:42:03'),
(12, 1, 0.00000000, 0.00000000, 2300.00000000, 43, '-', '341RWE35AZG1', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-27 06:42:40', '2025-10-27 06:42:40'),
(13, 1, 50.00000000, 1.12500000, 2300.00000000, 43, '-', 'SAM7FE6S71PW', 'Plan Subscription Payment Via from Manual Transfer', 'plan subscription payment', '2025-10-27 06:49:42', '2025-10-27 06:49:42'),
(14, 1, 100.00000000, 0.00000000, 2300.00000000, 63, '-', 'SKVA1QDGSWR7', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-27 06:51:09', '2025-10-27 06:51:09'),
(15, 1, 300.00000000, 1.75000000, 2200.00000000, 63, '-', 'J1TV11UTVKE4', 'Plan Subscription Payment Via from Manual Transfer', 'plan subscription payment', '2025-10-27 07:09:35', '2025-10-27 07:09:35'),
(16, 1, 500.00000000, 0.00000000, 2200.00000000, 288, '-', '1X855WNOF1KU', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-27 07:10:43', '2025-10-27 07:10:43'),
(17, 1, 30.00000000, 1.07500000, 1670.00000000, 0, '-', 'GCKNMFPTWTPP', '28.93 $ Withdraw Via Bank Transfer', 'withdraw', '2025-10-27 07:22:10', '2025-10-27 07:22:10'),
(18, 1, 0.00000000, 0.00000000, 1670.00000000, 231, '-', 'CDTO7S6OFOG9', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-30 05:30:03', '2025-10-30 05:30:03'),
(19, 1, 0.00000000, 0.00000000, 1670.00000000, 231, '-', 'XXFFOUO1URXQ', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-30 06:04:57', '2025-10-30 06:04:57'),
(20, 1, 0.00000000, 0.00000000, 1670.00000000, 231, '-', 'QC9C9BY4W2HN', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-10-30 06:08:28', '2025-10-30 06:08:28'),
(21, 1, 50.00000000, 0.00000000, 1670.00000000, 55, '-', 'RQ1EX9F4MAC9', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-11-02 03:31:49', '2025-11-02 03:31:49'),
(22, 2, 100.00000000, 0.00000000, 1670.00000000, 65, '-', '7DDYOTCA5477', 'Payment With Balance to Plan Subscription Payment', 'Plan Subscription Payment', '2025-11-02 04:39:21', '2025-11-02 04:39:21'),
(23, 1, 300.00000000, 1.75000000, 1620.00000000, 125, '-', 'QTUDS7XSY5WE', 'Plan Subscription Payment Via from Manual Transfer', 'plan subscription payment', '2025-11-04 02:23:46', '2025-11-04 02:23:46'),
(24, 1, 200.00000000, 0.00000000, 1420.00000000, 160, '-', 'FPU1RDPSAEF4', 'Payment With Balance to Purchase Credit', 'Credit Purchase Payment', '2025-11-09 03:10:57', '2025-11-09 03:10:57'),
(25, 1, 400.00000000, 0.00000000, 1020.00000000, 180, '-', '2J9YT4U55VOA', 'Payment With Balance to Purchase Credit', 'Credit Purchase Payment', '2025-11-09 03:11:32', '2025-11-09 03:11:32'),
(26, 1, 240.00000000, 1.60000000, 1020.00000000, 192, '-', 'HNFFGHMYMTYK', 'Credit Payment Via from Manual Transfer', 'credit payment', '2025-11-09 03:13:03', '2025-11-09 03:13:03'),
(27, 1, 200.00000000, 1.50000000, 1020.00000000, 202, '-', '2X93W7TH6PGO', 'Credit Payment Via from Manual Transfer', 'credit payment', '2025-11-09 03:13:54', '2025-11-09 03:13:54'),
(28, 1, 210.00000000, 1.52500000, 1020.00000000, 202, '+', 'SOSOFWDVQR34', 'Deposit Payment Via from Manual Transfer', 'deposit payment', '2025-11-09 03:19:48', '2025-11-09 03:19:48'),
(29, 1, 30.00000000, 1.07500000, 1020.00000000, 202, '+', 'QOBCZWMQNM1E', 'Deposit Payment Via from Manual Transfer', 'deposit payment', '2025-11-09 03:20:56', '2025-11-09 03:20:56'),
(30, 1, 50.00000000, 1.12500000, 1070.00000000, 202, '+', '46M8VKRKJ2AW', 'Deposit Payment Via from Manual Transfer', 'deposit payment', '2025-11-09 03:22:03', '2025-11-09 03:22:03');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `parent_id` bigint NOT NULL DEFAULT '0',
  `role_id` bigint NOT NULL DEFAULT '0',
  `firstname` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `lastname` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `username` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `country_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `mobile` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `credit` decimal(18,2) NOT NULL DEFAULT '0.00',
  `ref_by` int UNSIGNED NOT NULL DEFAULT '0',
  `balance` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `address` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci COMMENT 'contains full address',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0: banned, 1: active',
  `kyc_data` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `kv` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: KYC Unverified, 2: KYC pending, 1: KYC verified',
  `ev` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: email unverified, 1: email verified',
  `sv` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: mobile unverified, 1: mobile verified',
  `reg_step` tinyint(1) NOT NULL DEFAULT '0',
  `ver_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'stores verification code',
  `ver_code_send_at` datetime DEFAULT NULL COMMENT 'verification send time',
  `ts` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0: 2fa off, 1: 2fa on',
  `tv` tinyint(1) NOT NULL DEFAULT '1' COMMENT '0: 2fa unverified, 1: 2fa verified',
  `tsc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `ban_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `remember_token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `parent_id`, `role_id`, `firstname`, `lastname`, `username`, `email`, `country_code`, `mobile`, `credit`, `ref_by`, `balance`, `password`, `image`, `address`, `status`, `kyc_data`, `kv`, `ev`, `sv`, `reg_step`, `ver_code`, `ver_code_send_at`, `ts`, `tv`, `tsc`, `ban_reason`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 0, 0, 'test', 'user', 'testuser', 'testuser@gmail.com', 'AL', '355939344452354527', 195.79, 0, 1070.00000000, '$2y$12$KbOYS5pnGxTgwgrGC6VkV.4f8ZpEpD01Q9..R5UrnwQ7i5mujBcqK', 'testuser/1/690c6c36139021762421814.png', '{\"address\":\"America,USA\",\"state\":\"America\",\"zip\":\"1230\",\"country\":\"United Kingdom\",\"city\":\"America\"}', 1, NULL, 1, 1, 1, 1, '271729', '2025-10-26 14:24:36', 0, 1, NULL, NULL, NULL, '2025-10-26 08:24:35', '2025-11-16 05:04:20'),
(2, 0, 0, 'Rogas', 'Tony', 'rogastony', 'rogastony@gmail.com', 'AF', '93934457676', 220.60, 0, 1570.00000000, '$2y$12$3HVQbXjCo5MxDvo2nZ9K0.R/5iMhjU544VFS2FEl2qLZ4T0Xu340m', 'testuser/1/68fe336b002341761489771.jpg', '{\"address\":\"America,USA\",\"state\":\"America\",\"zip\":\"1230\",\"country\":\"United Kingdom\",\"city\":\"America\"}', 1, NULL, 1, 1, 1, 1, '271729', '2025-10-26 14:24:36', 0, 1, NULL, NULL, NULL, '2025-10-26 08:24:35', '2025-11-02 04:57:07'),
(3, 0, 0, NULL, NULL, 'rtytryerty', 'dffd@gmailcom', 'AF', '934563453', 0.00, 0, 0.00000000, '$2y$12$hDXyEcTwEEXFPvcNvF/cJeMrEH1O32zgPJoOAwEMdL1DG5iZEcqri', NULL, '{\"address\":\"\",\"state\":\"\",\"zip\":\"\",\"country\":\"Afghanistan\",\"city\":\"\"}', 1, NULL, 1, 1, 1, 0, NULL, NULL, 0, 1, NULL, NULL, NULL, '2025-11-05 09:09:52', '2025-11-05 09:48:08');

-- --------------------------------------------------------

--
-- Table structure for table `user_logins`
--

CREATE TABLE `user_logins` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` int UNSIGNED NOT NULL DEFAULT '0',
  `user_ip` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `city` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `country` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `country_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `longitude` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `latitude` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `browser` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `os` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_logins`
--

INSERT INTO `user_logins` (`id`, `user_id`, `user_ip`, `city`, `country`, `country_code`, `longitude`, `latitude`, `browser`, `os`, `created_at`, `updated_at`) VALUES
(1, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-10-27 01:26:34', '2025-10-27 01:26:34'),
(2, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-10-28 00:59:06', '2025-10-28 00:59:06'),
(3, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-10-29 00:47:40', '2025-10-29 00:47:40'),
(4, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-10-29 04:45:05', '2025-10-29 04:45:05'),
(5, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-10-29 23:24:16', '2025-10-29 23:24:16'),
(6, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-10-30 07:48:53', '2025-10-30 07:48:53'),
(7, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-01 01:24:57', '2025-11-01 01:24:57'),
(8, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-02 00:41:34', '2025-11-02 00:41:34'),
(9, 2, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-02 00:42:11', '2025-11-02 00:42:11'),
(10, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-02 03:10:35', '2025-11-02 03:10:35'),
(11, 2, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-02 04:38:30', '2025-11-02 04:38:30'),
(12, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-03 07:46:47', '2025-11-03 07:46:47'),
(13, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-04 00:40:43', '2025-11-04 00:40:43'),
(14, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-04 03:18:11', '2025-11-04 03:18:11'),
(15, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-04 04:21:22', '2025-11-04 04:21:22'),
(16, 2, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-04 04:23:46', '2025-11-04 04:23:46'),
(17, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-04 04:46:36', '2025-11-04 04:46:36'),
(18, 3, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-05 09:09:52', '2025-11-05 09:09:52'),
(19, 3, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-05 10:09:47', '2025-11-05 10:09:47'),
(20, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-05 23:49:01', '2025-11-05 23:49:01'),
(21, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-05 23:49:57', '2025-11-05 23:49:57'),
(22, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-06 03:58:38', '2025-11-06 03:58:38'),
(23, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-09 02:44:29', '2025-11-09 02:44:29'),
(24, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-10 00:34:09', '2025-11-10 00:34:09'),
(25, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-10 23:20:40', '2025-11-10 23:20:40'),
(26, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-11 00:01:18', '2025-11-11 00:01:18'),
(27, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-11 03:14:44', '2025-11-11 03:14:44'),
(28, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-11 03:55:48', '2025-11-11 03:55:48'),
(29, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-11 03:56:25', '2025-11-11 03:56:25'),
(30, 1, '127.0.0.1', '', '', '', '', '', 'Firefox', 'Windows 10', '2025-11-11 05:17:20', '2025-11-11 05:17:20'),
(31, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-12 00:11:29', '2025-11-12 00:11:29'),
(32, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-12 08:14:53', '2025-11-12 08:14:53'),
(33, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-13 03:23:28', '2025-11-13 03:23:28'),
(34, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-13 07:06:27', '2025-11-13 07:06:27'),
(35, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-15 01:04:41', '2025-11-15 01:04:41'),
(36, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-15 01:19:31', '2025-11-15 01:19:31'),
(37, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-15 06:09:49', '2025-11-15 06:09:49'),
(38, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-16 03:18:13', '2025-11-16 03:18:13'),
(39, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-16 05:03:07', '2025-11-16 05:03:07'),
(40, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-16 22:33:09', '2025-11-16 22:33:09'),
(41, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-16 23:04:23', '2025-11-16 23:04:23'),
(42, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-18 05:55:37', '2025-11-18 05:55:37'),
(43, 1, '127.0.0.1', '', '', '', '', '', 'Chrome', 'Windows 10', '2025-11-18 05:59:07', '2025-11-18 05:59:07');

-- --------------------------------------------------------

--
-- Table structure for table `user_notifications`
--

CREATE TABLE `user_notifications` (
  `id` int NOT NULL,
  `user_id` int UNSIGNED NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `click_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `read_status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_notifications`
--

INSERT INTO `user_notifications` (`id`, `user_id`, `title`, `click_url`, `read_status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Form Builder Answer Submitted', '/user/submission', 0, '2025-11-01 05:53:19', '2025-11-01 05:58:11'),
(2, 2, 'New Form Builder Answer Received', '/user/answer-list/4', 1, '2025-11-01 05:53:19', '2025-11-01 05:53:19'),
(3, 1, 'Form Builder Answer Submitted', '/user/submission', 1, '2025-11-02 00:43:59', '2025-11-02 00:43:59'),
(4, 2, 'New Form Builder Answer Received', '/user/answer-list/5', 1, '2025-11-02 00:43:59', '2025-11-02 00:43:59'),
(5, 2, 'Form Builder Answer Submitted', '/user/submission', 1, '2025-11-02 00:45:17', '2025-11-02 00:45:17'),
(6, 1, 'New Form Builder Answer Received', '/user/answer-list/5', 1, '2025-11-02 00:45:17', '2025-11-02 00:45:17'),
(7, 1, 'Form Builder Answer Submitted', '/user/submission', 1, '2025-11-02 00:46:52', '2025-11-02 00:46:52'),
(8, 2, 'New Form Builder Answer Received', '/user/answer-list/4', 1, '2025-11-02 00:46:52', '2025-11-02 00:46:52'),
(9, 2, 'Form Builder Answer Submitted', '/user/submission', 1, '2025-11-02 00:51:13', '2025-11-02 00:51:13'),
(10, 1, 'New Form Builder Answer Received', '/user/answer-list/5', 1, '2025-11-02 00:51:13', '2025-11-02 00:51:13'),
(11, 1, 'Balance with Plan Subscription Payment', '/user/transactions?search=RQ1EX9F4MAC9', 1, '2025-11-02 03:31:49', '2025-11-02 03:31:49'),
(12, 2, 'Balance with Plan Subscription Payment', '/user/transactions?search=7DDYOTCA5477', 1, '2025-11-02 04:39:21', '2025-11-02 04:39:21'),
(13, 1, 'Plan Subscription Paymentsuccessful via Manual Transfer', '/user/deposit/history?search=QTUDS7XSY5WE', 1, '2025-11-04 02:23:46', '2025-11-04 02:23:46'),
(14, 1, 'Balance with Purchase Credit', '/user/transactions?search=FPU1RDPSAEF4', 1, '2025-11-09 03:10:57', '2025-11-09 03:10:57'),
(15, 1, 'Balance with Purchase Credit', '/user/transactions?search=2J9YT4U55VOA', 1, '2025-11-09 03:11:32', '2025-11-09 03:11:32'),
(16, 1, 'Credit Paymentsuccessful via Manual Transfer', '/user/deposit/history?search=HNFFGHMYMTYK', 1, '2025-11-09 03:13:03', '2025-11-09 03:13:03'),
(17, 1, 'Credit Paymentsuccessful via Manual Transfer', '/user/deposit/history?search=2X93W7TH6PGO', 1, '2025-11-09 03:13:54', '2025-11-09 03:13:54'),
(18, 1, 'Deposit Paymentsuccessful via Manual Transfer', '/user/deposit/history?search=SOSOFWDVQR34', 1, '2025-11-09 03:19:48', '2025-11-09 03:19:48'),
(19, 1, 'Deposit Paymentsuccessful via Manual Transfer', '/user/deposit/history?search=QOBCZWMQNM1E', 1, '2025-11-09 03:20:56', '2025-11-09 03:20:56'),
(20, 1, 'Deposit Paymentsuccessful via Manual Transfer', '/user/deposit/history?search=46M8VKRKJ2AW', 0, '2025-11-09 03:22:03', '2025-11-16 23:01:05');

-- --------------------------------------------------------

--
-- Table structure for table `withdrawals`
--

CREATE TABLE `withdrawals` (
  `id` bigint UNSIGNED NOT NULL,
  `method_id` int UNSIGNED NOT NULL DEFAULT '0',
  `user_id` int UNSIGNED NOT NULL DEFAULT '0',
  `amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `currency` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `rate` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `trx` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `final_amount` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `after_charge` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `withdraw_information` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1=>success, 2=>pending, 3=>cancel,  ',
  `admin_feedback` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `withdrawals`
--

INSERT INTO `withdrawals` (`id`, `method_id`, `user_id`, `amount`, `currency`, `rate`, `charge`, `trx`, `final_amount`, `after_charge`, `withdraw_information`, `status`, `admin_feedback`, `created_at`, `updated_at`) VALUES
(1, 3, 1, 30.00000000, '$', 1.00000000, 1.07500000, 'GCKNMFPTWTPP', 28.92500000, 28.92500000, '[{\"name\":\"Account Holder Name\",\"type\":\"text\",\"value\":\"Ben Dose\"},{\"name\":\"Bank Name\",\"type\":\"text\",\"value\":\"Manual Bank\"},{\"name\":\"Branch Code\",\"type\":\"text\",\"value\":\"2533\"},{\"name\":\"Account Number\",\"type\":\"text\",\"value\":\"32522AS44\"},{\"name\":\"Email for Confirmation\",\"type\":\"text\",\"value\":\"testuser@gmail.com\"}]', 1, '#DIJD34563#', '2025-10-27 07:22:00', '2025-10-27 07:23:08');

-- --------------------------------------------------------

--
-- Table structure for table `withdraw_methods`
--

CREATE TABLE `withdraw_methods` (
  `id` bigint UNSIGNED NOT NULL,
  `form_id` int UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `min_limit` decimal(28,8) DEFAULT '0.00000000',
  `max_limit` decimal(28,8) NOT NULL DEFAULT '0.00000000',
  `fixed_charge` decimal(28,8) DEFAULT '0.00000000',
  `rate` decimal(28,8) DEFAULT '0.00000000',
  `percent_charge` decimal(5,2) DEFAULT NULL,
  `currency` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `withdraw_methods`
--

INSERT INTO `withdraw_methods` (`id`, `form_id`, `name`, `min_limit`, `max_limit`, `fixed_charge`, `rate`, `percent_charge`, `currency`, `description`, `image`, `status`, `created_at`, `updated_at`) VALUES
(1, 13, 'Tranfer from Bank', 1.00000000, 1000.00000000, 1.00000000, 1.00000000, 2.00, 'USD', '<p><i>This method is for internal bank-to-bank transfers. Provide your receiving bank details exactly as registered. Transfer will typically reflect within 2–5 business days depending on banks involved.</i></p>', '68ad62763fa621756193398.png', 1, '2022-03-30 09:09:11', '2025-09-21 07:25:23'),
(2, 14, 'Mobile Banking', 1.00000000, 1000.00000000, 0.00000000, 1.00000000, 0.01, 'USD', '<p><i>Provide the correct mobile banking number and account name. Make sure your mobile banking wallet is active and able to receive funds. Processing time is usually instant to 24 hours after approval.</i><br>&nbsp;</p>', '68ad626943d931756193385.png', 1, '2022-03-30 09:10:12', '2025-09-21 07:25:04'),
(3, 24, 'Bank Transfer', 1.00000000, 1000000000.00000000, 1.00000000, 1.00000000, 0.25, '$', '<p><i>Please ensure the bank account details are correct before submitting your request. Funds will be transferred within 1–3 business days after approval. Any incorrect information may result in delays or failed transfers.</i></p>', '68ad6251354db1756193361.png', 1, '2025-06-29 04:40:12', '2025-10-02 05:23:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`,`username`);

--
-- Indexes for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_password_resets`
--
ALTER TABLE `admin_password_resets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `deposits`
--
ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forms`
--
ALTER TABLE `forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `frontends`
--
ALTER TABLE `frontends`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gateways`
--
ALTER TABLE `gateways`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gateway_currencies`
--
ALTER TABLE `gateway_currencies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `general_settings`
--
ALTER TABLE `general_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logos`
--
ALTER TABLE `logos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logo_images`
--
ALTER TABLE `logo_images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `menus_slug_unique` (`code`);

--
-- Indexes for table `menu_items`
--
ALTER TABLE `menu_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu_menu_items`
--
ALTER TABLE `menu_menu_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_logs`
--
ALTER TABLE `notification_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notification_templates`
--
ALTER TABLE `notification_templates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permission_roles`
--
ALTER TABLE `permission_roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `plugins`
--
ALTER TABLE `plugins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_attachments`
--
ALTER TABLE `support_attachments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_messages`
--
ALTER TABLE `support_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`,`email`);

--
-- Indexes for table `user_logins`
--
ALTER TABLE `user_logins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_notifications`
--
ALTER TABLE `user_notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdrawals`
--
ALTER TABLE `withdrawals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `withdraw_methods`
--
ALTER TABLE `withdraw_methods`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `admin_password_resets`
--
ALTER TABLE `admin_password_resets`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `deposits`
--
ALTER TABLE `deposits`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `forms`
--
ALTER TABLE `forms`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `frontends`
--
ALTER TABLE `frontends`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=129;

--
-- AUTO_INCREMENT for table `gateways`
--
ALTER TABLE `gateways`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `gateway_currencies`
--
ALTER TABLE `gateway_currencies`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `general_settings`
--
ALTER TABLE `general_settings`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `logos`
--
ALTER TABLE `logos`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `logo_images`
--
ALTER TABLE `logo_images`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `menu_items`
--
ALTER TABLE `menu_items`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `menu_menu_items`
--
ALTER TABLE `menu_menu_items`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `notification_logs`
--
ALTER TABLE `notification_logs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;

--
-- AUTO_INCREMENT for table `notification_templates`
--
ALTER TABLE `notification_templates`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `permission_roles`
--
ALTER TABLE `permission_roles`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plugins`
--
ALTER TABLE `plugins`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `support_attachments`
--
ALTER TABLE `support_attachments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `support_messages`
--
ALTER TABLE `support_messages`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `support_tickets`
--
ALTER TABLE `support_tickets`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_logins`
--
ALTER TABLE `user_logins`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `user_notifications`
--
ALTER TABLE `user_notifications`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `withdrawals`
--
ALTER TABLE `withdrawals`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `withdraw_methods`
--
ALTER TABLE `withdraw_methods`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
